---
layout: default
title: "Burners Adventure Game"
hero: /images/albert-robida-pd/free-fight-outside-walls.jpeg
hero_alt: "Free fight outside the walls — Albert Robida"
---

# BURNERS

*A little good, a little bad, a little of both.*

*Fast, lethal sword-and-sorcerie in the Dragon Isles. Fire makes it good.*

v0.5

---

## What Is a Burner?

Respectable folk spit the word. **Burner**: you're the drifter who blows into a harbor town on the evening tide with a sword, a spell, or a set of picks, takes the job nobody sane will touch, and is gone by the next fog, leaving behind a lighter strongbox, a heavier graveyard, and, often enough, a smoking ruin where a problem used to be. Not a soldier. Not a hero. Not exactly *honest*. A Burner.

They mean it as an insult. You wear it like a medal.

Because you are defined by one thing: **knowing which move the moment calls for.** When to stand in the press and trade blows. When to give ground and cut your losses. When to look at a thing too big to kill and simply *never draw*. Walk wide and live. And when the footing's gone and the odds have turned, when to *run*, purse be damned, and count breath as winning.

And when the job's finally done and the reckoning comes howling up the stairs behind you, you know the last move, the one that earned the name. **Leave nothing behind but smoke.** Fire settles most debts. Fire makes it good. *What do we do with witches? We burn 'em.*

Most who take up this trade don't last a season. The docks are full of would-be Burners who didn't know when to run, or drew on the wrong thing in the dark, or stayed one round too long admiring their own work. You won't become a *name* with a song sung about you by being the strongest or the deadliest. You'll become one by reading a bad bet and folding it.

**You are a Burner.** So is everyone at this table. You are not here to save the Dragon Isles; you are here to get in, get paid, and get out with your skin, and if the place is on fire behind you as you go, well. It usually is, after all, *"fire makes it good"*.

*The rest of this book is about staying alive long enough to be a name instead of a warning.*

---

## Say What You Do, and How

Everything in this game starts here. You say what your character does, and how they go about it: the deed, and your approach to it.

*I pick the lock* is half an answer. *I try to pick the lock* is less. Leave out the how and the Referee will ask for it: *"How do you go about that?"* Better to say it before you are asked:

- *I ease the tumblers with my picks, listening for the catch.*
- *I spike the lockplate with the hammer and pry it off.*
- *I put my shoulder to the door and break the latch.*

Same lock, three ways in. The Referee rules whether yours can work. If it is sound, it works. If it is risky, they name the Risk. What could possibly go wrong? You make an Approach roll.

How you go about it also says which Approach you roll. Take the sentry at the gate:

- Sword: *I come at him out of the dark and cut him down before he can shout.*
- Craft: *I wait for him to turn, then go over the wall behind him.*
- Heart: *I slide two crowns across and ask him to look the other way.*
- Sorcerie: *I catch his eye and Bewitch him. Old friends open gates.*

One sentry, four approaches.

More of the same idea:

- Searching: *I tap the flagstones with the ten-foot pole, listening for hollow.* Not *I check for traps.*
- Climbing: *I throw the grapnel to the parapet and hand-over-hand the rope.* Not *I climb the wall.*
- Talking: *I tell the harbormaster the cargo is plague-touched and he'd best not open it.* Not *I bluff him.*

Your character's Theme and Traits can help back up your approach.

---

## Glossary

### Character

- **Theme:** your name or alias and a short line on who you are.

- **Approach:** how you go about a situation: Sword, Craft, Heart, or Sorcerie.

  - **Sword:** fighting to the death. Weapons, armor, tactics, footwork, tempo. Used in a fight, not a friendly brawl.

  - **Craft:** practical skill. Stealth, locks, tracking, sailing, survival, first aid, making and mending.

  - **Heart:** people. Persuasion, intimidation, empathy, medicine, leadership, trade, languages, friendly brawls.

  - **Sorcerie:** magic and the unseen. Spell schools, divination, binding, alchemy, ancient lore.

- **Approach level:** you start with one Approach at level 1. Approach level adds to Approach rolls and sets how many Traits you may hold under that Approach (four per Approach level).

- **Trait:** a skill or quality under one Approach (*lockpicking*, *steady under fire*, *arming sword*). You gain Traits when you wake from sleep, from what you did at the table (see *Gaining Traits*). You may only take Traits for Approaches you have levels in (or the one your next level will raise), and only from that Approach's list (arms and armor are Sword, non-combat practical skills are Craft, magic schools are Sorcerie, people-skills are Heart, etc.). Arcana Traits name the item, like weapons: *staff*, *wand*, *orb*. Some Traits are trained-only: without them you cannot attempt the action or use the kit (a magic school, plate armor, greatsword or longbow, etc.).

- **Signature:** an asterisk on a Trait. A knack that showed up at your table: a named item, a **named companion**, an instinct, a holdout.

- **Character level:** you start at character level 1 with 1d6 HP. Earn XP and gain four new Traits to reach the next level (see [[Burners Experience]]). When you gain a character level, raise the Approach those four Traits sit under by one, and reroll your HP. If you survive to reach 4th level, your character will have 4 Approach levels, either in a single Approach (Sword 4 or Sorcerie 4) or multiple (Sword 1 and Sorcerie 3).

### Equipment

- **Gold pieces (gp):** all prices use traditional gold pieces.

- **Inventory slots:** twelve slots for weapons, armor, gear, and baggage. Big items (a sword, a shield, a backpack) use more than one. What you hold in your hands still takes its slots: a sword in the fist counts the same as a sword on the belt. A **Boss** may split some of the twelve into **Muster slots** (see *Muster*). Pack beasts and mounts you buy to carry or ride sit **off** the twelve — see [[Burners Equipment#Animals and mounts]].

- **Baggage:** small items can share a slot if they ride in a pouch, quiver, or satchel (1 slot). A backpack (3 slots) holds bedroll, rope, rations, and loot efficiently, but takes ten minutes to unpack.

- **Count these:** ammunition, holy water, incendiaries, and rations — mark each when you spend it. You count the rest of the pack too; these are the ones that vanish if you don't mark. [[Burners Equipment#Count these]].

- **Gear dice:** your gear is your Fuel. On the Initiative roll, each weapon or shield in your hands and each Arcana your Approaches cover adds its slots in dice. Armor gives AC, not dice. Three or more empty slots give one die: light kit, quick feet. Muster and Sorcerie slots never count as empty. Dropping something to free a slot is an action.

- **Armor class (AC):** leftover after Defend, soaked by armor before HP. Leather 1, gambeson 2, mail 3, plate mail / field plate 4, full plate 5.

- **Muster / Manage:** Heart 1+ — hire and run retainers. Full rules: [[Burners Muster]].

### HP and Wounds

- **HP:** luck and wind, not meat — **hit protection**. One d6 per character level, rolled at creation. Reroll at level-up and keep the higher of the new total or old+1. Bites come off HP first; only overflow past 0 opens a Wound. Reach **full HP** and your wounds close.

- **Wound:** real injury. You take one when a blow drives you **past 0 HP**, or when harm lands where **HP cannot help** (helpless, some poisons, module specials). Track **wound severity** (sum of overflow from wounding attacks). Penalties last until **full HP** (maimings excepted). See *Wounds*.

- **Wound effects:** where you were hit matters. A leg wound puts you in the dirt. A head hit narrows your sight. And so on.

- **Shock Check:** when a Wound opens, roll **`2d6 + Sword` vs total wound severity**. Fail and the shock table lands (dirt, stun, knockout…). Natural **1+1** always fails; **6+6** always succeeds.

- **Helpless:** bound, asleep, knocked out, finished at leisure. You cannot turn the blow — no HP; the harm is a Wound (or a coup). *In the dirt* is not helpless.

### Play

- **Turn:** ten minutes of play time. Turns are used to mark the passage of time, and help each player get a chance to do something ("say what you do"). Combat uses Rounds instead.

- **Risk:** the number the Referee names when a plan is risky. What could possibly go wrong? You roll an Approach roll against it.

- **Approach roll:** after you say what you do, if the Referee names a Risk, roll 2d6 and add your Approach level against that number. Meet or beat and you do it clean; fall short and the shortfall is **Heat**. To climb a cliff with Craft 3, you roll 2d6+3. Risk 10 and a roll of 7 means 3 Heat.

- **Heat:** unpaid Risk — the shortfall from an Approach roll. The Referee banks it and spends it as consequences, and may convert Heat into HP when the bite is on a body.

- **Sweet and Spicy:** a rolled 6 is Sweet (a good twist); a rolled 1 is Spicy (a complication). These ride alongside the sum and never change it. Two 6s (a natural 12) is the perfect roll. Two 1s (a natural 2) is a fumble.

- **Alignment:** like an Approach, but for a specific situation or bond with a patron, guild, or power. Count every relevant Trait across all your Approaches, divide by 4, round down. See *Alignment*.

### Combat

- **Roll Initiative!:** the Referee will say "roll initiative!" to signal the start of combat. Immediately roll your Fuel maximum in d6s: your level plus your gear dice (see *Burners (PCs)* under Combat). Leave them on the table, untouched, frozen at their face values. These dice become your Fuel. At each Roll Initiative after that, keep the dice you didn't use and top off: roll your level, plus 1 for each counted item you have the Trait for, plus your light-kit die, never past your maximum. Your Initiative is how many show 3 or 4 (see *Initiative order*).

- **Initiative order:** the Referee names the number the monsters act on. Match or beat it and you go before them; fall short and you go after. Within before or after, players coordinate and act in any order they wish. Going before them entitles you to the whole Action then — move, position, strike, cast. You may hold any of it and use it when something happens; holding doesn't make you first (see *Holding* under Combat).

  - **Surprise:** at the start of combat the Referee will roll to see if either side is surprised. If a side is surprised, their round 1 Initiative order is dead last. There is no other effect (nobody loses their Action; Fuel is unchanged).

- **Combat Round:** one minute. Your character gets one Action (attack, cast, etc.) based on Initiative order. You may move and position as part of your Action, such as drawing a weapon and moving to engage a foe. With a foe already in reach, drawing is Friction (see *Friction*).

- **Continued Combat:** on round 2 and later the Referee says "roll initiative!" again. Keep the Fuel dice you didn't use and top off, never past your maximum, then recount 3s and 4s for the new Initiative order. The dice you keep stay frozen; do not re-roll them.

- **Fuel:** all the dice from your Initiative rolls, kept at their faces and burned through the fight to attack, defend, cast, and counterattack. Remove burned Fuel dice from play.

- **Spark:** a natural 6 on a Fuel die: an opportunity, not a free action. Spend the 6 to strike the Spark, then **Fuel the Spark** with the additional Fuel its option requires, or let it fade. Burned on a cast with an Arcana you have the Trait for, the 6 may add the Arcana's slots instead (see *Your 6s*).

- **Attack:** use your action to make an attack, either melee or missile. You must burn one Fuel die per attack, with the option to burn a second die if your weapon is 3+ slots and wielded in both hands. Deals damage of total Fuel die faces used. With Sword, you make an extra attack per Sword level, all burning Fuel.
  - **Flurry (Spark):** When attacking, Fuel a Spark to attack again (burn Fuel as for a normal attack); armor applies normally.
  - **Man-handle (Spark):** Fuel a Spark to shove, grab, trip, or knock down a foe. Armor does not soak. Free defense dice if they are hard to move: a bear, bronze in the water, four at once (one free die each). One Spark can shove a knot; each Defends the same force. A 7 beats one die — they fall; a 6 on that Defend still Sparks and may take you with them. Fully Defended: the shove fails (no reverse). They shove you back only if that Defend Sparks and they Fuel a man-handle.
  - **Impale (Spark):** When attacking with a Stabbity weapon (dagger, rondel, short sword…), Fuel a Spark to thrust deeper into the same spot; armor does not soak the Fuel you burn to Fuel it.
  - **Sever (Spark):** Only vs foes with **too many parts** — octopus, spider, hydra, swarm-limbs, and the like. When attacking with a Cutty / chopping weapon (poleax, battle ax, greatsword, cleaver…), Fuel a Spark with **1** Fuel to hack off one spare limb or head. That part's attack is gone for the fight. Not for ordinary humanoids (use Wounds / Man-handle).
  - **Past them (Spark):** An attack hits the first one in its line, friend or foe (the friend in front of you, the shield wall in front of their archer), unless you burn a 6 to get past. The 6 is a cost, not the blow's damage. See *Finding an opening* under *Friction*.

- **Defend:** burn Fuel to cut the blow; leftover, armor soaks, rest to HP. Caps: melee 1 die (no limit if you meleed or Blocked this round); missile 1 die (2 with Cover); hostile magic no limit. **Counterattack**, **Cover**, **Block**, **Ward**, **In the dirt**.

- **In the dirt:** flat on the ground — all Fuel burned must be re-rolled. Rise free on your Action unless a foe presses you in melee (then it's Friction: burn one Fuel, and a foe can counter). Waist/leg Wounds hold you down until full HP.

- **Cast / Ward (Sorcerer):** combat cast is one Action (Fuel ≥ SL). **Ward:** cut hostile magic for adjacent allies (up to Sorcerie Level Fuel); they Defend the remainder. Full cast procedure: [[Burners Sorcerie]].

### Monsters

- **Monster:** an enemy, with a stack of cards and an armor equivalent the Referee tells you (a goblin as gambeson, AC 2; a troll as mail, AC 3). Compare your weapon's slots to its AC: higher, +2 damage; equal, nothing; lower, −2. Divide by 5, rounding up if you have the weapon's Trait and down if you don't, and that many cards come off. Some foes have resistances to certain weapons (always −2, or −4) or a Bane (always +2); the Referee tells you when it shows. Full procedure: [[Burners Referee Guide#Monsters at speed (preferred Referee mode)]].

---

## Character Creation

1. You are character level 1. Place that level in one Approach: Sword, Craft, Heart, or Sorcerie.
2. Take up to four Traits under the Approach you just chose. You need not take all four now; gain the rest in play (see *Gaining Traits*).
3. Roll 1d6 for your HP.
4. Give your character a name or alias and a short "look" so the table gets to know them.
5. Take your starting kit, then spend your purse in town.

Signatures emerge in play. You do not choose them at creation.

To pick a people to come from (Northmaren, Southmaren, Elf, Alu, Kith, and the rest), see [[Burners Ancestry]]. Each entry is a ready-made look plus a menu of Traits, gear, and the Signatures your kind grows into. Eldar (listed on Ancestry and [[Burners Experience#Eldar]]) use the Eldar XP column — double XP — and may earn two Signatures per character level instead of one. Those Signatures still come in play; Ancestry is what lets them be gifts a mortal cannot claim (low light, charm, sleep, and the like). Northmarens and Southmarens use the ordinary column.

### Traits

On your sheet, a Trait is a skill or a quality: arming sword, herbalism, strong, perceptive, raised in the fens. **Up to four Traits per Approach level**, under that Approach only. Sword 2 → up to eight Sword Traits. Sword 1 and Sorcerie 1 → up to four Sword and four Sorcerie — not eight in one Approach. A Trait does not raise the Approach; your level does. You never buy Traits with XP.

**Gaining Traits.** Each time you wake from sleep, look back on what you did and take the Traits it earned: one, several, or none, up to the four for your next level. Each must come from something you went through at the table: you did the thing, learned it, or paid for it there. A moment that cut deep can earn more than one Trait — *"After the guard nearly took my head at the gate, I came away with silver tongue and steady under fire."* Take them at the table, when the waking is played; nothing done between sessions or on the road counts. There is no quota and nothing banked: a session with no new Trait is fine, and you are never owed one. Traits you left empty at creation are gained the same way. The four Traits for your next level go under the Approach that level will raise, so name that Approach when you gain the first of them. Change your mind and you may discard that Trait and earn a different one. When you wake from a safe sleep with those four Traits and enough XP, you level up (see [[Burners Experience]]).

**Option: burn to level.** The Referee may swap waking for burning. Traits and levels come when you burn something you won't get back: coin, a bridge, a lair, a name, an oath, a friend's trust, the ship you came in on. The Referee says whether it was enough. When you burn, look back and take the Traits you've earned since your last burn, and level up if you have the four Traits and enough XP.

**Option: burn it spectacularly.** Or keep waking for Traits, and let a spectacular burn stand in for them: a whole hoard thrown away, a kingdom's favor spent, the only way home cut off. Burn like that with enough XP and you level up, four Traits or not.

Either way it costs you: a burn costs what you gave up, and a night's sleep costs the time.

**Training.** Some Traits need a teacher. When play gives you no way to learn a thing (a new magic school, plate harness, a tongue nobody around you speaks), find an expert and pay them in coin, or in a task or favor they name. The Referee says which Traits need training.

**Traits by Approach — locked.** Each Trait belongs to one Approach. Write it under that Approach and nowhere else — it cannot count toward another Approach's four. Martial arms and armor are Sword (see *Arms and Armor*); languages are Heart; magic schools are Sorcerie. *Peasant weapons* (tools and hunting implements) are Craft. The lists below are the homes — not samples you may rehome.

- **Sword** — arms, armor, and the fight.
  - Skills: dagger, club, spear, axe, arming sword, mace, flail, bow, crossbow, shield, wrestling, boxing, ambush, tactics, cavalry, warhorse, siege, heraldry, scouting. Trained-only kit: see *Arms and Armor (Sword)* below (greatsword, warbows, plate, firearms…).
  - Qualities: strong, fearless, relentless, steady, iron-willed, veteran, hard to kill, courageous, steady under fire, dragon-scarred.
- **Craft** — the practical skills of daily life.
  - Skills: lockpicking, stealth, tracking, trapping, disguise, sailing, herbalism, smithing, bowyer, fletcher, carpentry, navigation, climbing, swimming, survival, bushcraft, wood lore, hunting, dogs, falconry, first aid, appraisal, rope use. Peasant weapons: knife, hatchet, wood ax, hunting bow, longbow, spear, club, sickle, scythe, grain flail, pitchfork, shovel.
  - Qualities: nimble, observant, patient, resourceful, quiet, cunning, light-fingered, sure-footed, raised in the fens, knows the woods.
  - Magic Schools: *Canting* (see below)
- **Heart** — people, nerve, and presence.
  - Skills: persuasion, intimidation, deception, leadership, empathy, trading, medicine, performance, streetwise, linguistics, riding, music, stagecraft, mimicry, ventriloquism, gambling, etiquette.
  - Qualities: charming, commanding, loyal, silver-tongued, well-connected, witty, jaded, honorable, commanding voice, lucky.
  - Languages: Northmaren, Southmaren, Eldarin, … (see below)
- **Sorcerie** — the unseen, and the schools that open it.
  - Qualities: perceptive, studious, second-sight, ancient-blooded, learned, haunted, witch-blood, marsh-lore, rune-wise, bookish.
  - Arts (not schools): divination, alchemy, binding, ancient lore — learned as Traits or from books, as the table prefers.
  - Magic Schools: *Sorcerie*, *Vitae*, *Elementale*, *Thaumaturgy*, *Illusione*, *Umbrakala*, *Necromantia*, *Canting* (see below)

### Arms and Armor (Sword)

Traits for weapons, shields, and armor are **Sword**. Write *arming sword*, *poleax*, *plate armor*, *heater*, *warbow* under Sword — never under Craft, Heart, or Sorcerie. The common folk may take *peasant weapons* under Craft, which are effectively "weapon-like tools" of the common man, hunting implements, and the like. (Examples: knife, hatchet, wood ax, hunting bow, longbow, spear, club, sickle, scythe, grain flail, pitch fork, shovel, etc.) The *longbow* is the yeoman's bow, learned at the village butts or in the lord's forest, so it is Craft. It is still trained-only. The warbow and heavy longbow are soldiers' bows, and stay Sword.

**Open kit.** Most weapons and armor work in a fight with no Trait — AC, slots, and blows as written. A Trait is still how you earn a Signature on that kit, and how enchanted steel accepts you.

**Trained-only.** Without a Trait for that kit, you cannot use it in a fight — no AC from the harness, no blows. The full list is every piece tagged Trained on [[Burners Arms and Armor]], and plate armor (*plate armor*). On that page today: greatsword; war sling; warbow, longbow, heavy longbow; siege arbalest; arquebus, flintlock rifle, handgonne; and the Dwur runelocks and thaumagonnes (Dwuringer pistol, revolver, pistol, holy water sprinkler, doppelpistol, dungeon sweeper, Thaumasweeper, carbine, longrifle, Thaumagonne, Thaumacannon). Buy-list: *Weapons, Armor, and Shields* below.

**Enchanted arms and armor.** Enchanted kit is trained-only — without the fitting Trait you swing ordinary steel (Slots, AC, faces) and the magic stays quiet. Full rule: *Enchanted Arms and Armor*.

### Languages (Heart)

**Common tongues**:

You've heard at least enough of all three trade tongues ("common tongues") to get by in daily communication; you can talk to innkeepers, buy gear from a shop, etc. Most Eldar and goblins in the wilds can do the same. A Trait in a trade tongue makes you fluent and literate in it — fit for courts, treaties, and books. Your Heart level determines your overall oratory and literary prowess.

- **Northmaren** — (Northman, Norn) the north: Alglonds, Lyonese, Kith lands, and the river kingdoms.
- **Southmaren** (Harnendorian, Harn) — the south and the seas; the trading tongue most nations use.
- **Eldarin** (the Elder Tongue) — old civilizations and the Eldar; nobles and diplomats often learn it.

When taking a Trait in a trade tongue, you can choose specific dialect: Alglond, Kith, Lothian, Avathar, Aquilan street cant, Ashenrise street cant, etc. In Eldarin dialects correspond to ancestry and region: Ithilrhi, Baal, Dwur, Alu, etc.

Other languages will be unfamilar to you unless you have a Trait; they are trained-only.

### Magic Schools (Sorcerie)

Magic schools are Sorcerie Traits, and trained-only. Hold the Trait and the school is open; without it you cannot read or cast that tradition. Spells inside an open school are still learned from **true writings**. The eight schools:

- **Sorcerie** — the common craft (raw grammar of magic). No Trait needed; being a Sorcerer is enough.
- **Vitae** — life, growth, harmony (Elves).
- **Elementale** — fire, weather, dragon-magic (Baal).
- **Thaumaturgy** — force, mechanisms, engineering magic (Dwur).
- **Illusione** — perception, thought, dreams (Belerions).
- **Umbrakala** — shadows, thresholds, paths between (Alu).
- **Necromantia** — death, spirits, decay (Avathars).
- **Canting** — the Darkman's secret hedge-magic. Tags to **Craft**, not Sorcerie. Its workings ride the local street dialect — flash paper, marks, patter — but most who speak that cant never cast a card.

### Starting Gear

You begin carrying the clothes on your back and a backpack. You also have a small knife, coin purse, and a firestarter somewhere on your person.

Your backpack takes 3 slots and contains: bedroll, waterskin, fifty feet of rope, one week rations, and a tinder box. You can move any of those items to your main inventory slots, but keeping it as a backpack means you can free up 3 slots by dropping it.

Your Approach also brings starting gold and its own kit or standing — see below. Spend what you keep in town from the tables further down; everything you carry ready takes an item slot.

**Starting kits are for new characters only.** The Veteran purse, Boss loyal retainer, Journeyman free tool, Sorcerer personal spellbook and Arcana — those are creation. When you later put a level into a different Approach, you gain the Approach and its title, not that Approach's starting gold or free kit. A Veteran who becomes a Boss does not wake a loyal retainer. A Boss who takes Sorcerie 1 does not get a free personal spellbook, Arcana, or starting spells — see *New Sorcerer in play* on [[Burners Sorcerie]]: **buy a blank personal spellbook (25 gp)**; costume Arcana 100 gp each if wanted; spells are not for sale as a catalog. Learn from **true writings** (scribe free, time only) or **ask a teacher to teach you something** (**1,000 gp × level** — the teacher chooses the working). A personal spellbook is crib notation for that sorcerer, not a party lesson. Waiting costs more than starting as a Sorcerer because you miss the apprentice kit. Re-split slots on rest when the new Approach needs it (Muster, Sorcerie slots).

### The Starting Veteran

Starting gold: 100 gp.

You know arms and armor. You can put together a proper kit, find working steel, and persuade its owner to sell. You carry yourself like a man-at-arms who has protected the realm. Guards recognize a veteran, not a wandering brigand. Your starting gold is the kit you have already earned in service — spend it in town to put that kit on the table.

A sample buy, 53 gp of your hundred, filling all twelve slots:

- Chain mail (AC 3) — 6 slots, 40 gp
- Backpack — 3 slots
- Arming sword — 2 slots, 10 gp
- Rondel dagger — 1 slot, 3 gp

Mail soaks 3 off every blow. Caught with the pack on, you roll only your level: 1 die. Leave the pack somewhere safe and the sword in your hand adds its 2, and the three empty slots add a light-kit die: 4 dice. The rondel rides the belt and gives nothing until it's drawn. Mail plus pack leave only three slots for steel, so the heater stays home until you drop the pack; carry it instead and you roll 6. Plate wants a Trait (*plate armor*); field and full plate are rare fitted harness. Full prices: *Weapons, Armor, and Shields* below.

At Sword 1 you are already a Veteran: two attacks a round. See *Veteran Attacks* under Combat.

### The Starting Boss

Starting gold: 80 gp.

A Boss starts rich in people, not in steel. Your starting gold outfits you and your first loyal retainer. Split your twelve as **9 physical + 3 Muster** at creation — room for a thin kit and three seats for today's crew. One Muster slot holds the loyal retainer; two sit open for the next hire. You may not re-Muster until your first 8-hour sleep or your first real job outfit.

Your kit is:

- 9 physical + 3 Muster — one Muster slot holds today's retainer; two open
- one loyal retainer Mustering: level 1, Sword 1 or Craft 1, half power (2 Traits, HP 1d3, Loyalty 10)
- the retainer has no coin of their own — every weapon, armor, and oddment they carry is bought from your 80 gp
- half-share of treasure recovered when they live (that is their pay)

A sample buy, 59 gp of your eighty — you light, them armored:

You (9 physical):

- Leather (AC 1) — 2 slots, 20 gp
- Short spear — 3 slots, 3 gp
- Backpack — 3 slots
- Empty — 1 slot

Retainer (from your gold):

- Leather (AC 1) — 2 slots, 20 gp
- Arming sword — 2 slots, 10 gp
- Heater shield — 3 slots, 6 gp

Your Fuel: pack off, level 1, plus 1 Muster die for the retainer's seat, plus a light-kit die for four empty slots — 3 dice. The spear isn't Heart gear, so it gives none; a mace or rod would. Caught with the pack on, 1. The retainer rolls its own Fuel when you play it: half level (0) plus its sword and heater — 5 dice. Muster slots hold people, or a rod or mace of command. A leader spends on their people — one purse, and it is yours. Manage, Loyalty, half power, and the rest of Muster live on [[Burners Muster]].

### The Starting Journeyman

Starting gold: 60 gp.

A Journeyman is both specialist and jack of all trades. You live in the world and understand it better than anyone else — the road, the woods, the trade, the tavern corner. All twelve slots are physical. Your starting gold is light because apprenticeship already gave you a tool of the trade tied to one of your Traits: a hunting bow with a quiver of arrows, a wood ax, a blacksmith's hammer, thieves' tools, a musical instrument, whatever fits the fiction. Pick that free.

A sample buy after the free tool, 23 gp of your sixty, filling all twelve:

- Hunting bow (free tool) — 2 slots
- Leather (AC 1) — 2 slots, 20 gp
- Backpack — 3 slots
- Dagger — 1 slot, 3 gp
- Empty — 4 slots

Your Fuel: pack off, level 1, plus the hunting bow's 2 in your hands, plus a light-kit die — 4 dice. Caught with the pack on, 1. Light kit, room for the road and what you find on it. Your Craft is how the band endures the wilds (see *The Journeyman's craft*).

A Canting Journeyman who takes the Canting Trait and walks that road declares 7 physical + 5 kicks — same slot-split rules as Sorcerie slots, different name — but starts with no spells and an empty hand until they learn Canting in play. See *The Canting Journeyman* on [[Burners Sorcerie]].

### The Starting Sorcerer

Starting gold: 40 gp.

A Sorcerer's craft comes with a kit (the fruit of your apprenticeship). That is why your starting gold is so much lighter than a Veteran's: you already spent most of it becoming a mage. Your kit is:

- 7 physical slots + 5 Sorcerie slots — declare the split at creation; you may not re-split until your first 8-hour sleep. Sorcerie slots set your hand size (5). They hold **Arcana** (staff, wand, rod, orb, crystal, ring, amulet, mask, robes, hat) at each item's full slot cost. **Books and scrolls** may ride physical or Sorcerie; they fill the slot. Never armor, shields, or war kit. See *Sorcerie Slots* on [[Burners Sorcerie]].
- One free Arcana — costume of the craft; pick one from the allow-list. Mundane grade; enchanted Arcana is still a find. Arcana in your Sorcerie slots gives its slots in Fuel; empty Sorcerie slots give none.
- A **personal spellbook** in a scrivener's satchel (book, ink pot, quill, loose-leaf paper): *Read Magic* plus four other 1st-level spells from your school, all known — apprenticeship already taught them (*Read Magic* is useful loot literacy, not the key to the other four). The Referee picks them, rolls them, lets you choose, or works with you. The book is kit (not the free costume pick); it may sit in a Sorcerie slot or physical. It is **crib notation** for **you**, not a lesson anyone else can learn from. Plain ink records Facts free; moving further spells into the book later costs time, not gold per spell (see *Spellbooks* on [[Burners Sorcerie]]).
- Your hand is all five known spells — ready to cast. Count them on your fingers.

A sample buy, 23 gp of your forty:

Sorcerie slots (5):

- Personal spellbook (kit) — 1 slot
- Wand (free Arcana) — 1 slot
- Empty Sorcerie slots — 3 (hand size still 5)

Physical (7):

- Leather (AC 1) — 2 slots, 20 gp
- Backpack — 3 slots
- Dagger — 1 slot, 3 gp
- Empty — 1 slot

Your Fuel: pack off, level 1, plus the wand's 1, plus a light-kit die for four empty physical slots — 3 dice. A staff (3 slots) would give 5. Caught with the pack on, 1. Sorcerie slots never count as empty. The magic is already yours.

Two of your school's six 1st-level spells are not in your personal spellbook. Those, deeper spells, other schools, and more Arcana are your hunt. Extra costume Arcana runs 100 gp apiece in town; enchanted Arcana stays a find. Found **true writings** you can read let you memorize that one working while they are in reach; scribing into your personal spellbook costs **time**, not 100 gp per spell — the true work remains. The personal spellbook is not a party resource — if you die, it does not teach the next mage. *Read Magic* identifies loot — it is not required to learn. See [[Burners Sorcerie]].

Canting rogues use the same split for kicks — see *The Starting Journeyman*.

### Weapons, Armor, and Shields

A weapon's **slots** are the space it fills and its reach: when held attacks go off together, more slots strikes first. In your hands, a weapon or shield your Approach covers gives its slots in Fuel (see *Burners (PCs)* under Combat). Melee weapons of 3 or more slots are two-handed: in two hands they hit harder but leave no hand for a shield. They can be used in one hand, without the extra attack die. A raised shield can count as **Cover** vs missiles. Armor **AC** soaks leftover after Defend. This is the starting character price list. Additional prices and oddments are in [[Burners Equipment]]. A fuller catalog of arms is in [[Burners Arms and Armor]].

| Weapon | Slots | Cost (gp) | |
| --- | --- | --- | --- |
| Dagger | 1 | 3 | can be thrown |
| Club | 1 | 3 | |
| Sling | 1 | 2 | ranged |
| Throwing ax | 1 | 3 | can be thrown |
| Small ax | 2 | 4 | can be thrown; includes bearded ax |
| Mace | 2 | 5 | includes war hammer, horseman's ax |
| Arming sword | 2 | 10 | |
| Short bow / hunting bow | 2 | 25 | ranged, two-handed |
| Short spear | 3 | 3 | two-handed; can be thrown |
| Longsword | 3 | 15 | two-handed |
| Longbow | 3 | 40 | ranged, two-handed |
| Crossbow | 3 | 30 | ranged, two-handed |
| Battle axe | 3 | 7 | two-handed |
| Hewing spear | 4 | 5 | two-handed |
| Greatsword | 4 | 15 | two-handed |
| Polearm | 5 | 7 | two-handed; includes halberd |

**Armor**: AC soaks leftover after Defend, one number by the make of the armor. Full prices are in [[Burners Equipment]].

| Armor | AC | Slots | Cost (gp) |
| --- | --- | --- | --- |
| Leather | 1 | 2 | 20 |
| Gambeson | 2 | 4 | 30 |
| Chain mail | 3 | 6 | 40 |
| Plate mail | 4 | 8 | 60 |
| Field plate | 4 | 5 | 2,000 |
| Full plate | 5 | 7 | 4,000 |

**Shields**: with the Trait, a shield takes its slots off a blow you Block (see *Block*); a raised shield can count as Cover vs missiles (2 dice on that Defend).

| Shield | Slots | Cost (gp) |
| --- | --- | --- |
| Buckler | 1 | 3 |
| Target | 2 | 4 |
| Heater | 3 | 6 |
| Rotella | 4 | 9 |
| Kite | 4 | 12 |
| Tower | 5 | 15 |

#### Training

Open kit, trained-only kit, and where those Traits live: *Arms and Armor (Sword)* under Character Creation. Enchanted kit and its free die: *Enchanted Arms and Armor*.

### Experience

Awards, the deed rule for treasure, present-only shares, Eldar track, and who tracks what: [[Burners Experience]]. You never buy Traits or spell learning with XP. Signatures emerge in play. Retainers take XP per [[Burners Muster]] (OSE half-share if not Mustering; Mustering seats split half of their Boss's XP).

### Approach Level

Your character level is bought with XP from the table on [[Burners Experience]] (Eldar use the Eldar column). When you gain a level, raise the Approach your four new Traits sit under by one (see *Gaining Traits*). You do not move points already set. At 4th level you might be Sword 3 and Sorcerie 1, or Sword 2 with Craft 1 and Heart 1, however your play has shaped you.

Your roll is 2d6 plus your Approach level. With no level in that Approach you are Approach 0: you still roll 2d6, just without a bonus. That missing bonus is the whole disadvantage. You can still attempt things at Approach 0, but that Approach's trained advantages stay locked until you reach level 1. One point is the line between a townsman and a practitioner.

### Titles

When you reach level 1 in an Approach, you earn its title. The title turns on that Approach's trained advantages. Below level 1 you have no title there and get none of them.

| Approach | Title | Turns on |
| --- | --- | --- |
| Sword | Veteran | extra attacks |
| Sorcerie | Sorcerer | cast from your hand; Sorcerie slots and Arcana; read magic |
| Craft | Journeyman | reduce party-wide travel, weather, and survival costs by your Craft level |
| Heart | Boss | **Muster** (1 slot per retainer); **Manage** (up to Heart); Loyalty |

**The Journeyman's craft (Craft 1+).** As a Veteran you rule the melee. As a Journeyman you rule the journey. Your Craft level reduces party-wide costs from travel, weather, and survival: cold, heat, hunger, thirst, exhaustion, forced marches, rough terrain, getting lost. When the Referee quotes such a cost, subtract your Craft level from it for everyone you are guiding. Often that drops the cost low enough that the Referee waives the roll. Example: traveling in the biting cold rain has a cost of 6 Heat, and you are a Journeyman with Craft 3 who has a deadfall shelter and a fire going. You cut it to 3. Without Craft 1+ you can endure the wilds yourself, but you cannot shepherd others through them.

**The Boss's command (Heart 1+).** As a Veteran you rule the melee. As a Journeyman, the journey. As a Sorcerer, the unseen. As a Boss, the Muster. Heart unlocks **Muster** and **Manage**. Anyone with coin can hire retainers; a Boss Mustering them plays them at the table — and those seats do **not** tax party XP (they split half of the Boss's award instead). Full rules: [[Burners Muster]].

## Alignment

Alignment is an Approach for when the fiction does not map cleanly to Sword, Craft, Heart, or Sorcerie. It is also for a **standing** tie to something bigger than a skill. The Referee names the axis. You count every Trait across all your Approaches that bears on it, **divide by 4, round down**. That number is your **Alignment level** with that axis for this roll or this bond.

**Situational Alignment** is the catch-all for the odd moment. Hauled before the Thieves' Guild masters, Heart is close but not quite. The Referee calls **Alignment with the Thieves' Guild** instead, counting canting, streetwise, that season you spent as a fence. Use a fixed Approach for ordinary rolls. Reach for situational Alignment only for the particular strange thing in front of you.

**Patron Alignment** is the same math. The axis is an otherworldly being: a god, saint, d'jinn, dead power, or thing from beyond the veil that has a True Name and a nature. Record it on your sheet when it matters: *Lunara 2*, *the Voice in the Void 1*. It grows the way everything in Burners grows. You take Traits that bear on the patron at level-up. You keep a **Relic** of theirs. You accept their shaping after a pact. You do deeds they favor. A Relic of the patron (their conduit, often named Arcana or another named item) counts as +1 Alignment with that patron for Invocations only.

| Alignment level | What it means at the table |
| --- | --- |
| **0** | Stranger. The patron may not hear, or the Offer is thin. |
| **1** | Known. Small favors, one clear Ask. |
| **2** | Favored. Serious Offers; shaping sticks. |
| **3+** | Saint. Their business is yours; see [[Burners Invocations]]. |

Patron Alignment is **not** Sorcerie. Calling on the patron — pageantry, True Name, Offer and Ask — is an **Invocation**. The full rules live on [[Burners Invocations]].

## HP and Armor

You have HP of one d6 per character level, rolled. Just 1d6 at first level. Reroll on each level-up for the higher of the new total or the old plus one. HP is not meat. It is luck, wind, and the reflex to turn a blow — **hit protection**. Blows come off your HP as near-misses. Only overflow **past 0** opens a **Wound**, driving your HP into the negative (see *Wounds*). That overflow adds to **wound severity**. At **0** you are out of luck, not yet cut — ordinary people have no hit protection and sit at 0 without being Wounded. If you cannot turn the blow, you are **helpless** — see the glossary.

Armor is what you wear. Defend first; leftover, its AC soaks, rest to HP. AC runs from 1 to 5 by make: leather 1, gambeson 2, chain mail 3, plate mail and field plate 4, full plate 5. Heavy harness eats more of your twelve and leaves less room for steel. Armor gives AC, not dice. Leather, gambeson, and mail are open. **Plate is trained-only** (see *Training* under *Weapons, Armor, and Shields*). Armor keeps you from being worn down, not from being cut once you are down. In heavy armor you lose HP slowly, but the Wound you take past 0 is raw.

## Traits by Approach

See *Traits* under Character Creation.

## Sample Party

- **Aldric**, Sword 1 (Veteran). "Seen too much to flinch, too little to quit."

  - 4 HP and chain mail (AC 3): every blow he takes is shaved by 3 before it reaches him, so he wears down slowly and is hard to drop. Past 0, his Wound is raw like anyone's.

  - Traits: arming sword, shield, plate armor, ambush (Sword).

  - Held: arming sword and a buckler.

  - Signatures: none yet, a plain tough veteran waiting for a habit to harden into one.

- **Senna**, Sorcerie 1 (Sorcerer). "Reads the world like a book nobody else can open."

  - 4 HP and leather (AC 1). With **Approach 0** in Sword her defense is thin and her HP goes fast, so she survives by staying out of reach, not by soaking blows.

  - Traits: marsh-lore, second-sight, witch-blood, Vitae (Sorcerie).

  - Hand: *Read Magic*, *Healing Touch*, *Stanch*, and two other 1sts from her book — all five ready. *Stanch* is the card that helps at 0 HP or less; *Healing Touch* does not.

  - Split: 5 Sorcerie slots (hand size 5), 7 physical — personal spellbook + one free Arcana (wand) in Sorcerie slots; the rest plain kit.

- **Pip**, Craft 1 (Journeyman). "Has never been caught. Not once."

  - 4 HP and leather (AC 1). Like Senna, he relies on not being hit rather than on soaking blows.

  - Traits: stealth, lockpicking, disguise, nimble (Craft).

  - Signature: Mizzle (on his stealth), slipping away unseen the moment a scene turns against him.

- **Mara**, Heart 1 (Boss). "Pays in coin and reputation. Collects both."

  - 5 HP and leather (AC 1). Split: **9 physical + 3 Muster** — Nell Mustering (1 slot); two open.
  - Sword 0 — one attack; *spear* Trait only (no Veteran extras).
  - Traits: leadership, streetwise, intimidation, loyal (Heart); *spear* (Sword).
  - Held: spear. Coin kept back to outfit Nell. Re-Muster locked until first sleep.
  - Loyal retainer: **Nell** — level 1, Sword 1, Traits *spear* and *steady under fire*, HP **1d3**, Loyalty **10**; see [[Burners Muster]].

## Signatures

Your Signature is an asterisk on the Trait it springs from: a knack that showed up at your table. You earn one per level in that Approach. Eldar may earn two per character level instead of one ([[Burners Experience#Eldar]]). (Retainers earn at most **⌊Approach / 2⌋** — see [[Burners Muster]].)

Signatures take four common shapes; the Referee may allow others:

- **Named item.** You name a weapon, shield, armor, or tool on a Trait you already hold (*arming sword* → *Naurdring*; *hunting bow* → *the fen-bow*). That name **is** the Signature: put the asterisk on the Trait. For arms and armor, see *Enchanted Arms and Armor* below.

- **Named companion.** A trained animal on a Trait you already hold (*warhorse* → *Bracken*; *dogs* → *Rook*). That name **is** the Signature. Ordinary pack and riding stock needs none — buy them, ride or load them; they stay off your twelve ([[Burners Equipment#Animals and mounts]]). They are not retainers and do not take Muster slots. If yours is gone, train another when you can and change the name.

- **Instinct.** Something you always do becomes a thing that never fails you. Back to the wall, and nothing flanks or surprises you from behind. Poke the chest with a ten-foot pole first, and its traps never catch you. The habit is the trigger; honor it in the fiction and the edge is automatic.

- **Holdout.** A small thing you keep hidden on your person: a boot knife, a flint sewn into your collar, an accelerant vial stitched into a sleeve. Name it and say where it rides. It lives outside your twelve slots and stays with you even when you are searched or stripped of gear. Out of combat it is free to reach. In a fight, drawing it costs one Fuel.

## Enchanted Arms and Armor

**Enchanted, legendary, eldritch, magic** — same class. A module *+1 sword* is a magic sword: woken steel, not a mild bump. It may hum, light the dark, hate a quarry, or speak. The plus is how you stock it (see [[Burners Referee Magic Items]]), not how small it is.

**Acceptance.** The enchantment only answers someone who holds the fitting **Trait** for that kit — *arming sword*, *chain mail*, *hunting bow*, *heater*, and so on. That is not a roll. The blade accepts you or it does not. Without the Trait you may still carry and swing the steel as ordinary kit (Slots, AC, faces); the magic stays quiet — no free die, no powers. Most war Traits sit under Sword, so Veterans usually claim the magic steel. A Journeyman with *hunting bow* can still be accepted by a magic hunting bow.

With the Trait you are accepted: the item gives you **one free die each round**, rolled when you use it, and its **powers** once you have found them. A weapon's die goes on a blow; a shield's or armor's on a Defend. Burn your Fuel, then roll the free die and add it. It is not Fuel: it doesn't count for Initiative, it can't go anywhere else, and if you haven't used it by the next Roll Initiative it's gone. It comes on top of the dice you burn, past any limit on the blow or the Defend. A 6 on it is a 6 like any other. Magic steel is not steady: some rounds it sings, some rounds it barely wakes.

A **Named item** Signature on that Trait (your steel, named) is the same acceptance — the name marks it as yours.

**Sentient** blades are enchanted kit that also have a will (see [[Burners Referee Magic Items]]). They still require the Trait to accept you as a wielder; personality, jealousy, and speech sit on top of that.

See [[Burners Referee Magic Items]] for stocking and +n.

---

## Part Two: Playing

### The Two Steps

#### Step 1: Say What You Do

Say what you do, and how you do it. *I ease the tumblers with my picks.* Not *I try to pick the lock,* and not bare *I pick the lock* with no method.

The Referee rules one of three ways:

- If the plan is sound and fits who you are, it works. No roll.
- If it has no chance, it fails. No roll.
- If it could work but is risky, go to Step 2.

Your Theme and Traits help the Referee see that you could do it. They do not skip the roll on their own. Weave a Trait into what you say so the table hears how you do it.

#### Step 2: Name the Risk

A risky deed has a Risk, a number the Referee names. What could possibly go wrong? Make an Approach roll against it.

You still do the thing. The dice say how much of the Risk sticks. Unpaid Risk is **Heat**: banked now, spent by the Referee as consequences now or later. When the bite is on a body, they may convert Heat into HP (see *Heat* in the glossary). A Spicy twist may ride alongside.

You roll when there is a Risk, or when the outcome is uncertain.

### Approach Roll

When the Referee asks for a roll, they name the Risk. Name your Approach.

Roll 2d6 and add your Approach level. Meet or beat the Risk and you do it clean. Fall short and the shortfall is **Heat** — marked now, spent by the Referee when the consequence fits (including as HP when the peril is personal).

There is no separate birthright to withstand a danger. You endure with the same four Approaches you act with. When a hazard tests you, pick the Approach the danger asks for and roll against the Referee's Risk:

- **Sword:** hold your feet, stay conscious under a wound.
- **Craft:** force a door; dodge what you cannot fight: a dart, a pit, a floor giving way, a creeping poison.
- **Heart:** hold your nerve against fear, a charm, a horror from the dark.
- **Sorcerie:** shrug off a mind-magic and dredge up what you know.

Where none fits, work it as an Alignment (see Alignment). Hostile magic in a fight uses Fuel Defend against the caster's cast total — see [[Burners Sorcerie]].

#### Sweet & Spicy

Out of combat:

- One 6 or one 1 is a single twist, good or ill.
- Double Sweet (two 6s, a natural 12) is the perfect roll: the best outcome the fiction allows.
- Double Spicy (two 1s, a natural 2) is a fumble: the worst fitting outcome lands.

Combat has no Sweet or Spicy, and nothing fumbles. A 6 in Fuel is a **Spark** (see Combat), or more with an Arcana you have the Trait for (see *Your 6s* under Combat). A 1 is a low die.

**Surprise** on round 1: the Referee rolls; a surprised side is dead last in Initiative order that round. No other effect — Fuel and Actions stay. Round 2+ is normal. Being caught or outmaneuvered may still add a situational Damage modifier — you defend as normal against the higher number.

A coup de grace finishes a **helpless** foe outright — no Defend, no HP. See *Helpless* in the glossary.

### Wounds

You take a **Wound** when:

- an attack drives you **below 0 HP** (overflow past 0) — steel, claw, or the walking dead alike;
- or harm lands where **HP cannot help** — **helpless**, some poisons, module specials (Referee's call).

Resolve each Wound once, then carry it. Wounds accumulate. Penalties last until you reach **full HP** (maimings excepted). A blow that lands you **exactly at 0** spends the last of your luck; you are not Wounded until a blow drives you negative. A Wound from the **Fallen** (undead) — see [[Burners Referee Guide#Undead]]. Lore: [[Burners Burn Undead]].

**Wound severity.** Keep a running total for the fight: for each attack that caused a Wound, add its **overflow** past 0 (damage that drove you below 0 after armor). Non-HP Wounds (where HP cannot help) add **0** unless that same attack also overflowed HP.

1. Find the location. Use a named spot if someone called it, or roll 1d6: 1 head, 2 torso, 3 waist, 4 arm, 5 hand, 6 leg. A limb is left or right, by the fiction or a coin, and a hit takes one limb.

2. Deepen the tally. If the blow drove you below 0, your HP goes that far negative (armor already soaked leftover after Defend). The negative tally is flesh; it accumulates. Severity for the fight rises by that overflow.

3. Apply the location effect. A vital wound leaves you up and fighting but carries a location effect. A limb wound disables that limb.

4. **Shock Check** — immediately. This asks whether you stay **combat-effective**, not whether you die.

#### Location effects

- **Head, reeling.** Tunnel vision. You engage and defend only what is directly in front of you, and any foe you cannot see strikes you as if you were surprised (no shield or parry against them). Mild against one foe, deadly when you are surrounded.

- **Torso, winded.** The blow knocks the wind out of you: lose one Fuel die at once. If your pool is already empty, you top off one die short next round instead, so the hit always tells, but once, not forever.

- **Waist, collapsed.** You are in the dirt and cannot stand up until you reach **full HP**.

- **Arm or hand.** That limb is unusable. A weapon arm cannot attack; a shield or off arm cannot use a shield.

- **Leg.** You go in the dirt and cannot stand up until you reach **full HP**, the same as a waist wound.

**In the dirt** — see *In the dirt* under Combat. A waist or leg wound holds you down until **full HP**; you cannot rise before then. Being in the dirt does not stack, however you ended up there. A fresh, untended wound also makes that spot a soft target. A blow called at an already-wounded spot deals 2 extra damage until you reach **full HP**.

#### The Shock Check

Every Wound puts your footing in question. Roll **`2d6 + Sword` against total wound severity** this fight. Meet or beat it and you keep fighting, shaken. Fall short and the shock lands — read the raw 2d6 on the table below (worst at the bottom). Natural **1+1 always fails**; natural **6+6 always succeeds**, whatever the severity.

| 2d6 | Shock |
| --- | --- |
| 2 | Knocked out, and the wound bites deep: add the shortfall to your negative HP (and to severity). |
| 3 | Knocked out: down, out of the fight, senseless. |
| 4 | Knocked out: down, out of the fight, senseless. |
| 5 | Sprawled and disarmed: knocked into the dirt, and you drop what you hold. |
| 6 | Sprawled: knocked into the dirt (see *In the dirt*). |
| 7 | Stunned: you lose your next Action. |
| 8 | Winded: lose one Fuel die at once, or top off one die short next round if your pool is empty. |
| 9 | Staggered: driven back out of reach, and a foe may step after you. |
| 10 | Disarmed: you drop what you hold. |
| 11 | Rocked: you keep your feet, shaken but still fighting. |
| 12 | Unshaken: shrug it off, and rise for free if you were already in the dirt. |

If you have nothing to drop (you're unarmed or casting), the Referee swaps a disarm result for a fitting shock instead: a spell guttering out, a lost hold, a wasted breath.

**Mid-tempo disrupt.** While you are in a **non-melee** Action — cast, shoot, flee, climb, drink, rise, and the like — a blow that **Wounds** you triggers the Shock Check as usual. The blow may be a **Counterattack** or any other hit that catches you mid-act. **Fail that Shock** and the Action breaks: spoiled, unfinished, or gone wide (a cast taps with no effect, aim is lost, a climb fails). Pass, and you keep your feet in the act — HP loss alone does not abort it. A melee attack is never spoiled this way; the blow already is the Action. HP loss and Wounds still land, simultaneously.

#### Going Down

A downed ally is knocked out, not dead — until a coup de grace finishes them, or the fight ends without help (below). Win the fight and get them help.

#### After the fight — survival

After **any fight in which you took a Wound**, you **die** unless you receive **help** in time (an ally's Action, first aid, *Stanch*, Vitae, or other care the Referee accepts).

Helped, you make a **survival check**: **`2d6 + Craft` vs total wound severity**. An ally who assists may let you use **their Craft** in place of yours. Natural **1+1 always fails**; **6+6 always succeeds**. Fail, or go unhelped → **dead**.

#### Healing and recovery

**Full HP closes wounds.** Maimings at the brink do not heal on their own.

- **Hour Rest** (one hour, food and water): recover **all HP** to maximum — **only if you have no Wound**. If you are Wounded, Hour Rest does nothing for HP until you are whole again. HP lost to undead does not fill on Hour Rest until magical healing or Purge — [[Burners Referee Guide#Undead]].
- **Wounded:** recover **1 HP per day** naturally (safe rest with food) until **full HP**, then the Wound closes. *Stanch*, other Vitae, potions, and chirurgeons can restore HP sooner; *Healing Touch* does not help at **0 HP or less** — that is *Stanch*. An **aggravated Wound** (undead, disease, moon-sick, and the like) ignores ordinary recovery — natural climb, Hour Rest, and normal healing spells/potions do not improve HP until the Wound is cleared (Purge / Cure Disease / the fitting cleanse). See [[Burners Referee Guide#Undead]].
- **First aid** (Craft): tends a wound in the field; it does not restore HP by itself, but can be the **help** that lets you attempt the survival check.

*Example. Aldric (Sword 1, maximum 4 HP) is driven to −3 by a blow of overflow 3: Wound, severity 3, leg — in the dirt. Shock (`2d6 + Sword` vs 3) beats it; he stays effective but in the dirt. After the fight an ally helps; survival (`2d6 + Craft` vs 3) succeeds. He climbs 1 HP per day (−2, −1, 0, 1…) until full 4; then the Wound closes. Hour Rest would not have filled him while Wounded.*

The danger is the Wound. Every one is a Shock Check in the fight and a survival check after. Cover downed friends. Reach full HP and you are whole again.

*The crew fights an ogre in a working scene.  Aldric (Sword 1, 4 HP, chain mail AC 3, arming sword, buckler) rolls Initiative. His sword (2) and buckler (1) give three dice, and his level one more, so his Fuel maximum is four. He rolls 6, 4, 3, 1. Two show 3 or 4, so his Initiative is 2. The ogre's group rolls **1d6** = **2**. Aldric matches it, so he goes before the ogre. On his turn a Veteran gets two attacks. With a one-handed sword (2 slots) each is a single die. He burns the 4 at the ogre and holds his second attack to Block. The ogre wears hides, as leather (AC 1); his sword's 2 slots beat it, so +2: 4 + 2 is 6, two cards off the ogre's Monster Stack (HD 4 → 8 cards). Then the ogre's club comes: free quote **5**, pressed with a 5 from the Referee's dice for **10**. Aldric spends his held attack to Block. He burns the 6, and he has the Trait for his sword (Parrying, 2 slots) and his buckler (1 slot), so they take 3 more off: 10 − 6 − 3 = 1, and his mail soaks it. The 6 Sparks, so he Fuels a Counterattack with the 3: 3 + 2 is 5, one more card. He keeps the 1, and the next Roll Initiative tops him back up to four. Over the following rounds the ogre is worn down; Aldric is bloodied but standing.*

When you face control magic, you **Defend** the same way you defend a blow, but a clean overrun lands the effect (stun, hold, charm, sleep), not HP damage. See *Defending against a spell* in [[Burners Sorcerie]].

### Combat

Each Combat Round is one minute. You act in locked Initiative order. On your turn you get one Action: attack, cast, or feat. Moving, readying, taking cover, or aiming come with it, part of the same Action rather than a turn of their own. Only a demanding shift (rising from the ground, or breaking away under threat) costs you the Action itself. Defending is not free. You burn Fuel whenever you are struck.

**Rolling Initiative.** Say **Roll Initiative** at the top of every round. No one declares actions before the roll. You fight with what you were actually carrying.

**Burners (PCs).** Your Fuel maximum is your level plus your gear dice: the slots of each item your Approaches cover with their Traits, counting the weapons and shield in your hands and your Arcana. Sword covers weapons and shields. Sorcerie covers Arcana. Craft covers its own, like the longbow, the fighting staff, and the buckler. Heart covers the rod and the mace. A Sorcerer gets no dice for a sword unless she has a level in Sword. Armor gives AC, not dice.

**Light kit.** Three or more empty slots give one more die, the light-kit die. One or two give none, and it is never more than one. Muster and Sorcerie slots never count as empty. Count it all from what you carry when Initiative is rolled.

A level 1 Veteran with a trained arming sword (2) and heater (3) rolls 6. With a greatsword (4) she rolls 5: one big two-handed blow and Defend three times, or two big blows and one Defend. A Sorcerer with a staff (3) rolls 4.

**Muster dice.** A Boss adds one die for each filled Muster slot: a retainer in the seat, or a rod or mace of command carried there. Burn them for any of your Mustering retainers, any time, on their attack, Defend, or other action. Handing a die to the one who needs it, when they need it, is the art of command.

**Which dice go where.** Weapon and shield dice go on fighting: blows, shots, Blocks, and Defends. Arcana dice go on casts and Wards. Muster dice go on your people. Level dice go anywhere. This only matters with more than one kind: roll each kind in its own color.

**Drop it, lose its dice.** Drop an item, stow it, throw it, or have it knocked away, and lose dice equal to its slots. It stops adding to your top-off, too. If you can't tell which dice came from it, drop that many and re-roll the rest of your hand.

**Pick it up, draw it.** A weapon you pick up or draw mid-fight gives no dice now. From the next Roll Initiative it adds 1 to your top-off if you have its Trait.

**Your pack.** Leave your pack in a room that feels safe. Caught with it on, your maximum is only your level. Dropping it mid-fight takes your Action; from the next Roll Initiative your gear counts again.

**Fatigue.** In a long fight, fatigue fills one of your empty slots, then another, as you tire. A day without food or a night without sleep fills one too. Fall below three empty slots and you lose your light-kit die from the next Roll Initiative. With no empty slot, drop something to make room. Rest, food, and sleep clear it.

Round 1: roll your maximum. The faces you rolled, kept as they lie, are your Fuel for the fight. Your **Initiative** is the count of them showing 3 or 4.

**Round 2 and after (PCs).** Roll Initiative means top off: keep the dice you didn't use, and roll your level in new dice, plus 1 for each counted item you have the Trait for, plus your light-kit die if you still have three empty slots. Your pool never grows past your maximum. Then count 3s and 4s across the whole pool. Spending a 3 or 4 during the round does not change the locked order — only the next Roll Initiative does.

**Foes.** Each distinct enemy group rolls **1d6** every Round Initiative (orcs one die, ogre another). Reroll each round. If a monster's text says **shambling** or **acts last**, skip the die and go last. Do not roll Fuel for order.

**Surprise (round 1 only).** The Referee rolls to see if either side is surprised. A surprised side is dead last in Initiative order that round. No other effect: nobody loses their Action, and PC Fuel is unchanged. From round 2 on, surprise is over.

**Lock order.** The Referee names the number the monsters act on (each distinct group rolls **1d6**, or shambling / acts last). Match or beat it and you go before them; fall short and you go after. Within before or after, players coordinate and act in any order they wish.

If you go before the monsters, the whole Action is yours then — move, position, strike, cast, all of it.

**Holding.** Hold your move, your Action, some of your attacks, or any mix of them, and use them when something happens. The rank behind holds its move and steps up when the front foe falls, or burns a 6 to attack past the friend in front (see *Finding an opening*). A fighter in a doorway holds his attack and strikes the first one that steps into reach. An archer holds her shot until her friend is out of the line. A Veteran with a longsword strikes once now and holds the other: "My weapon's longer. As he steps up, I stick him."

Holding doesn't make you first. When a held attack and a foe's attack go off together, the longer weapon strikes first: more slots is longer. Same slots, they land together. Against a hewing spear (4 slots), the Veteran's longsword (3) is still stuck first.

*Example. Orcs roll 4. Kragg Initiative 5 goes before; three allies at 2 / 1 / 1 go after, in whatever order they agree.*

If you empty your hand on offense you are caught winded until the next Roll Initiative, blows arriving whole in the meantime. Burn with that in mind. Fuel you are forced to lose but cannot burn from your pool comes off your next top-off instead: you top off one die short. Such a cost always lands, exactly once, and never leaves you owing a debt you cannot pay.

**Burning Fuel.** Everything you do in combat burns Fuel. You must burn Fuel to attack, defend, cast, and so on. A die is used at its face and discarded. No reroll. The pool you play is the faces you rolled.

**Your 6s.** When you burn a 6 on a cast or a Ward using an Arcana you have the Trait for, you may take your gear instead of the Spark: add the Arcana's slots, free. Each Arcana adds its slots once per cast. Taking your gear is instead of the Spark, so that 6 strikes nothing else. Roll two 6s and one may take your gear while the other Sparks. In the dirt, the re-rolled face stands: a re-rolled 6 may take your gear. A cursed Trait never adds slots. A 1 is just a low die.

Weapons don't add on a 6: their slots already count against the foe's armor on every blow (see *Monsters*). Shields and Parrying weapons give their slots when you Block, on any face (see *Block*).

A **Parrying** weapon parries by its shape: swords, the langes messer, the parrying dagger. When you Block, it takes its slots off the blow, like a shield. A weapon without the tag (dagger, axe, mace, spear) takes nothing off.

**Sparks.** A natural 6 in your Fuel is a **Spark**: the opportunity to do something more. A Spark can follow a 6 you just burned on an attack, Defend, cast, or other action — resolve that action first, with the 6 counting normally. Or you may burn a held 6 solely to strike a Spark and jump straight to what follows. Either way, immediately **Fuel the Spark** with the additional Fuel its option requires. That Fuel powers the follow-on action: you do the Spark. Add no Fuel and the Spark fades, unless the option says the Spark itself is fuel enough. Or, if the 6 went into a cast or Ward with an Arcana you have the Trait for, take your gear instead: add its slots, free (see *Your 6s*). Roll several 6s and each may Spark.

- **Spark: Flurry.** When attacking, Fuel the Spark to attack again (burn Fuel as for a normal attack); armor applies normally.
- **Spark: Man-handle.** See *Man-handle*.
- **Spark: Impale.** When attacking with a Stabbity weapon (dagger, rondel, short sword…), Fuel the Spark to thrust deeper into the same spot; armor does not soak the Fuel you burn to Fuel it.
- **Spark: Sever.** Only vs foes with **too many parts** — octopus, spider, hydra, swarm-limbs, and the like. When attacking with a Cutty / chopping weapon (poleax, battle ax, greatsword, cleaver…), Fuel the Spark with 1 Fuel to hack off one spare limb or head. That part's attack is gone for the fight. Not for ordinary humanoids. Soft many-part pests may simply drop a segment and flee. No longer applicable when the number of extra parts runs low (one neck left on a hydra).
- **Spark: Past them.** Burn a 6 to get an attack past someone in the line, friend or foe, to your target. The 6 is a cost, not the blow's damage. Without it the attack hits whoever is in the line. See *Finding an opening* under *Friction*.
- **Spark: Counterattack.** After a Defend Sparks (except under Cover), Fuel the Spark to strike (burn Fuel as for a normal melee attack). The Spark buys the attack; see *Counterattack*.

**Attacking.** You make one attack a round (as a Veteran you make more; see below). Burn one Fuel die; its face is the damage. A two-handed weapon of 3+ slots wielded in two hands can burn a second die. In one hand it burns one. The second die is for a full swing or thrust with nothing in the way: not past someone in the line, not in a crawlway or a tight press, not through bars or over a wall. Hindered, it burns one. Up to two dice a blow from mundane steel, all burned from your Fuel, their faces together the damage. Against a Burner: Defend first, then leftover, armor soaks, rest to HP — past 0 the overflow is a Wound. Against a monster: compare your weapon's slots to its armor, and the Referee converts the damage (see *Monsters* in the glossary). With the weapon's Trait, round the cards up; without it, round down. A trained hand always bites; an untrained one needs a big blow. Because armor soaks leftover on every blow, a flurry of small hits is how you cut down an unarmored Burner; heavier steel cracks plated kit. Hunting bows and other 2-slot arms stay one die.

**Veteran Attacks.** As a Veteran you strike more than once: one extra attack per Sword level. At Sword 1 you make two. At Sword 3 you make four. Each is its own blow of its own dice, all inside your single Attack action. Each may fall on the same foe or spread across several. Any of these attacks may instead be spent to **Block** a blow at you or an adjacent ally, or held for a **Counterattack**.

**Defending.** There is no defense roll. Blows land. Burn Fuel dice and cut the incoming Damage by their faces. Leftover, armor soaks; anything still left comes off your HP. Caps: **melee** — one die, or no limit if you made a melee attack or a Block this round (any foe); **missile** — one die, or two if you have Cover; **hostile magic** — no limit (Defend against the cast total; overrun may land control instead of HP — [[Burners Sorcerie]]). Fire from an incendiary is an area effect, not a defended blow — [[Burners Arms and Armor#Incendiaries & Alchemy]]. While **in the dirt**, same caps — but all Fuel burned must be re-rolled. If a natural 6 Sparks while defending, you may **Counterattack** (except as under Cover). If you're the archer or mage caught in reach without having meleed, you cut each melee blow with a single die.

*Example — dirty fighting. Aldric's Fuel is a ruin: 2, 2, 1, 1. The ogre's club is coming for 13 and he has already meleed, so he may Defend without limit. Those faces will not cut 13. He throws himself in the dirt (free with what's left of the exchange). He dumps three dice into the Defend; each re-rolls: 5, 4, 6 = 15. Club stopped — the 6 counted on the Defend and Sparks. The Spark buys the Counterattack; he Fuels it with his last die (arming sword: one die), re-rolled in the dirt to 1. A nick from the floor. Cinema. Next he still has to rise under the press — Friction, one Fuel the ogre can counter — or keep scrambling in the dirt.*

**Block.** Spend an attack to meet a blow aimed at you, or step in front of one aimed at an adjacent ally; that blow redirects onto you. Hold the attack if the blow hasn't come yet. Defend it as normal, then your shield and Parrying weapons take their slots off what's left, each one you have the Trait for. Armor soaks the rest. One attack covers one blow. A Block counts as a melee attack for the Defend cap: having Blocked, you Defend without limit for the rest of the round. A Block's Defend can Spark like any other.

| When you Block | Takes off |
| --- | ---: |
| No Parrying weapon or shield | 0 |
| Parrying dagger, buckler | 1 |
| Arming sword, sidesword, target | 2 |
| Longsword, heater, round shield | 3 |
| Greatsword, rotella, kite | 4 |
| Tower | 5 |
| Sword and buckler | 3 |
| Sword and heater | 5 |
| Sword and tower | 7 |
**Counterattack.** When a foe in reach does something other than a melee attack — cast, shoot, flee, drink, rise, and the like — a **Veteran** may spend a melee attack at the same time. Resolve it as a normal melee attack (burn Fuel) simultaneous to the action.

When you are both meleeing, there is no free Counterattack — their swing is steel meeting steel. The opening comes only if a Defend **Sparks** (except under Cover). The 6 already counted on the Defend; the Spark buys the attack (it does not spend from your attack allotment). Fuel it — burn Fuel as for a normal melee attack — to strike.

Wound + failed Shock may break a non-melee Action — see *Mid-tempo disrupt*.

*Example — Counterattack. A cultist in Kragg's reach turns to cast. Kragg (Veteran, longsword) held one attack; he spends it and Fuels a normal two-handed blow — 5 and 4 for **9**, simultaneous with the cast. If that Wounds and the cultist fails Shock, the working breaks mid-tempo. Later, steel on steel: Kragg Defends an orc's cut, a 6 Sparks. The Spark buys the attack; he Fuels it with 6 and 3 for a Counterattack of **9** — no attack from his allotment spent.*

**Cover.** Fiction that lets you burn two dice vs a missile (wall, raised shield, creature…).

**Line of attack.** An attack hits the first one in its line, friend or foe. A blow from the rank behind hits the friend in front. A shot at the archer behind the shield wall hits the shield wall. Whoever is in the line takes it as if aimed at them, and Defends as normal. To get past them, see *Finding an opening* under *Friction*. A blow past someone is one die, never the two-handed second; a shot keeps its dice.

**Friction.** Some moves are hard to pull off, so you burn one Fuel to try them, and you can't burn again. If a foe counters with more Fuel, the action fails or goes awry. The Fuel is the cost of trying: it adds nothing to a blow's damage.

**Drawing under pressure.** Burn one Fuel to draw or pick up a weapon with a foe in reach.

**Unarmed vs armed.** Burn one Fuel to make an unarmed attack against an armed opponent.

**Standing up.** Burn one Fuel to rise from the dirt with a foe pressing you in melee.

**Finding an opening.** An attack normally hits whatever is first in its line: friend, foe, or wall. Burn a 6 to shoot, strike, or cast past it: into a melee, from the second rank, around a cart or the shield wall in front of their sorcerer. In a minute of fighting, that is the opening you waited for. Say how: over a shoulder, under an arm, a roll between their legs and back out. Any weapon will do. Partial cover, like a low wall, does not need a 6. A shield wall can count as cover.

**Ward.** A **Sorcerer** (Sorcerie 1+) adjacent to an ally or a tight group may cut hostile magic aimed at them — a spell's cast total, magical breath, and the like (not mundane fire alone). Burn up to your **Sorcerie Level** in Fuel; subtract those faces from the attack value. **Each ally then Defends** against what remains. No school Trait; no card. A 6 burned with an Arcana you have the Trait for may add its slots instead of Sparking (see *Your 6s*). Not your Action — Ward rides the incoming working. Craft-only Canting Journeymen cannot Ward. Full cast procedure: [[Burners Sorcerie]].

**In the dirt.** Flat on the ground — a risky place. **All Fuel burned while in the dirt must be re-rolled** (blow, Defend, cast, Block, Man-handle, Counterattack); the new face is what counts. You may **throw yourself in the dirt** free with your Action when the pool is trash and you need a scramble. **Rise** free on your Action unless a foe presses you in melee — then rising is Friction (see *Standing up*): burn one Fuel, and if a foe counters, you stay down. No die to spare? You top off one die short next round. A waist or leg Wound holds you down until **full HP** (see *Wounds*); you cannot rise before then. Being in the dirt does not stack.

**Man-handle.** Fuel a Spark to "man-handle": shove, grab, trip, or knock down, or otherwise grapple/wrestle a foe. If not fully defended, the target winds up in a poor position, such as down on the ground, a pinned weapon arm, etc. Armor does not count as defense here (no soak). It can still make them hard to move — bronze in the water, a bear, four at once — and that is free defense dice. A strapped shield brought to bear is one free defense die, and a Man-handle can pin it but never tear it away. A center-grip shield can be torn away. See *Shields* in [[Burners Arms and Armor]]. Fuel for man-handling attacks and defenses is normally limited to 1 die, or 2 dice if both hands are free. Wrestling a smaller person is easier; wrestling four foes is hard — give each of them a free defense die. One Spark can shove a knot if it is one move (a sweep on a span); each Defends the same force. A fat shove (two dice, a 7) beats a single defense die — they all go in. A 6 on that die still Sparks even as they fall; Fuel a man-handle and they may take you with them. See *In the dirt* for the effects of putting a foe on the ground. A Spark on defense enables a counterattack normally, which could be a man-handle. Fully Defended means the shove fails — you do not swap places because they rolled higher. They throw *you* only if that Defend Sparks, they Fuel a man-handle, and you fail to fully Defend it.

**Constrict.** Some monsters have special attacks that man-handle and deal damage at the same time, a giant crab's pincer, an octopus tentacle, coils of a serpent. If not fully defended the target is man-handled and takes damage. Armor only applies to reduce damage after seeing if the attack was fully defended, so it does not help avoid the squeeze.

**The Referee's hand.** The Referee may always deal less damage than a blow could do when the situation calls for it. In the same spirit, the Referee may rule that a monster's special attack (poison, a grab, a level drain) lands only on a Spark rather than on every hit.

### Armor

Armor is what you wear; leftover after Defend, its AC comes off before HP.

- Leather, gambeson, and mail. AC by make: leather 1, gambeson 2, chain mail 3, plate mail and field plate 4, full plate 5.

- Leather, gambeson, and mail are open. **Plate** (plate mail and above) is trained-only: see *Training* under *Weapons, Armor, and Shields*. Heavy armor eats into your twelve. If you armor up you carry and move with little to spare. If you travel light you keep three empty slots for the light-kit die, and room for loot and fatigue. Armor gives AC, not dice.

- Armor is one number in ordinary play, with no hit locations.

- A shield is not armor; you hold it, not wear it. Held, it gives its slots in Fuel if your Approach covers it. A raised shield can count as **Cover** vs missiles (2 dice on that Defend). When you **Block**, a shield you have the Trait for takes its slots off the blow.

### We Burn Undead

Wounds inflicted by the Fallen (undead) fester and fell the victim, who joins their dismal ranks. The Fallen burn cheerily in **fyre**, and fear naught else. [[Burners Burn Undead]].

## Magic

Spells are **cards** in a hand sized by your Sorcerie slots (or kicks, for Canting). The Sorcerer title (Sorcerie 1) lets you cast; in a fight that is one Action burning at least SL Fuel for the cast total. Hostile magic is Defended like steel. Full rules: **[[Burners Sorcerie]]**. Catalog: **[[Burners Spells]]**. Canting Journeymen walk the same road under Craft.

### Relics and sentient items

**Relics** and **sentient items** are covered on [[Burners Invocations]]. They are not spells. Spell magic remains [[Burners Sorcerie]] / [[Burners Spells]].

## Muster

*Ok boys, check your kit, check your weapons, it's today. You get a pint and a chaser, no more. Let's go*

Anyone with coin can hire a retainer. A **Boss (Heart 1+)** **Musters** today's crew and plays them at the table. Starting Boss kit, Manage, Loyalty, half power, and examples: **[[Burners Muster]]**.

## Lingering Costs: Poison, Petrification, Paralysis

When you endure cleanly you avoid the bite: the fitting Approach against its Risk, Craft against poison (see *Approach Roll*). Once it lands, it deals its level in damage to your HP each round for a number of rounds equal to its level, with no further defense. You escape it with a cure (an antidote, a Vitae working) or by surviving the duration. Past 0 HP it wounds you each round, deepening your negative tally like any wound, or petrifies or paralyzes you as the effect dictates. The Referee rolls nothing. The dread does the work.

## Area Effects

Counter a monster breath by raising your shield (a legendary shield is broad), by **Warding** magical breath, by cover, or by eating the quoted damage. A **spell** area effect Defends like any other hostile working — see [[Burners Sorcerie]].

## Influence

Say what you do and the Referee rules whether it can work (see *The Two Steps*). Ask the jailer to free the prisoners against his duty and it fails. Bribe him to look away and it works — gold or a Spicy twist, and a sharp read softens what you pay. Turn the cultists on each other only after you have built the wedge; then the room tips.

Disposition is a fact of the world. When the fiction has not fixed it, the Referee may roll the Reaction table (see [[Burners Referee Guide]]). Heart amplifies a success the fiction already grants. What you pay in coin, favor, time, or reputation is open to haggling.
