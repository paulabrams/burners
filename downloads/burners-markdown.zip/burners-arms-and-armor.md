---
layout: default
title: "Burners Arms and Armor"
hero: /images/albert-robida-pd/crossbow-ambush-in-street.jpg
hero_alt: "Crossbowmen in the street — Albert Robida"
---

# Burners Arms and Armor

*The optional expanded catalog of arms, armor, shields, and Eldar materials (see [[Burners Adventure Game]]). The lean starting buy-list with slots and prices lives in [[Burners Equipment]].*

> **Reading the numbers.** **Class** (weapons) and **size** (shields) are comparison tags — Weapon Class vs Armor Class for soft-target reads (WC > AC), or shield size for look and heft. **Slots** are the inventory and Initiative-dice stat (see [[Burners Adventure Game]] and [[Burners Equipment]]). Class and Slots are listed separately because they are not always the same (a military **Dagger** is Class2 but 1 slot; a **Mace** is Class3 but 2 slots). Armor maps onto the core's **suits** (AC and slots in [[Burners Equipment]]). Enchantment — see [[Burners Principles#Armor soaks; monsters use Monster Stacks]]. Assign **Slots** from the lean list where an item appears there, otherwise by the same bulk/handiness ladder.
>
> *Era guide:* Northmarens run early-medieval arms & armor, Southmarens late-medieval/early-Renaissance, the Eldar exotic and magical.
>
> **"Legendary" — mind the two senses.** A *Signature* rung on mundane kit (name and history) vs **enchanted / legendary / eldritch** arms (one magical class — a *+1* is a magic sword). Trait acceptance: [[Burners Adventure Game#Enchanted Arms and Armor]]. Stocking: [[Burners Referee Magic Items]]. Signatures earned in play: [[Burners Principles#Earned in play]].

---

## Advanced Kit

Advanced rules for kit beyond the basics (skippable for a casual game). Everything past plain, common gear is **earned in play** — see [[Burners Principles#Earned in play]].

### Item Quality

Every weapon, armor, or tool sits on one ladder, bottom to top. Only the first two rungs are for sale; the rest are earned in play.

1. **Common** — its type's Tags, nothing more.
2. **Fine steel** — masterwork price; **Trusty** (never sticks or notches — the worst outcome finds something else).
3. **Signature** — a name and a history (*"Wren's sword, tuned over twenty years of border duty"*). Worth coin and worth questions, but no bonus of its own. You name an item in play, never at creation.

Tuned, Bane-forged, and Legendary arms are Referee magic items — see [[Burners Referee Magic Items]]. Enchanted / legendary / eldritch are one class; Trait acceptance gates the magic: [[Burners Adventure Game#Enchanted Arms and Armor]].

### Signatures

A **Signature** is the fiction of that third rung — a name, a look, a history (*"Naurdring the goblin slicer"*; *"a tunic, royal blue with gold embroidering"*). It is not a die bonus; there are none. What it does is lend an action credibility, the way a fitting Theme or Trait does — declare it and the Referee may let the deed simply succeed (Step 1). Write it with the item type and Tags, e.g. *"Naurdring, the goblin slicer [Longsword Class3 Slots3…]"*. A **damaged** item can lose its Signature — fine velvet is ruined by a crawl through a cavern — so save your best for when it counts. Enchanted kit carries **powers** once found — see [[Burners Adventure Game#Enchanted Arms and Armor]] and [[Burners Referee Magic Items]].

## Item Tags

Weapons carry **Class** (penetration / soft-target reads) and **Slots** (inventory space and reach). Shields carry **size** (look and heft) and **Slots**. Armor pieces may list Class for catalog flavor; in play, read **AC** and **Slots** from the suit tables in [[Burners Equipment]]. Some tags take a value — `Class2`, `Far3`, `Slots2` — which defaults to **1** when omitted.

---

## Weapons

Weapons are tools of war. **Melee** weapons (swords, axes, spears) fight hand-to-hand and have a length — get to the range yours wants. **Missile** weapons (bows) attack at distance — keep away from the press and seek lines of sight while using cover.

**Two-handed (`2H`)** weapons need both hands. A `2H` melee weapon used one-handed has **Weapon Class −1** and grants none of its beneficial tags (not an option for bows).

### Common Weapons

The most commonly available — easy to produce and acceptable for a commoner to carry. Everyone carries a knife; travelers usually carry a staff.

- **Pugilism** `[Class0 Slots0 Close Unarmed]` — kicks, punches, knees, stomps, and other unarmed attacks.
- **Knife** `[Class1 Slots1 Close Short Stabbity Civil]` — common belt knife.
- **Throwing Knife** `[Class1 Slots1 Close Short Stabbity Far1]`
- **Stick or Stone** `[Class1 Slots1 Short Far1 Primitive]` — sturdy tree branch, rock, etc.
- **Cane** `[Class1 Slots1 Short Civil]` — a gentlemanly stout walking stick or cudgel.
- **Sickle** `[Class1 Slots1 Short Hooking Tool]` — for grain.
- **Hatchet** `[Class1 Slots1 Short Breaching Tool]` — small, for chopping wood.
- **Messer / Machete** `[Class2 Slots2 Medium Cutty]` — long work knife.
- **Wood Ax** `[Class2 Slots2 2H Medium Breaching Tool]` — for chopping wood.
- **Scythe** `[Class2 Slots2 2H Medium Tool]` — blade for harvesting wheat.
- **Short Spear** `[Class3 Slots3 2H Medium Far1 Piercing Primitive]` — short thrusting/throwing spear, up to your nose (~5 ft), simple and effective; common in hunting and war.
- **Staff / Quarterstaff** `[Class3 Slots3 2H Medium Control-Medium Civil]` — stout staff around nose- or head-height. Common, simple, effective.
- **Long Staff** `[Class3 Slots3 2H Long]` — staff about as high as you can reach.
- **Maul** `[Class4 Slots4 2H Medium Crushy Primitive]` — huge, heavy club.

### Swords and Daggers

Versatile sidearms, particularly excellent at defense — able to parry and deflect most weapons.

- **Pommel** `[Class1 Slots0 Close]` — counterweight end of a dagger or sword.
- **Dagger** `[Class2 Slots1 Close Stabbity]` — military double-edged dagger.
- **Parrying Dagger** `[Class2 Slots1 Close Binding Parrying Handguard2 Stabbity]` — left-handed dagger wielded to accompany a sword.
- **Rondel** `[Class2 Slots1 Close Stabbity]` — triangular thrusting war dagger, used to pierce gaps in armor, especially while grappling. Carried by many knights and men-at-arms.
- **Cutlass** `[Class2 Slots2 Short Parrying Handguard2 Cutty]` — short curved cutting sword (machete, hanger).
- **Langes Messer** `[Class2 Slots2 Medium Parrying Cutty]` — long single-edged knife-sword with a nagel and no hand protection (messer, dussack). Often carried with a finger buckler.
- **Short Sword** `[Class2 Slots2 Short Parrying Handguard Piercing Stabbity]` — short straight stabbing sword (katzbalger, cinquedea).
- **Arming Sword** `[Class2 Slots2 Medium Binding Parrying Handguard Piercing Cutty]` — simple iconic straight sword (viking or knight's sword).
- **Sidesword** `[Class2 Slots2 Medium Parrying Handguard2 Binding Piercing Cutty]` — "the sword by your side," a typical military/civilian sidearm (spada di filo, cavalry sword).
- **Sabre** `[Class2 Slots2 Medium Parrying Handguard2 Cutty]` — long curved cutting sword. A thin-bladed scimitar is a sabre; otherwise a falchion.
- **Rapier** `[Class2 Slots2 Medium Parrying Handguard3 Binding Piercing Cutty]` — civilian sword, popular with nobles and duelists in Aquila.
- **Falchion** `[Class3 Slots2 Medium Binding Parrying Handguard Cutty]` — curved sword with a clipped tip that can bind a foe's weapon (storta, malchus, scimitar).
- **Longsword** `[Class3 Slots3 2H Short-Medium Control-Medium Binding Parrying Handguard Piercing Cutty]` — bastard sword, kriegsmesser, or Alu "av-kel" sword.
- **Swiss Saber** `[Class3 Slots3 2H Medium Binding Parrying Handguard3 Piercing Cutty]` — a curved longsword with an elaborate handguard.
- **Greatsword** `[Class4 Slots4 2H Medium-Long Control-Medium Parrying Handguard2 Binding Piercing Cutty Trained]` — two-handed sword (spadone, montante, zweihänder). Can attack in any direction.

### Military Weapons

Strongly associated with military units; most need training in a military order. Many towns restrict possession within the walls except by official guards — the Referee may have guards harass, fine, or confiscate.

- **Shield Punch** `[Class1 Slots0 Close Binding]` — uses the boss or rim.
- **Rifle Stock** `[Class1 Slots1 2H Short]` — using the heavy rifle stock as a club.
- **Javelin** `[Class1 Slots1 Short Far2 Piercing Primitive]` — short throwing spear.
- **Throwing Ax** `[Class1 Slots1 Close Hooking Far2]` — war hatchet or tomahawk, thin head and long handle.
- **Rifle Bayonet** `[Class2 Slots2 2H Medium]` — spear point on the barrel of a rifle.
- **Khopesh** `[Class2 Slots2 Short Medium Binding Hooking]` — sickle-shaped sword-ax, ancient and still used by some Eldar.
- **Small Ax** `[Class2 Slots2 Close Short Breaching Hooking Far1]` — one-handed war ax, the bearded or Viking hand ax; light enough to throw.
- **Horseman's Ax** `[Class3 Slots2 Short Breaching Hooking]` — ax with a rear spike for penetrating armor, swung from the saddle or on foot. Not a throwing ax; on the price list it goes with the Mace.
- **Mace** `[Class3 Slots2 Short Crushy]` — flanged/beaked/spiked club for crushing armored foes; needs swinging room. Includes short war hammer, horseman's hammer, morningstar.
- **Short Spear** `[Class3 Slots3 2H Medium Far1 Piercing Primitive]` — short thrusting/throwing spear, up to your nose (~5 ft).
- **Battle Ax** `[Class3 Slots3 2H Medium Breaching Hooking]` — heavy two-handed war axe, handle shorter than a polearm.
- **Hewing Spear** `[Class3 Slots4 2H Medium Long Piercing]` — thrusting/cutting spear, as high as your upstretched hand can reach (~7–8 ft).
- **Long Spear** `[Class3 Slots5 2H Long Piercing]` — demi-pike, well past your reach (~10–12 ft); a battlefield spear, at home in the second rank.
- **Pike** `[Class3 Slots6 2H Long Piercing]` — extremely long spear (~15–20 ft) for mass infantry; ineffective in individual combat except a duel (range listed "Long").
- **Mangual Flail** `[Class4 Slots4 2H Medium Long Hooking Control]` — large multi-headed military flail. Use the high (Head) guard to avoid hitting yourself.
- **Pick** `[Class4 Slots4 2H Medium Hooking Piercing]` — large footman's pick; arced head can strike over shields.
- **Long Axe** `[Class4 Slots4 2H Medium Long]` — a very long battle axe.
- **Poleaxe** `[Class4 Slots4 2H Medium Control-Short Hooking]` — the predominant knightly polearm for armored combat: short stout staff with axe, hammer, and spike (lochaber ax, bec de corbin).
- **Ranseur** `[Class4 Slots5 2H Long Binding]` — popular early polearm with a trident head (roncone, ronka); side prongs bind and trap weapons/shields. Spetum to earlier Eldar; some fold, some (brandistock, "feather staff") have hidden spring prongs.
- **Glaive** `[Class4 Slots5 2H Long Cutty Hooking]` — polearm with a large single-edge blade, usually a back hook, no spear point (fauchard to earlier Eldar).
- **Guisarme** `[Class4 Slots5 2H Long Binding Hooking]` — polearm with a concave scythe-like blade, usually a thrusting spike and pulling prongs (bill, bill hook, scorpion).
- **Partisan** `[Class4 Slots5 2H Medium Long Cutty Binding]` — elegant polearm with a sword-like guarded head allowing a shorter grip.
- **Halberd** `[Class5 Slots5 2H Medium Long Binding Hooking]` — polearm with thrusting spike, cutting ax, and pulling hooks (bardiche, voulge).

### Projectile Weapons

Shoot ammunition. The three main types are bows, crossbows, and guns. Loading/reloading costs Actions equal to the `Reload` tag.

- **Primitive Bow** `[Class1 Slots1 2H Far2 Reload1 Primitive Civil]` — self-made/primitive shortbow, all-wood arrows, sharpened wood tips, no fletching.
- **Hunting Sling** `[Class1 Slots1 2H Far4 Reload3 Primitive Civil]` — common light sling, stones or clay; years of practice.
- **Hunting Bow** `[Class2 Slots2 2H Far4 Reload1 Civil]` — most common short bow. Broadheads usual; round heads (Class1) for birds/small game.
- **War Sling** `[Class2 Slots2 2H Far3 Reload4 Trained]` — larger, more powerful war sling, cast-lead aerodynamic shot.
- **Warbow** `[Class3 Slots3 2H Far3 Accurate Reload1 Trained]` — heavy-draw short bow, armor-piercing bodkins; years of training/conditioning.
- **Hunting Crossbow** `[Class3 Slots3 2H Far4 Accurate Reload3]` — easy to shoot.
- **Longbow** `[Class3 Slots3 2H Far5 Accurate Reload1 Trained]` — large self bow, taller than the archer; great power, range, accuracy; slower than hunting bows.
- **Heavy Longbow** `[Class4 Slots4 2H Far5 Accurate Reload2 Trained]` — heavy-draw longbow, military arrows (50% heavier); years of conditioning.
- **Heavy Crossbow** `[Class5 Slots4 Far4 Accurate Reload7]` — military crossbow, easy to learn, hard-hitting, cumbersome and slow to reload.
- **Flintlock Pistol** `[Class5 Slots2 Far4 Accurate Reload7]` — basic Dwur pistol.
- **Doubloon** `[Class5 Slots2 Far2 Reload7 (each)]` — double-shot flintlock pistol/blunderbuss, often nautical/pirate themed.
- **Shotgonne** `[Class5 Slots3 Far2 Reload9 (each)]` — double-barreled hand cannon for "intimate encounters"; each barrel loaded, primed, fired independently.
- **Siege Arbalest** `[Class6 Slots5 Far5 Accurate Reload12 Trained]` — very heavy, powerful crossbow; extremely slow to reload.
- **Arquebus** `[Class6 Slots4 Far4 Accurate Reload9 Trained]` — newer, more accurate hand cannon with a true rifle shape and matchlock.
- **Flintlock Rifle** `[Class6 Slots4 Far5 Accurate Reload8 Trained]` — a rifle using a flintlock.
- **Handgonne** `[Class7 Slots5 Far3 Reload12 Trained]` — hand cannon: heavy barrel, handle, and socket for a stock or staff.

**Bows vs Crossbows.** Bows need more training (warbows are a specialist profession), are simpler to craft, need strength/conditioning, are lighter and easier to aim/reload on the move, and shoot faster. Crossbows need no strength to hold ready and are better for fielding armies (less training; troops fight even when weakened). A bow is "ready" only with an arrow nocked — drawing/releasing is part of the attack, never held drawn long. Crossbows aren't carried loaded (the bolt falls out if tilted).

### Weapon Tags

Weapons carry tags for their characteristics; many describe a way to upgrade in specific circumstances. Weapons fall into **main weapons** (spears, axes) and **sidearms** (swords, daggers); larger weapons have higher Class and more tags.

- **Weapon Class** — the weapon's penetration vs contemporary armor. Used for soft-target reads (WC > AC). **Slots** — inventory space, and reach: when held attacks go off together, more slots strikes first (see [[Burners Equipment]]).
- **Military Weapons** — Class3+ are "military weapons," not usually permitted in civilized areas unless they have the `Civil` tag. A two-handed military weapon has no sheath on the belt, so it is always carried in the hands: walking through town with one is walking around with a drawn weapon. A sword and buckler hang at the belt and leave your hands free. Large military weapons like greatswords and halberds also need room to swing: in a corridor, a doorway, or a crowd you may have to burn a die for the friction.
- **2H (Two-Handed)** — optimized for two hands; longer and heavier. Used one-handed: WC −1 and no tag benefits.

**Range tags** (optimal distance — upgrade if you're at your optimal range and the foe is not):

- **Close** — optimal for unarmed; only unarmed attacks at this range (punch, kick, grab, wrestle, throw, elbow, knee, head-butt, pommel, bite). A sword pommel is a Class1 Close weapon.
- **Short** — optimal for most melee; any weapon can fight here. Any thrusting melee weapon in two hands ("halfsword") is optimal at Short.
- **Medium** — optimal for longer melee (swords); any weapon can fight here.
- **Long** — optimal for spears and polearms; other melee weapons reach here only with the `Long` tag.
- **Far** — at least 10 ft, out of melee reach; only `Far` weapons attack here.

**Advanced weapon tags:**

- **Accurate** — capable of very long shots for a skilled marksman. Spend an Action (with a supporting Trait like *marksman, archer, sharpshooter*) to raise optimal range one step (e.g. `Far` → `Far3`), up to double normal range. Lost if you move or take another Action.
- **Binding** — can "bind" a foe's weapon with sticky contact. Spend an attack to bind; upgrade attacks and defenses vs that foe. Re-binding in response to a bind: whoever binds last is "winning the bind."
- **Breaching** — strong enough to force doors, chests, windows; other weapons break under such abuse.
- **Civil** — less threatening; legal to carry in towns.
- **Control** — (long swords, short polearms) easily turned to strike any direction; ideal for area control and fending off multiple foes. If the Referee raises Heat for being surrounded/flanked, spend an Action to negate the raise. Two hands only, at the listed range (e.g. `Control-Medium`).
- **Cutty** — can cleave soft targets. After a Spark against a soft target (your WC beats their AC) you may Fuel another attack with the same weapon.
- **Custom** — higher-quality, bespoke, perfectly made.
- **Handguard** — armor on your weapon hand. A simple cross hilt (arming sword, longsword) is AC 1, `Handguard`. A cross with a finger ring or knuckle bow (sidesword, sabre, hanger) is AC 2, `Handguard2`. A swept or cup hilt (rapier) is AC 3, `Handguard3`. A full basket (schiavona, Highland broadsword) is AC 4, `Handguard4`. A shield does the same for the hand that holds it, at its slots. When a blow is aimed specifically at that hand (a cut at the wrist or fingers), claim it, even on a plain Defend with no Block: it soaks leftover after Defend like armor, or your suit does if its AC is better. Against any other blow it does nothing. You can wear no armor at all and still have armor on your hand. Rare in play: blows aren't usually aimed at a hand.
- **Hooking** — (sickles, some polearms) can cut behind the target. When you Aim you may strike the rear instead of left/right for **+1 WC**.
- **Parrying** — a blade shaped to parry (mostly swords and daggers). With the Trait, when you Block, it takes its slots off the blow, like a shield, along with your shield or a second Parrying weapon. A weapon without the tag takes nothing off (see *Block* in [[Burners Adventure Game]]). The *parry* Trait doesn't make a weapon Parrying.
- **Piercing** — extended rigid blade 2+ ft, reaching deep. **+1 WC vs Large Monsters** (whose vitals sit deeper, giving them higher AC).
- **Primitive** — easy to build (low skill, time, materials); found among primitive tribes or improvised when nothing else is at hand.
- **Reload** — must be reloaded before attacking again (bows, crossbows, firearms). The number = Actions needed (min 1).
- **Trained** — **trained-only** in Burners: without a Trait for that kit you cannot use it in a fight (no blows). Examples: *greatsword*, *longbow*, *plate armor*.
- **Stabbity** — optimized for stabbing/"shanking." After a Spark you may Fuel another attack with the same weapon into the **same Wound**.

---

## Armor

Prices, AC, and slots for the shop list live in [[Burners Equipment]] and the play list in [[Burners Adventure Game]]: leather 1, gambeson 2, chain mail 3, plate mail and field plate 4, full plate 5. Leather, gambeson, and mail are open; **plate is trained-only**.

The pieces below are *look and history* for those rungs — build the harness you like, then read one AC from the Equipment table (or the closest entry: scale as chain mail, and so on).

**How the kit tends to map:**

- **AC 1 (leather, 2 slots)** — vitals only: boiled leather, a cuirie, a light jack, a cap or coif. Scout and mage kit.
- **AC 2 (gambeson, 4 slots)** — a thick padded jack or arming doublet, often under mail.
- **AC 3 (chain mail, 6 slots)** — a mail hauberk or byrnie, scale treated the same; helm and gauntlets as you like.
- **AC 4 (plate mail, 8 slots; field plate, 5 slots)** — coat of plates, brigandine, or plate over mail; field plate is the fitted harness.
- **AC 5 (full plate, 7 slots)** — enclosed proof, fitted.

Heavy harness eats slots and leaves less room for steel. Armor gives AC, not dice.

**Gaps and called shots.** Your suit is one number in ordinary play. When a foe deliberately strikes where it does not reach — a called shot, or a swarm at the legs of a lightly harnessed Burner — that blow meets bare flesh (AC 0). Helms, gauntlets, greaves, and gorgets close those gaps. A **closed** helm (armet, great helm) trades sight and hearing for the best cover; open helms and **civil**-looking armor draw less notice in town.

**Materials and named pieces** — adamant, moonsilver, orichalcum (see Eldar Materials), or a *Signature* harness — ride on top as flavor; AC still comes from the suit.

---

## Shields

Held steel, raised against a blow. Held, a shield gives its slots in Fuel if your Approach covers it. Its **slots** (prices in [[Burners Equipment]]): buckler 1, target 2, heater 3, rotella 4, kite 4, tower 5. With the shield's Trait, when you **Block** it takes its slots off the blow: a buckler 1, a tower 5, plus a Parrying weapon's slots (see *Block* in [[Burners Adventure Game]]). A raised shield can count as **Cover** vs missiles (2 dice on that Defend). A shield also counts as armor on the hand that holds it, at its slots, against a blow aimed at that hand (see *Handguard*).

Catalog **size** tags below are labels for look and heft — use Burners **slots** at the table.

### Shield Types

- **Buckler** `[size 1 Slots1 Centergrip Civil]` — small fist-gripped companion shield (round *brocchiero* or square *targa*). Common and cheap. The palm-sized finger buckler, about six inches across and gripped in the fingers, covers a sword hand that has no guard of its own; it is too small to count as Cover.
- **Target** `[size 2 Slots2 Strapped]` — small round shield strapped to the forearm (Scottish targe). The targe hand holds the grip and often a dirk with it.
- **Round Shield** `[size 3 Slots3 Centergrip]` — light wooden round shield (Viking shield).
- **Heater** `[size 3 Slots3 Strapped]` — smaller kite shield for mounted or foot combat.
- **Rotella** `[size 4 Slots4 Strapped]` — strapped metal round shield held at arm's length.
- **Large Round** `[size 4 Slots4 Centergrip]` — large wooden round shield.
- **Kite** `[size 4 Slots4 Strapped]` — reverse-teardrop horseman's shield, guarding the flank and leg.
- **Aspis** `[size 5 Slots5 Strapped]` — huge deeply-dished wooden shield.
- **Tower** `[size 5 Slots5 Strapped]` — tall rectangular shield.
- **Pavise** `[size 5 Slots5, standing cover]` — a semi-portable wall for siege crossbowmen; planted as static cover (an Action to move and re-set), it frees the hands.

**Grip.** A `Centergrip` shield is held in the fist. It moves quickly and goes forward with the sword hand. Drop it to free the hand. It can also be torn away: a Man-handle aimed at the shield that you don't fully Defend takes it. A `Strapped` shield rides the forearm on a strap and a hand grip — steadier and stronger, slower to ready. A Man-handle can pin it for a blow but never tear it away, and opening your hand doesn't drop it. Brought to bear against a Man-handle, it braces you: one free defense die. Either way a shield only stops the blow you bring it to bear on; a foe you do not see gets past it.

---

## Incendiaries & Alchemy

*Fire makes it good. A Burner carries more of it than sense allows — oil for the barrow, a firepot for the press, and something Dwur-made for the thing that will not burn on its own. Thrown fire is the trade's signature. (Prices and slots in [[Burners Equipment]].)*

- **Flask of oil** — pour and light, or shatter it thrown; a lit pool burns anything standing in it. Also lantern fuel.
- **Molotov cocktail** — a rag-fused oil flask; bursts alight on impact, no separate ignition needed.
- **Slow-match & fuse cord** — a smoldering cord that holds a reliable flame and lights oil, fuses, and firepots hands-free.
- **Pitch pot** — spread and light to raise a brief wall of fire across a passage or doorway.
- **Naphtha (dragon's-blood oil)** — superior oil that clings and burns hotter and longer; hard to beat out.
- **Clay firepot** — bursts into a spread of sticky fire, catching a cluster of foes at once.
- **Holy water (vial)** — splashed or thrown; sears undead and fiends like burning acid (fire / right tool vs husks that fear it — see [[Burners Burn Undead]]).
- **Alchemist's fire (vial)** — clinging flame that catches on contact and burns for several rounds until smothered.
- **Dwur boom stick** — a blackpowder charge on a haft; a loud, bright blast that shatters bone and staggers the dead.
- **Dwur grenade** — a sealed Dwur firepot; hurl it for a burst of flame and shrapnel across a small area.
- **Witchfire (vial)** — eldritch green flame that burns even the wet and the drowned dead, and no water will quench.

**Using fire.** A thrown incendiary is an Action; it lands as an area effect (the blow you cannot dodge) rather than a defended blow. Mark the flask when you throw it ([[Burners Equipment#Count these]]). Fire is not stopped by a Burner's armor. Against a monster it is damage the Referee converts to Hits on the pile (fire often *is* the right tool — or opens soft husks cold). Against the Fallen it bites deep (see [[Burners Burn Undead]]). The same kit **purges an undead Wound** — spend one Incendiary (holy water or holy oil) to burn the curse clean ([[Burners Referee Guide#Undead]]). Fire turned on the party — a trap, a backdraft — feeds Heat like any unsoaked harm. Something set alight keeps burning for a round or two (fire each round) until smothered: dropping in the dirt and rolling, a heavy cloak, or water (witchfire excepted). Blackpowder — boom sticks and Dwur grenades — is a blast rather than a lingering burn, and loud enough to wake every wandering thing on the level, so save it for when subtlety is already spent.

---

## Magic Items / Eldar Kit

The Eldar of aeons past made many things — dark and beautiful, bright and deadly. You might find Eldar relics in deep caverns or guardian battles, or meet Eldar (living or undead) wielding archaic blades of mysterious metals. The mightiest works are named in story, often borne by famous (or infamous) heroes.

**Trait acceptance.** Enchanted weapons, shields, and armor answer only someone who holds the fitting **Trait** for that kit (*arming sword*, *longbow*, *chain mail*, *heater*…). Without the Trait you may carry and swing them as ordinary steel — Slots, AC, faces — but the magic stays quiet (no free die, no powers). Accepted, a weapon gives one free die a round on a blow, and a shield or armor one on a Defend, rolled as you use it. Most martial Traits sit under **Sword**, so **Veterans** usually claim the magic arms and harness. A Journeyman with *hunting bow* can still be accepted by a magic hunting bow. Full rule: [[Burners Adventure Game#Enchanted Arms and Armor]].

**Designing Eldar items** — think in terms of Signatures. *"Drisi Orichalcum plate armor"* protects vs hostile magic (Resistance to magic where it covers you); a *"Drisi Vakaar Dagger"* could open Wounds that resist ordinary healing and make the Shock Check harder; the *"Avathar Book of Shadows"* carries a "shadow magic" Signature. Be creative and flexible rather than definitive.

### Eldar Materials

- **Adamant** — blued steel renowned for hardness and sharpness; normal steel alchemically tempered to a beautiful blue-grey.
- **Bladegrass** — fibrous plant worked like leather; the Alu use it instead of leather (armor, boots, saddles). Resists moisture (won't soak/swell); naturally edged, so the Alu craft flexible knives and sharp-edged whips.
- **Moonsilver** — silvery steel alloy that absorbs and sheds moonlight; revered by devotees of Lunara. Alu and Elves love it for jewelry, armor, swords.
- **Night Iron** — dark steel alloy that absorbs light, darker than dark; Alu used it for armor and blades. Its source and making are unknown.
- **Orichalcum** — brassy alchemical alloy cast into amulets, rings, weapons, armor; reputed to resist magic. Favored by Alu, Baal, and Drisi. **Grants Resistance to magic on any location it covers — but pay +1 Heat to cast magic through such a location.**
- **Vakaar** — infamous meteoritic-iron alloy, blackened/purple/green flecked blood-red; almost only used for "venom blades" whose Wounds don't heal naturally and resist ordinary healing (the score they cut won't recover on its own, and the Shock Check comes harder). Often wavy-bladed. Making it is lost lore — folded in darkness, washed with acid, poison, venom, blood, souls, and dark prayers to the Serpent Gods.

### Alu Items

- **Alu Dart Knives (as-en)** `[Class1 Slots1 Close Short Stabbity Far1]` — the Alu warriors' dart-like throwing knives.
- **Alu Sickle Sword (av-tlen)** `[Class2 Slots2 Medium Binding Parrying Handguard Hooking Cutty]` — deeply curved sickle sword that hooks and traps limbs; also clears jungle/bladegrass.
- **Alu Kel Sword (av-kel)** `[Class3 Slots3 2H Medium Binding Parrying Handguard Cutty]` — the Alu warriors' longsword.
- **Alu Bladestaff** `[Spear Class3 Slots3 2H Medium Far1]` — ornate staff with a hidden blade. Variants hide a spring-dart knife, whip, or smoke egg.
- **Alu Bladegrass Cloak** `[Class2 Slots1 Soft Cloak Partial]` — fluttering cloak of silken bladegrass strands.
- **Alu Bladegrass Cuirass** `[Class3 Slots5 Body-Armor]` — thick bladegrass over torso and head, including a war mask.
- **Alu Smoke Egg** `[Class0 Slots1 Far1]` — egg/thin-metal capsule of smoke, orichalcum dust, or chili powder; thrown or crushed for a person-sized cloud.

### Avathar Items

Avathars have specialized potion-delivery instruments, requiring training from the Royal Avathar Guild of Alchemists.

- **Syringe** — fill with a potion for pinpoint delivery (max effect), or administer to another as an *armed* attack (normal potion effect).
- **Catheter** — injects a potion directly into the blood; same as a syringe, but the potion is always "readied" and using it is an Action.
- **Dead Man's Switch** — a failsafe on a catheter that auto-delivers the potion if you fall unconscious or otherwise helpless (paralyzed, petrified, beguiled).
- **Blood Flies** — gruesome pets fed on the Avathar's demi-vampiric blood, trained to alert him to food (all but automatic at flesh-and-blood detection and tracking — a Craft roll there can simply succeed). Recallable and hideable, but disgusting (hinder social rolls).

### Drisi Items

Relics of the Drisi empires that ruled aeons ago — found in any land or underworld.

- **Adamant Scorpion** `[Class3 Slots4 Long]` — long shadow-steel polearm with incredible cutting properties.
- **Orichalcum Serpent Ring** `[Class0 Slots0 Gauntlet]` — brassy Eldar-steel ring that absorbs magic; mages avoid it unless they don't cast with that hand.
- **Orichalcum Scale Armor** `[Class2 Slots4 Half-Armor]` — small brassy Eldar-steel plates laced to a cloth/leather backing.
- **Orichalcum Buckler** `[size 1 Slots1 Centergrip Civil]` — brassy Eldar steel that absorbs magic.
- **Orichalcum Breastplate** `[Class3 Slots4 Body-Armor]` — brassy Eldar-steel front breastplate over clothing.
- **Vakaar Falchion** `[Class3 Slots2 Medium Binding Parrying Handguard Cutty]` — evil wavy-bladed sword of cracked dark-purple/green steel; wounds don't heal naturally.

### Draconecroalchemy Items

Some Baal-Mot, Drisi, and Black Wizards tap the vast power of dead dragons — bringing the enmity of Baal.

- **Blue Dragon Orb** — glassy sphere with a flickering dragon-magic spark; aids magic of air, electricity, weather.
- **Dracontia / Dragon Orbs** — crystalline spheres holding a fragment of a dragon's soul at the moment of death (a flickering flame/spark within); prized by wizards. Power scales with the dragon's soul and the manner of its death — the strongest come from dragons who died feeling betrayed, leaving an angry, vengeful fragment.
- **Dragonbone Dagger** — assassin's blade; wounds will not heal on their own.
- **Dragonbone Staff** — potent focus for controlling and conjuring fire; five feet to honor the Dragon Gods, turned from black dragonbone, etched with draconic symbols. Smooth and warm — or burning hot to those who displease the Dragon Gods. Prized by Black Wizards, heretical to dragon worshipers.

### Dwur Items

**Thaumatagonnes ("Runelocks")** are the Dwur's famous firearms and cannons — heavy fantastically-shaped barrels covered in Thaumaturgical runes that strengthen them for more powerful alchemical powder. Some bear further enchantments the Alglond firearms can't match. A rune on the striker magically resets it when spoken — but a Runelock can only be reloaded if you are **Trained** (*Runelock*, Dwur only), and the Traits *Dwur* and *Thaumaturge* each reduce Reload by 1.

- **Runelock Dwuringer Pistol** `[Class3 Slots2 Far2 Accurate Reload6 Trained]` — single-shot holdout pistol that fits in a belt buckle or boot.
- **Runelock Revolver** `[Class4 Slots3 Far3 Accurate Reload5 Trained]` — six shots; reload cost covers 1–6 cartridges.
- **Runelock Pistol** `[Class5 Slots2 Far3 Accurate Reload5 Trained]` — single shot.
- **Runelock Holy Water Sprinkler** `[Class4 Slots4 2H Far Reload7 Trained]` — "hand-cannon-mace-pistol" with four pistols in the mace head; each barrel loaded and fired independently.
- **Runelock Doppelpistol** `[Class5 Slots3 Far2 Accurate Reload5 Trained]` — two barrels, each loaded and fired independently.
- **Runelock Dungeon Sweeper** `[Class6 Slots4 2H Far3 Reload5 Trained]` — double-barreled shotgun for up-close combat; each barrel independent.
- **Thaumasweeper** `[Class6 Slots4 2H Far3 Reload6 Trained]` — Dwur Thaumaturgical "dungeon sweeper" cast in alchemist's iron, rune-etched.
- **Runelock Carbine** `[Class7 Slots4 2H Far4 Reload5 Trained]` — light rifle.
- **Runelock Longrifle** `[Class8 Slots5 2H Far5 Heavy Accurate Reload6 Trained]` — long-barreled heavy rifle.
- **Thaumagonne** `[Class7 Slots5 2H Far4 Reload10 Trained]` — Dwur Thaumaturgical handgonne, rune-etched alchemist's iron.
- **Thaumacannon** `[Class8 Slots6 Crew Far4 Reload12 Trained]` — Dwur Thaumaturgical cannon (heavy ~20# barrel on a stock/staff/frame), barrels cast as dragons/rockets/mountains. An alchemist loads fire, stone, shot, or explosive/incendiary concoctions, charging it with one specific spell (e.g. fireball, lightning bolt) you must describe.

### Ithilrhi (Elven) Items

- **Ithilrhi (Elven) Chainmail** `[Class3 Slots5 3Qtr-Armor Custom]` — a suit of tiny interlocking rings. If custom-made for the wearer it does **not** require a gambeson (normally needed for chain mail) and can be worn under clothing. Treat as chain mail (AC 3) unless the find says otherwise; custom fit may ride lighter (Referee).
- **Runesword** `[varies by sword type]` — legendary rune-inscribed sword wielded by Eldar battlesingers. Needs a Sword Trait for the sword type (*arming sword*, *longsword*, *greatsword*…).
- **Singing Bow** — an Elven warbow exquisitely carved and inlaid with silver leaf, channeling vim into arrows as they leave the bow. Needs the *longbow* (Craft) or *warbow* (Sword) Trait; Trained.

### Arcana (Sorcerie slots)

Sorcerers hold these in **Sorcerie slots** as Arcana (see [[Burners Sorcerie]]) — staff, wand, rod, orb, crystal, ring, amulet, mask, robes, hat. Personal spellbooks, true writings, and scrolls may ride **physical or Sorcerie**; in a Sorcerie slot they fill it but are not Arcana.

- **Book of Shadows** — a tome of one Umbrakala shadow-working.
- **Diadem of the Third Eye** — a pendant suspended above your brow, in the position of your third eye, usually a jewel or precious stone.
- **Eye of Horus** — one of your palms tattooed with magical patterns resembling a third eye.
- **Hamsa** — an ornate amulet depicting the "hand of the goddess" with the third eye; worn on a chain or pin.
- **Hex Hands** — your hands covered in magical tattoos, very potent when used together.
- **Ioun Stone** — a rare stone, crystal ball, or dracontia. Held in one or two hands, or (when Trained) released to hover beside you.
- **Sorcerer's Focus** — your clean-shaven head tattooed with magical ink, tracing patterns to project your thoughts into reality.
- **Summoner's Grimoire** — a book of summoning and binding rituals; the magic-user must recite the ritual directly from the book, often inscribing magic circles or patterns on the floor per the ritual.
- **The Evil Eye** — one of your eyes capable of a truly malevolent glare, yet prone to becoming bloodshot if used too often.
- **The Magic Finger** — one of your fingers (you pick!) tattooed with magical inks, able to shoot a ray of magic.
- **Wizard's Wand** — a sturdy rod the length of your arm (fingertips to elbow), often bundled sticks, to help channel magic.
- **Wizard's Staff** — a stout staff, ideal for defense and focusing power.

## Legendary Item Names

Legendary items are kick-ass, so they should have kick-ass names. Examples to kick-start your own:

**Weapon Names:** Asskicka!, Skullcrusher, Sineater, Inquisitor, Sunblade, Dawnbreaker, Tranquility, Lightbringer, Nightfall, Patience, Harmony, Mercy, Sword of Life, Hater, Twilight, Doomsong, Soulsplitter, Starhammer, Soultaker, Widowmaker, Frostcutter, Bloodletter, Kinslayer, Fellcleanser.

**Famous Weapon Names** *(no claim to originality):* Arondight, Ascalon, Caliburn, Clarent, Durandal, Galatin, Foehammer, Stormbringer, Mourneblade.
