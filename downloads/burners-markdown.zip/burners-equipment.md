---
layout: default
title: "Burners Equipment"
hero: /images/albert-robida-pd/knight-returning-with-pig-and-keg.jpg
hero_alt: "A knight returns laden — crossbow, sword, and loot — Albert Robida"
---

# Burners Equipment

## Weapons

| Weapon                  | Slots | Cost (gp) |
| ----------------------- | ----- | --------- |
| Dagger                  | 1     | 3         |
| Silver dagger           | 1     | 30        |
| Club                    | 1     | 3         |
| Sling with 30 stones    | 1     | 2         |
| Small ax                | 2     | 4         |
| Mace (incl. war hammer) | 2     | 5         |
| Short sword             | 2     | 7         |
| Arming sword            | 2     | 10        |
| Short bow / hunting bow | 2     | 25        |
| Spear                   | 3     | 3         |
| Longsword               | 3     | 15        |
| Longbow                 | 3     | 40        |
| Crossbow                | 3     | 30        |
| Battle ax (two-handed)  | 4     | 7         |
| Greatsword              | 4     | 15        |
| Halberd / pole arm      | 5     | 7         |

## Ammunition

| Item                    | Slots | Cost (gp) |
| ----------------------- | ----- | --------- |
| Case with 30 quarrels   | 1     | 10        |
| Quiver with 20 arrows   | 1     | 5         |
| One silver-tipped arrow | —     | 5         |

## Armor

| Armor       | AC  | Slots | Cost (gp) |
| ----------- | --- | ----- | --------- |
| Leather     | 1   | 2     | 20        |
| Gambeson    | 2   | 4     | 30        |
| Chain mail  | 3   | 6     | 40        |
| Plate mail  | 4   | 8     | 60        |
| Field plate | 4   | 5     | 2,000     |
| Full plate  | 5   | 7     | 4,000     |

- AC is Armor Class: the number of points of damage the armor absorbs on a hit.
- Plate armor requires training: see *Training* under [[Burners Adventure Game#Weapons, Armor, and Shields]].
- Field and full plate are rare and must be fitted to you by a master armorer.
- If an armor is not listed, use the closest entry. For example, scale mail can be treated as chain mail.

## Shield

| Shield  | Slots | Cost (gp) |
| ------- | ----- | --------- |
| Buckler | 2     | 3         |
| Heater  | 3     | 6         |
| Rotella | 4     | 9         |
| Kite    | 4     | 12        |
| Tower   | 5     | 15        |

## Adventuring Gear

| Item                                          | Slots | Cost (gp) |
| --------------------------------------------- | ----- | --------- |
| Backpack                                      | 3     | 5         |
| Sack, small                                   | 1     | 1         |
| Sack, large                                   | 1     | 2         |
| Rope, 50 feet                                 | 1     | 1         |
| Wooden pole, 10 feet                          | 1     | 1         |
| Iron spikes (12)                              | 1     | 1         |
| Hammer, small                                 | 1     | 2         |
| Crowbar                                       | 1     | 10        |
| Grappling hook                                | 1     | 25        |
| Stakes (3) and mallet                         | 1     | 3         |
| Tinder box (flint and steel)                  | 1     | 3         |
| Torches (6)                                   | 1     | 1         |
| Candles (6)                                   | 1     | 1         |
| Lantern                                       | 1     | 10        |
| Waterskin or wineskin                         | 1     | 1         |
| Wine (2 pints)                                | 1     | 1         |
| Standard rations, one person one week         | 1     | 5         |
| Iron rations (preserved), one person one week | 1     | 15        |
| Mirror, hand-sized steel                      | 1     | 5         |
| Thieves' tools                                | 1     | 25        |
| Holy symbol                                   | 1     | 25        |
| Garlic                                        | 1     | 5         |
| Wolfsbane (one bunch)                         | 1     | 10        |

## Incendiaries & Alchemy

| Item                          | Slots | Cost (gp) |
| ----------------------------- | ----- | --------- |
| Flask of oil                  | 1     | 2         |
| Molotov cocktail              | 1     | 3         |
| Slow-match & fuse cord, 10 ft | 1     | 3         |
| Pitch pot                     | 1     | 5         |
| Naphtha (dragon's-blood oil)  | 1     | 15        |
| Clay firepot                  | 1     | 20        |
| Holy water (vial)             | 1     | 25        |
| Alchemist's fire (vial)       | 1     | 30        |
| Dwur boom stick               | 1     | 40        |
| Dwur grenade                  | 1     | 60        |
| Witchfire (vial)              | 1     | 75        |

## Count these

Arrows, quarrels, and shot. Holy water. Incendiaries — oil, Molotovs, firepots, naphtha, boom sticks, the rest of that list. Rations.

Mark the arrow, the vial, the flask, the meal when you spend it. You have what the sheet says. Count the rest of the pack too; these four are the ones that go one use at a time.

Lantern oil is the same flask you would throw. One flask, one use — light or fire, not both.

## Animals and mounts

Bought to carry or ride. They sit **off** your twelve slots — not Muster, not inventory. A pack mule's load is its own, not yours.

| Animal | Cost (gp) |
| --- | --- |
| Mule | 30 |
| Riding horse | 75 |
| War horse | 250 |
| War dog | 25 |
| Hunting dog | 25 |
| Falcon / hawk | 50 |

Feed and stabling when you are in town (Referee). Ordinary stock needs no special Trait beyond what the job asks (*riding*, pack work). A **trained, named** companion — your horse, your dog — is a **Signature** on that Trait, not a Muster slot and not a second price: see *Signatures* on [[Burners Adventure Game]].

## Hirelings and specialists

Week rates for servants, trades, and camp/wall hands who are **not** on the adventure. Food and lodging in the rate; new gear on you. Rare hands (sage, alchemist) only in larger towns. Dwarves and elves typically cost double. Other types at the Referee's call.

Anyone who accompanies the party into danger — torchbearer, packbearer, rescued specialist — is a **retainer** for that stretch: you outfit them; survivors take at least a **half-share** (no flat wage for the delve). Loyalty, XP, Muster: [[Burners Muster]].

| Service | gp / week |
| --- | --- |
| Noncombatant (servant, torchbearer, porter) | 2 |
| Horse rider / messenger | 3 |
| Sailor | 3 |
| Blacksmith | 5 |
| Soldier / mercenary (camp, wall, road) | 5 |
| Armorer | 25 |
| Ship captain | 75 |
| Animal trainer | 125 |
| Alchemist | 250 |
| Sage | 500 |

**Garrison troops** (month hire, OSE mercenaries):

| Troop | gp / month | Troop | gp / month |
| --- | --- | --- | --- |
| Peasant levy | 1 | Archer | 5 |
| Light footman | 2 | Light horseman / longbowman | 10 |
| Heavy footman | 3 | Medium horseman / mounted archer | 15 |
| Crossbowman | 4 | Heavy horseman | 20 |

Food and basic kit in the rate; wages double in wartime. Morale is their own score (6 levy up to 9 mounted), checked on 2d6 as OSE. If individuals from a garrison accompany an adventure, treat them as retainers for that stretch ([[Burners Muster]]).

## Magic Items

Refer to [[Burners Sorcerie]] for sorcerer gear: **Arcana** in Sorcerie slots (allow-list
at full slot cost — those throw Initiative), **books and scrolls** (physical or Sorcerie;
fill the slot, no Initiative die), and **potions** (physical only). Spells live in the
**hand** and personal spellbook, not in the focus.

Costume Arcana (mundane grade) is **100 gp apiece** in town; a starting Sorcerer gets one
free. Enchanted Arcana and arms you find or earn. Scrolls and potions you make yourself.
Magic items are rarely for sale at any price.

## Pricing Anything Else

Want something not on these tables? You can use classic old school roleplaying game price lists or the quick approximations below.

**Base rate — gp per slot (unlisted items):**

| Category               | gp/slot | Examples                                       |
| ---------------------- | ------- | ---------------------------------------------- |
| Common                 | 1       | clothing, tools, rope, torches, provisions     |
| Plain armaments        | 5       | odd weapons not on the list                    |
| Fine steel & specialty | 10      | books, lockpicks, instruments, specialty tools |

- **Provisions:** 1 gp per meal for the group.
- **Ranged weapons** and **silver** (and other special materials) add a surcharge when you invent a new piece.
- **Field and full plate** are not slot-formula items — see *Armor*.
- **Arcana** (costume): **100 gp apiece** in town; enchanted Arcana is found or earned — see [[Burners Sorcerie]]. Scrolls and potions are crafted at **100 gp × level**. **Ask a teacher to teach you something:** **1,000 gp × spell level** (teacher chooses the working) — see *Learning Spells* on [[Burners Sorcerie]]. Blank **personal spellbook**: **25 gp**.

**Quality — added on top of the base (or on a listed price):**

| Enhancement           | Adds       |
| --------------------- | ---------- |
| Fine (aesthetic)      | +10 gp     |
| Rich                  | +100 gp    |
| Noble                 | +1,000 gp  |
| Exceptional craft, +1 | +100 gp    |
| Rare craft, +2        | +1,000 gp  |

So an *elegant knight's sword, +1*: listed arming sword **10** + "elegant" 10 + "+1" 100 = **120 gp**. Exceptional craft is finer in the fiction, but it is **not** enchanted magic — see [[Burners Referee Magic Items]].
