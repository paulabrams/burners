---
layout: default
title: "Burners FAQ"
hero: /images/albert-robida-pd/weary-knight-resting.jpg
hero_alt: "A weary knight rests — Albert Robida"
---

# Burners FAQ

*Questions that come up at the table. The books still win.*

This page does not add rules. It points at the ones already written. If an answer and a book disagree, the book is right: [[Burners Adventure Game]], then the satellite that owns the piece.

---

## Combat

### What is Fuel?

The dice you rolled on **Roll Initiative**, left on the table at their faces. You burn them to attack, Defend, cast, Block, and Fuel Sparks. A burned die is gone. Full procedure: [[Burners Adventure Game#Combat]].

### What does winning Initiative let me do?

The Referee names the number the monsters act on (each enemy group rolls **1d6**). Match or beat it and you go **before** them. Fall short and you go after.

If you go before them, the whole Action is yours then — move, position, strike, cast. Within before or after, the players coordinate and act in any order they wish.

### I have Initiative. I don't want to move toward them. Why can't I wait for them to get to me, then attack first?

This is about controlling Initiative.

If you are controlling Initiative, you can attack first. You can move first. You have agency over everything you do — and that is powerful, especially when you and the other players work together.

If you wait for them to act, you are giving that up. They are now in control of Initiative.

You might say: *I have a spear, and they are moving to attack me. Can't the spear attack first?* A fair point. Reverse it, though. What if *they* have the spear? You do not always know what they have.

The answer is to hold your attack. When they step in and both blows go off together, the longer weapon strikes first, and more slots is longer. A hewing spear is four slots; a pike is six; a dagger is one. If they have the longer weapon, they stick you first.

What the table gets is a procedure you can see, bank on, and plan with the other players. If you take Initiative, you take your Action before the opposition. If you want to cede Initiative to them, you may. You can even move and save the rest of your Action for after them — that is powerful too.

What you cannot do is cede initiative to the opposition and then expect to still control it.

### When can I move?

You move as part of your Action, to prepare for it — close, take the doorway, draw, set the line. You do not get to move after your Action.

That also means you cannot really attack and then retreat. Breaking away under threat *is* the Action; you do not swing and then step back. The extra beat, if you get one, is a Spark on Defend — and that is a Counterattack, not a withdrawal.

### Where do my dice come from?

Your level plus your gear dice: the slots of each weapon and shield in your hands and each Arcana your Approaches cover. A Sorcerer gets no dice for a sword unless she has a level in Sword. Armor gives AC, not dice. Three or more empty slots give one die (never more than one). A Boss adds a die for each filled Muster slot. Caught with your pack on, you roll only your level.

A weapon's **slots** are its reach: when held attacks go off together, more slots strikes first. A two-hander of 3+ slots also burns a second die on the blow, when nothing is in the way of the swing.

### Shield or two-handed?

A held shield gives its slots in Fuel if your Approach covers it; drop it and you lose them. A raised shield can count as **Cover** vs missiles (2 dice on that Defend). It is not armor. When you **Block**, a shield you have the Trait for takes its slots off the blow (buckler 1, heater 3, tower 5), and a Parrying weapon adds its own: sword and heater take 5 off.

A weapon of **3+ slots wielded in two hands** can burn a **second die** on the blow. Dropping the shield for that is sometimes the right call. You fight with what you were actually carrying. Dropping something to free a slot is an Action.

### How do I Defend?

Blows land. There is no defense roll. Burn Fuel and cut the incoming Damage by the faces. Leftover, armor soaks; anything still left comes off HP.

Caps: **melee** — one die, or **no limit** if you made a melee attack or a Block this round (any foe); **missile** — one die, or two with Cover; **hostile magic** — no limit. If you are the archer or mage caught in reach without having meleed, you cut each melee blow with a single die.

### Does blocking cost me?

Yes. **Block** spends **an attack**, one of the blows in your Attack action, to meet a blow aimed at you or step in front of one aimed at an adjacent ally. Defend it as normal; then your shield and Parrying weapons take their slots off, each one you have the Trait for. One attack covers one blow. A Block counts as a melee attack for the Defend cap.

A Veteran (Sword 1+) gets extra attacks (one extra per Sword level). Any of those may be spent to Block, or held for a Counterattack. You cannot Block if you have already spent every attack.

### I'm out of dice. Am I dead?

No. You are **winded** until the next Roll Initiative tops you off. Blows arrive whole in the meantime: leftover after armor comes off HP. Past 0 opens a **Wound**. That is the dangerous turn — not the empty hand by itself.

HP is luck and wind. The Wound is flesh. Finish it or fold, and get help when the fight ends.

**Top-off (round 2 and after):** keep the dice you didn't use, and roll your level in new dice, plus 1 for each counted item you have the Trait for, plus the light-kit die if you still have three empty slots, never past your maximum. Recount 3s and 4s. The dice you keep stay frozen.

### Do monsters have Fuel?

**Preferred speed:** no. Each enemy group rolls **1d6** for order, rerolled each round. They quote attacks. You Defend. They have a **Monster Stack** (2 × HD cards), not a Fuel pool. Ordinary folk at that speed have no Fuel either — they do not get a free Defend.

The Referee does roll a small handful of dice when the fight starts, as many as the Referee likes (try the biggest monster's HD or one per player, whichever is greater). They press a quote now and then, or on a rare 6 get a foe past the line. They last the whole fight with no refill. They are not Fuel, never Defend, and don't replace the 1d6 for order. [[Burners Referee Guide#The Referee's dice]].

**Optional:** a solo duel can run a monster as a Burner for spend and Defend. Initiative stays the group (or solo) 1d6. That is a demo tool, not the default. [[Burners Referee Guide#Monsters at speed (preferred Referee mode)]].

### What is a Spark?

A natural **6** on a Fuel die. An opportunity, not a free Action. Strike the Spark, then **Fuel** it with the extra Fuel its option requires, or let it fade. Flurry, Man-handle, Impale, Sever, Counterattack — see [[Burners Adventure Game#Combat]].

**Sever** is only vs foes with **too many parts** — octopus, spider, hydra, swarm-limbs. Chopping steel, Fuel the Spark with 1 Fuel, one spare limb or head is gone for the fight. Not for ordinary humanoids.

---

## After the fight

### I went past 0. What now?

A blow that drives you **below 0 HP** opens a **Wound**. Shock Check at once (`2d6 + Sword` vs total wound severity) — that asks whether you stay combat-effective, not whether you die. Natural **1+1** always fails; **6+6** always succeeds.

After **any fight in which you took a Wound**, you **die** unless you receive **help** in time (an ally's Action, first aid, *Stanch*, Vitae, or other care the Referee accepts). Helped, you make a **survival check**: **`2d6 + Craft` vs total wound severity**. An ally who assists may let you use **their Craft**. Natural **1+1** always fails. Fail, or go unhelped → dead.

A blow that lands you **exactly at 0** spends the last of your luck; you are not Wounded until a blow drives you negative.

### How do I get HP back?

**Hour Rest** (one hour, food and water): all HP to maximum — **only if you have no Wound**. Wounded: **1 HP per day** of safe rest until full HP, then the Wound closes. *Stanch*, potions, and chirurgeons can restore HP sooner. An aggravated Wound (Fallen, disease, moon-sick) ignores ordinary recovery until it is cleared. [[Burners Adventure Game#Healing and recovery]].

---

## Experience

### What pays XP?

**Treasure wrested from the dungeon:** 1 XP per 1 gp — coin, gems, jewelry, goods, art — credited at the deed: kill a guardian beside its hoard, or beat the trap into the room, and that treasure pays then, found or not. Sneak past and you earn only what you carry off. Undefended treasure and anything taken in town pay nothing.

**Monsters:** when you overcome them — killed, routed, or otherwise put down. The Referee sets the XP.

**Never XP:** magic items, weapons, armor, tools, monster parts, bounties, keeps, ships. They are their own reward; some sell for coin.

Coin is the long road. Monster awards are smaller. Beating what guards the haul is how you level. [[Burners Experience]].

### Do I know my XP?

No. The Referee keeps the totals. When you have your four Traits and enough XP, the Referee tells you that you level up the next time you wake from a safe sleep. [[Burners Experience#Who tracks what]].

### Who shares?

Who was there when the thing went down, or when the haul became party loot. Left before, or walked up after: no cut.

Split evenly among Burners and retainers on the job who are **not** Mustering. Non-Musting retainers keep **half** of that share. **Musting** seats are out of the divisor; they split **half of their Boss's XP**.

---

## Muster

### Do retainers top off Fuel?

Yes, thinly. Half power: a retainer's Fuel maximum is **⌊retainer level / 2⌋** plus its gear dice, minimum **1**. A level-1 retainer rolls its gear, one die below a Burner. The Boss's Muster dice can top up any of them, any time.

If the Boss spends their Action to **Manage**, up to Heart Mustering retainers round the level part **up** that round (the Boss takes no other Action). HP on the sheet does not rewrite mid-fight. [[Burners Muster#Half Power]].

Ordinary folk and speed-mode monsters are not retainers. They have no Fuel.

---

## Magic

### How do I recover a spent weave?

After **8 hours of uninterrupted sleep**. With no readable source: recover up to your caster level in cards from among tapped, burned, and lasting. With your **personal spellbook** (or a **true writing** whose hand you can already read): full redraw, every card ready. Another mage's personal spellbook is not a readable source. [[Burners Sorcerie]].

Casting in a fight is one Action (Fuel at least SL). Hostile magic is Defended like steel — overrun may land control instead of HP.

### Can I Ward for the crew?

A **Sorcerer** (Sorcerie 1+) adjacent to an ally or a tight group may cut hostile magic aimed at them. Burn up to your **Sorcerie Level** in Fuel; each ally then Defends what remains. Not your Action — Ward rides the incoming working. Craft-only Canting Journeymen cannot Ward.

### The sorcerer died. Can we learn from their book?

Their **personal spellbook** is crib notation, not a lesson — it only ever worked for them. Hunt a **true writing** or a teacher. [[Burners Sorcerie#Spellbooks]].

---

## Undead

### We put it down. Why isn't it dead?

Steel puts a husk down. **Fire** lays it. Unburned Fallen get up. A Wound from the Fallen festers — Purge, or it deepens. [[Burners Burn Undead]].

---

## Play

### When do I roll?

When the Referee names a **Risk**. Say what you do and how. If the plan is sound and certain, it just happens. If it is risky, **`2d6 +` the fitting Approach** against that number. Shortfall is **Heat**. There is no Persuade roll for whether the world bends.

### Where is the rest?

| Question | Book |
| --- | --- |
| How a fight runs | [[Burners Adventure Game#Combat]] |
| Worked fight, roll by roll | [[Burners Examples of Play]] |
| XP, the deed rule, shares | [[Burners Experience]] |
| Retainers, Manage, Loyalty | [[Burners Muster]] |
| Casting, hand, sleep | [[Burners Sorcerie]] |
| Spell catalog | [[Burners Spells]] |
| Running the table, Monster Stacks | [[Burners Referee Guide]] |
| Why the engine is built this way | [[Burners Principles]] |
