---
layout: default
title: "Burners OSE Conversions"
hero: /images/lancelot-speed-pd/knight-approaching-distant-castle.png
hero_alt: "A knight rides toward the distant keep — Lancelot Speed"
---

# Burners ↔ OSE Conversions

In the spirit of *The White Hack*, *The Black Hack*, and *The Black Sword Hack*, this is **the Burners Hack**. Use the original roleplaying game — through the lens of how [Old-School Essentials](https://oldschoolessentials.necroticgnome.com/srd/index.php) has cleaned it up — **unless Burners says otherwise**. Modules, treasure types, morale, reaction, turns, and the rest come in as written; this page is the routing table for where the Hack replaces or reframes a piece. Every conversion also follows [[Burners Principles]].

**Clocks.** OSE turns and rounds are Burners turns and rounds. Durations and light burn as written (torch 6 Turns / one hour-cycle, lantern 24 per flask; candles on [[Burners Equipment]]). Wandering monsters: [[Burners Referee Guide#Turn Tracker]] — always 1-in-6; roll on even turns and again when noise, dark, or wounds fire. OSE's plain check every other turn is the time signature. OSE's "rest one turn every hour or −1 to hit" is not used; Burners recovers HP with an [[Burners Adventure Game#Wounds|Hour Rest]] (a full quiet cycle, food and water, unwounded) instead.

**Default (keep as written).** Morale (2–12 on 2d6); reaction (2d6 — add **Heart** if a Burner leads the parley); number appearing; Treasure Type and coin values; movement as relative speed. Treasure XP and shares: [[Burners Experience]] (claimed haul, magic 0 XP, monster parts not XP, Eldar column).

---

## XP Awards

Burners uses OSE monster numbers on its own level table (see [[Burners Experience]]). Port treasure types and coin values as written; award treasure XP when the haul is **claimed**. Shares and part-out: [[Burners Experience]]. Eldar use the double-XP column.

| Source                   | Award                                      |
| ------------------------ | ------------------------------------------ |
| **Monster overcome**     | Printed OSE XP, or HD chart below          |
| **Coins, gems, jewelry** | 1 XP per 1 gp when claimed                 |
| **Goods, art**           | 1 XP per 1 gp when claimed (Ref sets gp)   |
| **Magic items**          | 0 XP — the item is the reward              |
| **Monster parts**        | gp or kit when claimed — 0 XP          |

Level when you next sleep somewhere safe after your XP crosses a tier (see [[Burners Experience]]).

### Monster XP by Hit Dice (OSE)

| HD      | XP  | HD    | XP      |
| ------- | --- | ----- | ------- |
| under 1 | 5   | 7     | 950     |
| 1       | 10  | 8     | 1,900   |
| 2       | 20  | 9–10  | 2,750   |
| 3       | 60  | 11–12 | 4,500   |
| 4       | 125 | 13–16 | 6,000   |
| 5       | 250 | 17–20 | 8,500   |
| 6       | 500 | 21+   | 10,000+ |

For fractional or special HD, **prefer the monster's printed XP** or the full OSE [Awarding XP](http://oldschoolessentials.necroticgnome.com/srd/index.php/Awarding_XP) table (base + bonus per `*` ability). This short chart is a coarse shortcut — e.g. HD 3 reads **60** here, but an OSE [Wight](http://oldschoolessentials.necroticgnome.com/srd/index.php/Wight) (`3`*) is **50 XP**.

**Converting a module hoard.** Roll or place treasure as OSE directs. Coins, gems, jewelry, goods, and art pay **1 XP per gp** when **claimed** — left behind grants nothing until claimed; the Referee sets each find's gp once (now or later). Magic items pay **0 XP**; the item is the reward. Carcass parts (hide, tusks, ivory) may sell or be useful kit — **0 XP** ([[Burners Experience#Part out]]). Delving retainers: OSE half-share if not Mustering; Mustering seats split half of their Boss's XP (see [[Burners Muster]]). Full procedure: [[Burners Experience]].

---

## Monsters

### The Stat Line

| OSE                      | Burners                                                                                                                                                                                          |
| ------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **HD**                   | Level, 1:1. **Monster Stack** = **2 × HD** playing cards (face-down closed / face-up open). |
| **XP**                   | Award when overcome — **XP by HD** from the table in *XP Awards* (a 1 HD skeleton = 10; HD 2 = 20). Use the module's printed award if given.                                                     |
| **AC**                   | Hint for the **face mix** only — soft kit → some face-down; shell/plate → mostly face-down; naked/sushi → all face-up. Suggest a **right tool** fiction (poleax, slicing, silver…) players may claim for the extra Fuel die. |
| **Damage die**           | Quote weight for Referee speed attacks (d6 → quote 3, etc.) — see [[Burners Referee Guide#Monsters at speed (preferred Referee mode)]]. |
| **Saves**                | Deleted — route the *ability* through the Defend Router                                                                                                                                          |
| **Morale**               | As written                                                                                                                                                                                       |
| **THAC0 / attack bonus** | Deleted — there are no to-hit rolls                                                                                                                                         |

### 2 × HD Monster Stack (face mix)

See [[Burners Principles#Armor soaks; monsters use Monster Stacks]] and [[Burners Referee Guide#Monsters at speed (preferred Referee mode)]]. **Monsters do not use PC Armor Class.**

**Referee speed (preferred):**

1. Deal **2 × HD** playing cards onto the table.
2. Paint the **face mix**: naked/sushi/no kit → **all face-up**; soft kit (leather, shield) → **some face-down**; mail/heavier → more face-down; true shell/plate/scales → **mostly or all face-down**. Soft armor **adds face-downs into the mix** — not a flat soak outside the budget.
3. Hard shell/plate / sushi often suggests a **right tool** (poleax, slicing, silver…) — claiming it lets a player burn **one extra Fuel** into the blow. Hits are always ⌈damage ÷ 5⌉; closed → **−1**, always, while any face-down remains.

Do **not** invent a tiny soak “just because the book had AC.” AC 1–2 as flat damage reduction was a **Referee math tax** — players never changed tactics for it.

Worked: **orc in leather** HD 1 → **1 down / 1 up**. **Wolf / naked tough** → **all face-up** (2 × HD). **Wet Devil** HD 8 → **16 face-up**. **Giant crab** HD 3 → **6 face-down**; poleax as right tool. **Knight in plate** → heavy face-down in 2 × HD; magic or pollaxe as right tool. **Dragon** → mostly face-down; name fire / soft underbelly / etc.

When a PC **loots** a suit of armor off a foe, that kit becomes ordinary Burners AC for the wearer — the monster’s face-down cards were the table paint, not PC AC.

### The Damage Die → quotes (and optional full-dice)

Preferred Referee play is **scene Heat + free quoted attacks** — no free monster Defend — [[Burners Referee Guide#Monsters at speed (preferred Referee mode)]]. The OSE damage die sets **quote weight** (and optional full-dice ports when you run a foe like a PC). Initiative is the group **1d6**, not Heat.

**Quote from the die (preferred):**

| OSE damage die | Quote (rough) |
| -------------- | ------------: |
| 1d4            | **2** |
| 1d6            | **2** or **3** |
| 1d8            | **4** |
| 1d10           | **5** |
| 1d12, 2d6+     | **5** (or two quotes) |

**Optional full-dice ports** (named foes you want to burn Fuel like a Burner): treat the damage die as weapon slots for blow weight — 1d4 → 1 slot, 1d6 → 2, 1d8 → 3, etc. — and roll a Fuel pool. See [[Burners Arms and Armor]]. Most nights, don't.

**Natural attacks** are quotes (or weapon slots on a full-dice port), not Initiative dice.

**Initiative:** each distinct foe group rolls **1d6** every Round Initiative (same as [[Burners Adventure Game#Combat]]). Heat is unpaid Risk, not the Initiative dish. Optional full-dice foes may roll a Fuel pool like a Burner — label that choice at the table. Fiction tempo still holds:

- **Shambling** *(the sluggish dead, oozes, rooted things)*: **acts last**, skip the d6.
- **A living spear** *(cobra, ambush-hunter)*: acts at the **top of the order**, skip the d6.

**Charge** *(a beast closing at a run — where OSE pounce/leap riders convert)*: a situational bump the Referee adds to the quote — as any situation can bump a blow (see [[Burners Adventure Game]]). **Shambling** things never get it.

**Receive a Charge** *(maneuver — a braced longer weapon, and you must see it coming)*: your thrust strikes **first**, before the rush lands, and the charger's rush adds to *your* blow instead. If it survives and presses in, its attack resolves as normal.

**Multi-attack routines** (claw/claw/bite): the Referee sets how many **quotes** the creature throws (a wolf bites once, a bear claws twice, a hydra strikes per head), each defended separately. Spread them across several characters, or land them all on one.

**Spellcasting monsters:** convert their list through the Spells section, or skip the list and quote each casting as a blow or a telegraph. A dragon does not need a spellbook; it needs a Breath telegraph and two good tricks. Wizard-type foes and libraries: leave a grimoire with **1–3 named 1sts**, school labeled — see *Enemy spellbooks* on [[Burners Referee Guide]].

### The Defend Router

An OSE save is a pointer to a Burners subsystem — see [[Burners Principles#Route, don't reinvent]] and [[Burners Principles#Granular defense, not binary save]]. `2d6 +` **the fitting Approach** against the Referee's Risk handles most hazards (see *Approach Roll* in [[Burners Adventure Game]]). Hostile magic uses Fuel Defend against the caster's cast total (see [[Burners Sorcerie]]). Ask what the save protects, then route it:

| OSE says                                    | Burners does                                                                                                                                                                                                                                                                           |
| ------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Save vs. Breath**                         | **Area effect** — see [[Burners Principles#Telegraph the unwinnable]].                                                                                                                                                                                                                 |
| **Save vs. Poison (or die)**                | **Defend** (Craft) to avoid; **lingering Cost** once it lands. See [[Burners Principles#No instant death]].                                                                                                                                                                            |
| **Save vs. Paralysis**                      | **Defend** (Craft or Sword) at the touch; fall short and you **stiffen** for a stated clock (ghoul-chill, 2d6 rounds) — recoverable, not permanent.                                                                                                                                    |
| **Save vs. Petrify**                        | **Counting doom**: repeated **Defends** (Craft or Sword), each miss a step toward stone; it recovers. Averting your eyes is the counterplay, at the price of fighting blind.                                                                                                           |
| **Save vs. Spells / Wands / Rods / Staves** | Fuel **Defend** vs **cast total**; roll initiative OOC. See [[Burners Principles#Granular defense, not binary save]] and [[Burners Principles#Harm and effect are separate lanes]]. **Ward:** adjacent Sorcerer burns ≤ Sorcerie Level Fuel to cut the attack, then each ally Defends. |
| **Save vs. Death effects**                  | **Shock Check** and **Wounds**, then post-fight help + Craft survival — see [[Burners Principles#No instant death]] and [[Burners Adventure Game#Wounds]].                                                                                                                             |

**Which Approach?** Craft to dodge a dart, pit, or poison; Sword to force a door, hold your feet, or stay conscious; Heart against fear and horror; Sorcerie to dredge up what you know against the uncanny. The player may argue for another Approach if the fiction fits. When in doubt: Craft to avoid, Sword to endure.

### Deriving a Score (when a module needs a raw number)

Burners has no ability scores on the sheet. On the rare occasion a module wants an actual number — an opposed feat of might, a stat-keyed gate — derive one on the fly as **10 + the fitting Approach level**:

| Old score | Approach |
| --------- | -------- |
| STR       | Sword    |
| DEX, CON  | Craft    |
| WIS, CHA  | Heart    |
| INT       | Sorcerie |

So a Sword 3 stands at an effective 13, a Craft 2 at 12. This is a fallback for the odd direct comparison, not a number to track — most endurance routes through a **Defend (**`2d6 +` **Approach)** and most contests are a **Pay** or **Deal** roll the same way.

### "Magic Weapons to Hit" → armor + right tool

See [[Burners Principles#Armor soaks; monsters use Monster Stacks]].

| OSE says               | Burners                                                                                         | The feel                                                                                                |
| ---------------------- | ----------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| Silver or magic to hit | Heavy **face-down** in the 2 × HD mix; players may claim silver/magic as the right tool (one extra Fuel into the blow) | *Resistant.* Everyone eats the −1 while face-down stands; the smart play is the claim. |
| +1 or better to hit    | Same; right-tool fiction = legendary blade or stated weakness                                 | *Unearthly.* Mortal steel is folklore; the right edge makes it mortal.                       |
| +2/+3 or better to hit | Same — the right tool may need *discovery*, or a fiction gate (*phylactery*)              | *A puzzle wearing a stack.* Not a bigger soak number.                                              |

The **right tool** is a **player claim** (fiction + one extra Fuel burned into the blow), not a Ref auto-switch — see [[Burners Principles#Armor soaks; monsters use Monster Stacks]]. Same spirit as a Bane-forged weapon (see [[Burners Arms and Armor]]).

**Undead & energy drain** (OSE): **no levels lost.** Any of the Fallen that **wounds** you opens a **Fallen Wound**. Midnight / Purge: husks deepen by **1**; drainers by `1d6` + `1d6` per OSE drain level (wight `2d6`). Immediate Craft survival; die unclean → spawn; die from purge → no spawn. See [[Burners Burn Undead#Fallen Wounds]] and [[Burners Principles#No instant death]].

**Mobs vs. the unearthly:** see [[Burners Principles#Armor soaks; monsters use Monster Stacks]].

---

## Checks, Doors, and Skills

A module check splits two ways. A trained or skilled attempt — thief skills, foraging, listening at doors — becomes `2d6 +` **fitting Approach vs Risk**, quoted as a **Pay** (the world acts on you — shortfall is Heat) or a **Deal** (you act on it — shortfall is no purchase). A raw attribute check with no skill behind it — bend bars, leap a chasm, stare down a horror — is the same: `2d6 +` Sword, Craft, or Heart vs the Referee's Risk.

| OSE chance | Heat |
| ---------- | ---- |
| 5-in-6     | 6    |
| 4-in-6     | 7    |
| 3-in-6     | 8    |
| 2-in-6     | 9    |
| 1-in-6     | 10   |

Stuck doors, thief skills, foraging, listening at doors — all this table. A trained Approach shifts the odds; that is the point of being a Burner.

**Traps and environmental damage** — see [[Burners Principles#Pools, not fixed numbers]] (*Traps*). Average the module die to flat Damage; detect or eat.

**Worked in the margin — the OSE zombie** (AC 8 [11] · HD 2 (9hp) · 1 × weapon, 1d8 · Morale 12):

> **Zombie.** HD 2 → **4 face-up** (AC 8 → no kit, all-up sushi) · Heat dish for the side · **Shambling** — acts last · Morale 12 as written · **XP 20**. Quote fists as heavy (**4**).

Read straight off the printed block — 2 × HD cards (face mix), Heat, right-tool-if-any, tempo, Morale.

---

## Spells

Port OSE spells onto [[Burners Spells]] when a match exists; otherwise write a one-line effect in the same format (`School L: …`).

- **Spell level = cast level SL.** Hand holds prepared cards; Sorcerie slot count sets hand size; Arcana rides in Sorcerie slots at full item cost (books and scrolls may too — fill the slot, no Initiative die). Sleep recovers up to caster Level cards (untap/burn/lasting); redraw or one-hour swap needs a readable source.
- **Durations and ranges as written** — the clocks match.
- **Casting (combat):** one Action; burn at least SL Fuel dice, roll them — cast total = sum of faces. Tap the card. On a Spark, Fuel it with one or more additional Fuel dice, up to SL, for extra effect; unfueled, it fades. May burn ready cards in the same Action to recast or copy.
- **Casting (NPC / module caster):** roll at least **SL Fuel dice** for the cast total the same way. A hostile cast **rolls initiative** if no fight is underway.
- **Defense and damage:** see [[Burners Principles#Granular defense, not binary save]] and [[Burners Principles#Harm and effect are separate lanes]]. Ignore OSE per-caster-level dice and fixed damage lines; overrun to HP 1:1. *Save for half* does not port.
- **Scrolls** require a **Sorcerer** (or Journeyman + Canting for Canting) — single-use items, any form; not cards (see [[Burners Sorcerie]]).

---

## Magic Items

Potions, rings, cursed items, and wondrous items port **as written** — they are fiction plus a rule, and the fiction is the value. **Magic items grant no XP**; the item is the reward (see *XP Awards*). Wands and staves that fit **Arcana** ride in Sorcerie slots at full slot cost (costume Arcana 100 gp in town; enchanted Arcana is a find — see [[Burners Sorcerie]]); they do not add hand cards. Item powers run as magic items, or for a one-off keep charges as a simple budget.

### +n Arms, Shields, and Armor → Enchanted + Powers

Convert *+1 sword*, *+2 shield*, *+1 plate*, and so on per [[Burners Referee Magic Items]] — extra die, +n powers, Tuned / Bane / relic ladders, and the OSE power menus all live there. Trait for the extra die: [[Burners Adventure Game#Enchanted Arms and Armor]]. Keep Slots, AC, and size as the mundane piece.

Potions, rings, and wondrous items stay as written above. Do not raise AC or size for a plus.

---

## Watchpoints

- **Lethality is comparable** — B/X at low levels is brutal and Burners characters are lean. Large mobs can spike past any defend; use swarm splitting and chokepoints.
- **Foreshadowing is mechanical** — see [[Burners Principles#Heat is collateral]].
- **Solo bosses** need enough face-down (and face-up) in 2 × HD to survive the party's first-round burst, or they die before their first telegraph.
- **Don't double-count dread** — see [[Burners Principles#Heat is collateral]].

---

> *Read the stat block once, write it in the margin — 2 × HD cards (face mix), Heat, right-tool-if-any, XP by HD — route the saves through Defend, and run it.*
