---
layout: default
title: "Burners Referee Guide"
hero: /images/albert-robida-pd/deal-struck-in-town-square.png
hero_alt: "A deal struck in the town square — Albert Robida"
---

# Burners Referee Guide

*How the world pushes back. The players say what they do; this is the toolkit for everything they do it to — the passage of time, the dark closing in, and the first cold look of a stranger.*

Three things run most of it: the Heat gauge you drive up and down as the scene's pressure, the Turn Tracker that keeps the world's ten-minute clock honest (old-school d6 for wandering monsters, light and noise on paper), and the Reaction roll that decides how the living things take to the crew.

---

## Running Heat

Heat is the crew's shared gauge and the spine of every scene — the full player rules are in [[Burners Adventure Game]]; here is how you drive it. It is the temperature of the room, not anyone's nerve: you narrate the room tightening and the number, face-up on the table, tracks it.

**Open every scene at a base**, set by how hot the room already is:

| Base | The scene |
| --- | --- |
| 3–4 | Quiet — a meet, a market, an empty road |
| 6 | Working — the vault, the wilderness, the parley that matters |
| 8 | Loud — the job blown, the chase, the hall on fire |

**Feed it.** Every shortfall the crew can't soak raises Heat by what they fell short — compress big misses, a botched sneak is +1 or +2, not +5. A blow past a defense, a blown roll, a hard parley all feed it, and you may raise it by fiat when fresh danger walks in (reinforcements, a lit lantern, the storm arriving), announced. Wounds do not feed Heat; they carry their own pressure.

**Telegraph threats to set the room.** Rough rubric: raise Heat toward the shown monster's **HD** — lower if the foe is disadvantaged, higher if it owns the situation. Reveal in stages and the gauge climbs with the fiction — spoor, then half-eaten kills, then the beast at full HD (a pack: summed HD, capped by chokepoints and the dark). Show the signs for slow dread; conceal them for an ambush that raises no Heat and strikes from surprise instead. Its presence sets the room; its attacks still quote its own Damage. Heat is the press dish — never the Monster Stack.

**Work the valves.** Heat falls when the crew acts on the room, not on request: fell or lose a named threat, −2; remove a named source (quench the fire, learn the ward-phrase), −1 or more; a Double Sweet vents 1; a steadying word or plan you buy, −1 once a scene. Folding ends the scene and cools to the next base. Downtime — a safe camp, a town between jobs — cools to base; a job that ended loud raises the base of what follows until the crew lies low and spends coin. Carousing is maintenance, not vice.

Heat joins the enemy side as its **Initiative / press pool** (preferred: **Heat dice only** — see [[Burners Referee Guide#Monsters at speed (preferred Referee mode)]]). Climbing Heat makes them a little faster and lets them press quotes; it does not hand you a second PC-scale dice puzzle. Finish it or fold.

---

## Running the Delve

The exploration turn is one World Turn — ten minutes. Each turn runs the same short loop:

1. **Declare.** The party sets a pace (cautious, normal, or hurried) and a primary action for the turn — move, search, listen, force, rest, interact, or something else.

2. **Present the Scene.** Frame the place in three strokes — Scene, Oddity, Risk (below). One vivid image, one thing that begs to be poked, one reason to hesitate.

3. **Resolve.** Play out the action: movement, searching, talk, a forced door, a fight.

4. **Advance the clock.** Mark the Turn on the Turn Tracker (below). Tick light. Check for wandering monsters when the schedule or a bang calls for it. Update ongoing spells, conditions, and any other clocks the fiction demands.

Between turns the loop just repeats: frame, resolve, advance.

---

## Searching and Traps

Searching costs a Turn. What it buys depends on what they tell you they are doing.

1. **Intent and method.** "We search the room" is a Turn spent and a rough look. "I run my knife along the seam under the sill" is a specific act on a specific thing, and it gets a specific answer.
2. **Give the information.** Anything a careful person would notice in ten minutes, they notice — no roll. The scratched flagstone, the draft, the tool marks, the chest whose lid sits a finger too high. You are not hiding facts; you are charging time for them.
3. **Roll only if it is still uncertain.** When the method might work and might not, it is `2d6 + Craft` vs the Cost. When the method plainly works on that problem, it works. When it plainly does not — bare hands on a masterwork lock — say so and let them spend the Turn elsewhere.

A trap the party has been told about is a puzzle, not a gotcha (see [[Burners Principles#No gotchas]]). Spring it undetected only when they walked past the sign or never looked. The trap quotes flat Damage — armor soaks on the way in, no Fuel up out of combat.

Mark the Turn either way. A fruitless search still burns light and still feeds the wandering-monster schedule.

---

## Scene, Oddity, Risk

Every room, encounter, or travel scene should answer three questions. Build it in thirty seconds and it will run itself.

**Scene — what do they immediately perceive?** One or two sentences, no backstory: one memorable image and one dominant sense. The players should instantly know where they are.

**Oddity — what invites investigation?** More than something strange: something that begs to be touched, examined, talked to, experimented with, circumvented, or asked about. The players should think "what's going on here?" If they can ignore it without a second thought, it is not a strong enough oddity.

**Risk — what makes that investigation uncertain?** Every interesting choice carries a possible cost: monsters, traps, hazards, time pressure, noise, resource drain, social fallout, a moral bind. The risk need not trigger at once, but it must be real. The players should think "how do we approach this?"

**The test.** If a scene has no curiosity, no meaningful interaction, and no consequence, it is just scenery — rewrite it. Run the checklist: can I picture it? do I want to investigate it? do I hesitate before I do? Three yeses and the scene is ready.

*Example — Scene: a rope bridge spans a mist-filled chasm. Oddity: every rope has been cleanly cut, yet the bridge still hangs in the air. Risk: crossing or closely examining it wakes whatever holds it aloft.*

---

## Turn Tracker

A world Turn is ten minutes. Track Turns on paper where the players can see it. One line per Turn: a check mark `x`, then noise if they made any — `!` for noise, `!!` for extra noise. Shouting, kicking in doors, fighting, casting spells, and the like all count. Optionally note light, WM rolls, and what happened.

```
X  enter, listen the door
X  Bellamy lantern (24) · WM 5
X ! forced the grate
X  WM 2
X  search the shrine
X  WM 4
X !! fight in the nave · lantern out · WM 3
X  WM 2
```

### Wandering monsters (d6)

Check at the start of every other Turn, or **immediately** when you write a bang (`!` / `!!`). Roll **1d6** and write the result ("WM n") on the line.

| Condition | Chance |
| --- | --- |
| Quiet | 1-in-6 |
| Noise | 2-in-6 if there was `!` in the past 20 minutes or `!!` in the past hour |
| Dark | 2-in-6 if quiet; 3-in-6 with noise and/or wounds |

When an encounter lands, set distance and warning from the fiction (or the module), roll Reaction if the thing can parley, and build it per Building and Running Monsters (below).

Whatever comes was already doing something before the dice said so. Say what in one breath — patrolling, hunting, hauling a kill, fleeing something worse, arguing over spoils, lost. That one line turns a roll into a clue about the place, and it usually tells you the Reaction before you roll it.

### Light

Track burn on the paper — do not hide it behind a die.

- **Torch:** 30′ for 1 hour (6 Turns). Bundle of 6: 1 gp, 1 slot ([[Burners Equipment]]).
- **Lantern:** 30′ for 4 hours (24 Turns) per flask. Lantern 10 gp; oil 2 gp; 1 slot each.
- **Candle:** 5′ for 1 hour (6 Turns). Bundle of 6: 1 gp, 1 slot.
- **Rag-on-a-stick:** as candle, up to ~20 minutes if lucky. Free, 1 slot.

---

## The Grind — Supplies, Fatigue

Light lives on the Turn Tracker. Fatigue is why the party cannot crawl forever, and it needs no separate die — it feeds Heat, because Heat is the crew's shared wind and nerve, and wearing down a long crawl is exactly the loss of those. When the fiction calls for a grind tick (long haul, thin air, lingering too long), raise the gauge, usually +1, and it rides there until the crew vents it. Supplies (rations, water, ammunition) run down the same way when you say they should.

A Journeyman keeps the band fresh. The [[Burners Adventure Game|Journeyman's craft]] reduces party-wide travel, weather, and survival costs by the Journeyman's Craft level, and fatigue in the dark is a survival cost like any other. Subtract the Journeyman's Craft from the tick for everyone they are leading: Craft 1 shrugs off a routine +1 entirely. Fatigue bites when the party has no Journeyman, when the Journeyman is down or split off from the group, or when the place is harsh enough to outrun their level. Scale the tick to the dungeon — a mild crawl adds 1, a brutal one (heat, thin air, crushing dark) adds 2 or 3, so a Journeyman's Craft matters more the worse the ground gets.

The over-extended party is the danger this builds: the grind pushes Heat up even when nothing is attacking, so a crew that lingers, lost and tired, walks into the next fight against a hotter scene — the enemy rolling a deeper pool and acting first. "We're worn thin and the room's boiling, and nothing's even swung at us yet — we have to get out" is the pressure a long crawl builds even when nobody has taken a wound.

### Cooling off — and how HP comes back

Heat cools when the crew acts on the room (see Running Heat). HP and Wounds follow [[Burners Adventure Game#Wounds]]:

- **Full HP closes wounds.**
- **Hour Rest** (one hour, food and water) fills HP to maximum **only if you have no Wound**.
- **Wounded:** **1 HP per day** with food until full, then the Wound closes. Vitae / *Stanch* / potions can help; *Healing Touch* does not restore at 0 HP or less.
- **First aid** (Craft) tends a wound and can be the **help** for the post-fight survival check; it does not restore HP by itself.
- After a fight where you took a Wound: **help**, then **`2d6 + Craft` vs severity** — or die. Monster specials (spawn, etc.) if you die from that creature's attack.

**Classic Crawl** (optional campaign flavor): once unwounded and at 0+, use **1d3 HP per full day** in a safe haven instead of Hour Rest for luck recovery. Write the choice at session zero. Wounds and survival still run as above.

### Fallen Wounds

Any of the Fallen that **wounds** you opens a **Fallen Wound**. Midnight / Purge: husks deepen by **1**; major / draining Fallen deepen by `1d6` + `1d6` per drain. Full procedure: [[Burners Burn Undead#Fallen Wounds]].

---

## Reaction — First Impressions

Disposition is a fact of the world (see Influence in [[Burners Adventure Game|the core rules]]), and when it is not already fixed by the fiction you roll for it. Any NPC, monster, or faction the party meets fresh gets a Reaction: roll 2d6 and read the table. This is the world's own leaning at first contact — the roll only says how it starts; what you ask next is still the Two Steps.

Circumstances are the main lever. A drawn blade, a shared enemy, a debt, a standing feud, or a fearsome reputation shift the roll the way a situational modifier shifts a defend — set a plus or minus from the same bands. Where one character is plainly making the approach (the spokesperson, the one who speaks the tongue, the face of the band), add their Heart. And Sweet and Spicy ride along as always: a rolled 6 is a good twist on the meeting, a rolled 1 a complication, whatever the total.

| 2d6 | Reaction | What it means |
| --- | --- | --- |
| 2 or less | Hostile | It moves against you now: attack, alarm, or bolt into a worse response. A natural 2 (fumble) is always Hostile. |
| 3–5 | Wary | Suspicion, hard words, steep terms. It would rather you were gone; push it and it turns. |
| 6–8 | Neutral | Uncertain and cautious, no commitment either way — the most open to being swayed by what you do next. |
| 9–11 | Amiable | Warm enough to talk, trade, or lend a hand, for a fair price or a good reason. |
| 12 or more | Friendly | It takes a shine to you: real aid, a favor, the start of an ally. A natural 12 (perfect) is always Friendly. |

Roll once at first meeting. Re-roll only when something material changes the footing: they save its life, they are caught in a lie, the faction hears what they did in the last town. A creature with no capacity for parley — mindless undead, a beast in a killing frenzy, a construct bound to its orders — skips the roll and does what its nature dictates; the table is for anything that can, in principle, be dealt with.

Reaction sets the starting disposition; the Two Steps and Influence carry the specific asks from there. A Friendly guard still will not hand you the keys to the vault, but he might look the other way where a Hostile one raises the cry.

---

## Frequency — running hot or cool

The default Turn Tracker (WM every other Turn, Quiet 1-in-6, bangs immediate at Noise) is classic dungeon tempo. Loud crews and dark crawls hit the higher rows and feel the pressure. If a job should run hotter, check every Turn instead of every other, or treat Dark as the floor even in lit halls. If cooler, keep Quiet at 1-in-6 and only bang-check on `!!`.

### Delve Die (optional)

If you want one 2d6 to fold encounter, break, and grind into a single roll, use this instead of the d6 WM checks — not both.

Roll 2d6, add nothing. Read the 1s and the 6s, not the sum.

- Any **1** → encounter. The other die is lead time (1,1 surprise through 1,6 distant drop).
- A **6** and no 1 → a break (safe nook, shortcut, omen, cache). Double 6 is a real gift.
- Neither → the grind: tick light, supplies, or fatigue (see The Grind above).

Every Turn runs hot; every other Turn is cooler. Distant 1,5 / 1,6 can be a sighting the party slips away from.

---

## Building and Running Monsters

A monster is any enemy: Hit Dice, attacks, and a public **Monster Stack** of **2 × HD** playing cards (face-down closed / face-up open). Its Hit Dice are its level: most humans are 0, most orcs are 1, a veteran higher. How blows land on that stack: this section. Burner-side Fuel economy: [[Burners Principles#Pools, not fixed numbers]].

### Monsters at speed (preferred Referee mode)

**Monsters have Hit Dice.** Deal each monster a **Monster Stack** of **2 × HD** playing cards. **Face-down = closed** (armored / shell). **Face-up = open** (meat). Ignore rank and suit. The stack replaces notepad HP. Players like a fat Fuel pool; you keep the enemy side **small and quotable**.

**Pool = Heat only** (one dish for the whole enemy side). Roll it for Initiative (count of 3s and 4s) and as optional Fuel when you **press**. Heat is not durability — never pluck it for damage. Set it from the shown threat: **≈ HD**, down if the foe is on the back foot, up if it owns the fight.

**Free attack (quote).** Flat damage — no die from the pool.

| Fiction | Quote |
| --- | ---: |
| Light (dagger, claw d4) | **2** |
| Common (sword, claw d6, tentacle+cutlass) | **2** or **3** |
| Heavy (d8, axe, crab smash) | **4** |
| Huge (d10+, ogre, polearm-beast) | **5** |

**Paint (mix inside 2 × HD).** Naked / sushi / tough hide with no kit → **all face-up**. Soft kit (leather, shield) → **some face-down** (orc HD 1 → **1 down / 1 up**). Mail/heavier → more face-down. True shell/plate/scales → **mostly or all face-down** (crab HD 3 → **6 face-down**). Soft armor **adds face-downs into the mix** — it does not invent a flat soak or a second track outside 2 × HD.

**One blow:**

1. Player announces **damage**. Keep the big number.
2. **Hits = ⌈damage ÷ 5⌉** (always round up).
3. **Closed?** (any face-down remains, or flesh that shrugs their edge) → **−1 Hit**, always. Armor is one card of soak — −5 damage in effect. No spend waives it.
4. **Right tool** — the player claims it in fiction (*“I slice the sushi!”* / *“poleax on the shell!”*) and burns **one extra Fuel** into the blow (beyond the weapon's usual dice); its face **adds** to damage before rounding. A deeper blow, not a waiver.
5. Pop **face-down first, then face-up**. **0** → bounce.

| Damage | Hits | Closed (−1) | Open |
| --- | ---: | ---: | ---: |
| 1–5 | 1 | 0 | 1 |
| 6–10 | 2 | 1 | 2 |
| 11–15 | 3 | 2 | 3 |
| 16–20 | 4 | 3 | 4 |

**Cracked!** = last face-down gone — faces show; the armor −1 ends. **Dead** = stack empty; scoop.

**Tactics:** claim the right tool for the extra die when it matters — the player holds the story. Scraps after Cracked. A **1**+**2** is still 1 Hit (ceil); closed → bounce; the right tool's extra die is how a stuck blow punches through.

**Press (optional).** Burn a Heat die onto a quote when it matters.

**Hordes.** Shared Heat dish. Attacks = bodies in reach. One **Monster Stack** (2 × HD cards) per body; soft kit only changes the face mix. Fat stacks for solos and named threats.

**Shambling** → act last.

**Full-dice monsters (optional).** Solo duel / demo as a Burner. Default is speed mode.

Also: `experiments/burners-monster-stacks.md` — Monster Stacks (and the older `experiments/burners-cracked.md` quote sheet).

### Morale — when the other side quits

Scores port from OSE unchanged (2–12, rolled on 2d6, roll under the score to hold). What matters at the table is remembering to ask. Check at these moments, once each:

- the side takes its **first death**
- the side is down to **half** its bodies, or a solo is **Cracked**
- the **leader** falls, flees, or is plainly beaten
- something lands that the creature has no answer to — fire on a beast, silver on the thing silver is for, a working it cannot shake

A failed check is not always flight. Read it off the fiction: run, surrender, bargain, drop the loot and scatter, or fall back to a defensible spot and keep watching. Animals bolt; disciplined troops withdraw in order; the desperate beg. Mindless things — husks, constructs, a beast in frenzy — skip Morale entirely and fight to the last card, which is exactly what makes them frightening.

When a side breaks, the threat is overcome for Heat purposes even if the bodies are still on the table. Vent, then decide whether the party gives chase (see Retreat and Pursuit).

---

## Situational Damage Modifiers

The Referee raises or lowers Damage for the situation. Set a value from the band, or roll a swing die when the moment is chaotic. Narrate the cause so players can attack the reason.

| Band | Feel | Examples |
| --- | --- | --- |
| +1 | slight edge | bad footing, downhill, a mild distraction |
| +2 | clear advantage | from behind, flanked, foe in the dirt, grappled |
| +3 | strong | surprised, blinded, struck mid-cast |
| +4 | severe | pinned, ambushed in the dark, several stacked |
| +5 | dire | helpless while the fight still rages |

The defender's edge runs the same band the other way: partial cover is a 2, hard cover a 4, an attacker who is in the dirt or swinging blind gives you a 2 or 3. When a blow outruns the dice a defender can burn (a lone die, or as many as they like once they have meleed this round; two vs a missile with Cover) plus their armor, the excess lands on HP — and past 0 it cuts a score.

---

## Swarms

Foes piling onto one target attack like a single Veteran of many levels: the group makes a bundle of attacks — reckon one per body in reach, or one per Hit Die for a larger creature — each its own blow of up to two dice, each defended separately, and each soaked by the defender's armor on the way in. Three orcs on Aldric are three attacks, not one big one. Once Aldric has meleed this round he Defends without limit against all of them; until then each blow is one die. An ally may **Block** for him (spend one melee attack to redirect one blow onto themselves). A chokepoint caps how many reach you at once; kill one and the bundle loses its attacks.

Keeping the blows separate is deliberate. A single combined Damage would blow past armor in one unsoakable spike; many small hits, each soaked on the way in, mean a mob wears you down through attrition and a draining Fuel pool instead — you run out of dice to defend before you run out of HP. That is the real danger of numbers: not one dreadful blow, but more attacks than you have dice to answer. The counter is avoidance — break line of sight, fight from a chokepoint, raise a shield as Cover, or thin the mob until the swings come slower than you can turn them.

---

## Cover, Sparks, and shooting into the press

Fuel is rolled face-up. Everyone can see the 6s.

When a missile flies into a melee, the target may use a **melee foe as Cover** (see [[Burners Adventure Game]]). If they Fuel a Spark on that Defend, the shot hits that foe instead — often a Burner locked with them. That is the rule working as written, not a gotcha to spring cold.

Before the arrow goes: give a friendly warning. *"Are you sure you want to put that into the press? He's got a Spark sitting right there."* The player still chooses. You telegraphed the risk while the dice were already on the table. See [[Burners Principles#No gotchas]].

---

## The Safe Town

The party begins in a safe town, which is a haven but not a home base and not theirs. It offers lodging, food, supplies, law, healing, and rumors: a place to cool off, re-equip, mend wounds, and hear where trouble lies. The party are guests on someone else's ground, and the town has its own authorities and life. Adventures spiral out from it and back to it, and a party may later earn or build a true home base of their own.

**Level here.** XP banks in the field; characters spend it to gain a level only in civilization — this town, another haven, or a place where they can train and rest. Mid-delve rank-ups do not happen. Rare emergencies are your call.

**Exploration crumbs (optional).** A small XP award for a wilderness hex newly mapped or a dungeon room meaningfully explored rewards poking and mapping without replacing treasure. Tune the number; there is no fixed crumb.

**Inventing spells and items.** When a player wants a working or lasting item not in the catalog, treat it as a campaign project: time, rare materials, a teacher or ruin, and a clear failure mode. No price table. Arcana stay finds; research may yield a scroll or potion formula, or a one-off the table invents together. See [[Burners Sorcerie]].

---

## Pricing Unlisted Gear

When an item is not on the [[Burners Equipment]] tables, price it from its slots and category, then adjust for quality and rarity and add it to the list. Listed gear uses the Equipment prices. The rates below are for **unlisted** pieces.

- Common gear (clothing, tools, a waterskin): 1 gp per slot.
- Fine steel and specialty goods (books, lockpicks, instruments, specialty tools): 10 gp per slot.
- Plain armaments (odd weapons not on the list): 5 gp per slot.
- Provisions: 1 gp per meal for the group.
- Ranged weapons and special materials such as silver add a surcharge when you invent a new piece.
- Arcana have no shop price — found, seized, gifted, or inherited. Scrolls and potions are downtime craft at 100 gp × spell level (see [[Burners Sorcerie]]).
- Heavy or exceptional armaments run far dearer: about 100 gp for a +1 grade, 1,000 gp for a rare +2 (added on a listed or formula price).
- Elevated quality adds to any item: +10 gp for fine, +100 for rich, +1,000 for noble work.
- Magic items are rarely for sale at any price; you decide whether one can be found at all. Stocking enchanted arms: [[Burners Referee Magic Items]].
