---
layout: default
title: "Burners Sorcerie"
hero: /images/henry-justice-ford-pd/wizard-with-enchanted-book.png
hero_alt: "The wizard and his book — H. J. Ford"
---

# Burners Sorcerie

*Magic — how a Sorcerer prepares, carries, and spends it.*

How magic works: who can cast, personal spellbooks and true writings, Sorcerie slots and
Arcana, the hand, the cast, burning, ritual, and Defend against hostile workings. Scrolls
and potions are at the end. The spell lists live on **[[Burners Spells]]**; worked rulings
for every 1st-level spell are on **[[Burners Magic Examples]]**.

## How Magic Works

Magic is prepared, not spontaneous — but the preparation lives in **you**, not in a wand
someone can snatch. A Sorcerer exists in two realms at once, and their pack proves it.
Utility first — most spells solve problems (light, movement, control, ward); hostile
magic lands through the same **Defend** economy as steel. The Sorcerer title (Sorcerie 1)
switches casting on; a combat cast is one Action that burns at least SL Fuel dice
(SL = the working's level) and rolls them for the **cast total**.

## Spells Are Cards

Think of every spell you know as a card.

- Your **personal spellbook** is your **deck** of known spells — **crib notation**, not a
  teaching book. A **true writing** in reach (one complete working) can add that spell to
  what you may memorize while you can study it (see *Spellbooks*).
- Your **hand** is the spells you have prepared to cast.
- Your **Sorcerie slot count** sets your **hand size**, the number of cards you may hold.
- **Casting** a spell **taps** its card.
- **Burning** a card exiles it to pay for more casting in the same Action.
- After **8 hours of uninterrupted sleep**, two paths (see *Sleep and recovery*):
  - **No readable source** — recover up to your caster level in cards from among tapped,
    burned, and lasting; re-split physical vs Sorcerie slots if you wish, but your hand
    stays as it is except what the budget restores.
  - **Readable source in reach** — your personal spellbook, or a true writing whose hand
    you can already read (see *Learning Spells*) — re-split freely and **full redraw**
    your hand from your whole deck. Every card you put in arrives **ready**; the limited
    recovery budget does not apply. Another mage's personal spellbook is not a readable
    source for you.

Every card in your hand is in exactly one zone. **Tapped, lasting, and burned cards all
still occupy hand size** until recovered (or lasting ends).

| Zone | Meaning |
| --- | --- |
| **Ready** | In hand, untapped — cast it any time. |
| **Discard** | Cast, with no lasting effect. |
| **In play** | Cast, with a lasting effect running. Moves to Discard when the effect ends. |
| **Burned** | Exiled — a step beyond Discard. Cannot be used until recovered. |

**Lasting** is a special case: the card stays *in play* while the effect runs. On sleep
redraw or a one-hour swap you may leave lasting cards in place; swapping one out or
spending sleep recovery to untap it **ends the effect**.

Tapped and burned are very different fates. A tapped card can be bought back with a burn.
A burned card is spent until you rest — you cannot burn a card to recover a burned card,
and no working, no gold, no clever reading brings one back early.

**One ready name per hand.** You cannot hold two *ready* cards for the same spell. A
burn-**copy** under an in-play lasting working is allowed — that is not a second ready card.

## The Sorcerer

To work magic you must be a **Sorcerer — Sorcerie 1 or higher.** Below that you are a
layman, and the cards mean nothing in your hands.

**Spell level.** Your **Sorcerie** is your caster level: you may **learn and know** spells
of level up to your Sorcerie. A Sorcerie-1 mage knows only 1st-level spells; a
Sorcerie-6 up to 6th. There is no focus ladder — no relic that lets a first-rank sorcerer
throw a 6th. The power is in the practitioner.

**A school is trained-only.** Each of the **six people-schools** (Vitae, Elementale,
Thaumaturgy, Illusione, Umbrakala, Necromantia) keeps its own secret language and spell
list; you must hold a Trait in that school to touch it at all. The common Sorcerie school
asks no Trait — being a Sorcerer is grammar enough. Canting is separate — Craft, not a
people-school.

**Hedge wizards.** Village casters, chapel priests, roadside apothecaries — still
**Sorcerers**. Same cards, same Sorcerie-slot split. They may work common Sorcerie alone,
or a people-school without the high look (Vitae in mortar-and-vial Arcana is still Vitae).
The school is the Trait and the list; the Arcana is costume. There is no separate Craft
hedge school for mending — healing stays Vitae.

**Canting is the exception.** The rogue's school rolls **Craft**, not Sorcerie. A
**Journeyman (Craft 1+)** with the **Canting** Trait may learn, hold, and cast Canting
only — the Darkman's school — with the same card rules. See [Canting: Kicks and
Jarks](#canting-kicks-and-jarks). No Sorcerie required.

## Starting Out

### The Starting Sorcerer

A Sorcerer's craft comes with a kit (the fruit of apprenticeship). At character creation
you **declare 7 physical slots and 5 Sorcerie slots** — twelve total. You may not re-split
until your first 8-hour sleep; we start fast.

Your **personal spellbook** holds **five known spells**: ***Read Magic*** plus **four
others** from your school — the fruit of apprenticeship, already taught and already
written in **crib notation**. The Referee picks them, rolls them, lets you choose, or
works with you — your table's call. Your **hand size is 5** — all five ready. Count them
on your fingers when you onboard. You did **not** need *Read Magic* to learn the other
four; a master taught them. *Read Magic* is in the book because it is useful loot
literacy, not because it unlocks learning. The personal spellbook is crib notes for
**you** — it is not a source anyone else can learn a spell from (see *Spellbooks*).

You also start with **one free Arcana** — costume of the craft from the allow-list
(mundane grade). Extra costume Arcana costs **100 gp apiece** in town; enchanted Arcana
stays a find. See *The Starting Sorcerer* under Starting Gear in [[Burners Adventure
Game]] for purse and oddments.

### The Canting Journeyman

A Journeyman who takes the **Canting** Trait and walks the Canting road declares **7
physical + 5 kicks** — same slot-split rules as a Sorcerer's Sorcerie slots, different
name and kit — but starts with **no spells** in the reader and an **empty hand** of five.
Canting is learned in play: guild teaching, stolen manuals, jarks spent or scribed. Other
Journeymen keep a normal twelve-slot pack; the split is only for rogues who work Canting
magic.

### Becoming a Sorcerer later

When you first reach **Sorcerie 1** in play, you gain the title — you may cast, declare
**Sorcerie slots**, and Ward. You do **not** gain the apprentice kit: no free personal
spellbook, no free Arcana, no starting spells. **You must buy a personal spellbook**
(blank, **25 gp**) if you want a deck of your own. Costume Arcana is **100 gp** apiece in
town if you want it. Spells are not for sale.

That is why waiting costs more than starting as a Sorcerer: the apprentice walks in with
a personal spellbook, one Arcana, and five ready spells; you pay for the blank book and
hunt every working.

Your hand starts **empty**. Grow the book the same way any Sorcerer does:

1. **Find** a **true writing** whose hand you can read (*Learning Spells*), **or** pay a
   teacher (**1,000 gp × level** — they choose what you learn).
2. **Carry** a found true writing (or stand at a fixed one) to redraw that working.
3. **Scribe** what you mean to keep into your personal spellbook — **no gp per spell**,
   only downtime (see *Spellbooks*). Crib notation cannot teach; another mage cannot
   learn from your book.

***Read Magic* is not required to learn.** The Referee should put a path to a first
working in reach soon after the title turns on.

### New Sorcerer in play

Table checklist when someone takes Sorcerie 1 mid-campaign — detail lives in the sections
above and in *Learning Spells* / *Spellbooks*:

- Blank **personal spellbook** **25 gp** (no apprentice kit)
- Empty hand until you learn
- Grow from a **true writing** (scribe **time only**; the true work remains) or **ask a
  teacher** (**1,000 gp × level** — teacher chooses the working). Do not learn from
  another mage's personal spellbook — crib notation, not a lesson.
- School **Trait** (or common Sorcerie) to read that tradition; *Read Magic* identifies
  foreign true writings and scrolls
- Costume Arcana **100 gp** if wanted; enchanted Arcana are finds
- Re-split physical vs Sorcerie slots on rest

## Sorcerie Slots

**Sorcerie slots** are the mage half of your twelve. Say the full phrase when it matters —
**Sorcerie 3** is your Approach level; **3 Sorcerie slots** is pack space.

**Sorcerie slots** set your **hand size**. **Arcana** fill them and throw Initiative.
**Books and scrolls** may also ride here — they occupy the slot, no Initiative die. The
**hand** is spell cards.

You have twelve item slots. As a Sorcerer you **declare a split**: so many **physical**,
so many **Sorcerie slots**. The **number** of Sorcerie slots is your **hand size**. Your
**hand** is separate from inventory; it is your ready spells, pictured as cards. The cards
live in you.

Canting uses the same math under **kicks** — see [Canting: Kicks and Jarks](#canting-kicks-and-jarks).

- **Re-split on rest.** On any 8-hour sleep you may redeclare the split. A Sorcerer who
  wants a six-card hand declares **six Sorcerie slots** — empty or filled; empty still
  count for hand size, only Arcana throws Initiative. The cost is rope, rations, and armor
  left behind.
- **Approach caps the spell.** Any card in your hand may be a spell of any level up to
  your Sorcerie (or Craft, for Canting). Slots are not leveled.
- **Your hand is personal.** No thief, no disarm, no dropped pack parts a caster from
  their hand. Only sleep, burning, and your own choices move the cards. Losing your
  personal spellbook cuts off redraws and swaps from your own deck — the notes can be
  taken, the hand cannot. The thief cannot learn from those notes.

**Initiative.** On Roll Initiative, add **one die per Sorcerie slot occupied by Arcana** —
empty slots, books, and scrolls add none. Arcana in those slots does not also add
weapon-in-hand dice. Sorcerie slots **never** also count toward the empty-inventory
Initiative dice (max 4). (Canting: one die per occupied kick.)

### Arcana

A Sorcerie slot may carry **Arcana**, a **personal spellbook**, a **true writing**, or a
**scroll** — nothing else. **Arcana** are the costume and foci of the craft: **staff,
wand, rod, orb, crystal, ring, amulet, mask, robes, hat**. Each item costs its **full
normal slot cost** (a staff is 3 Sorcerie slots, not 1; a ring is 1). Hedge craft counts
the same when it is clearly one of those forms — goat-horn hat, bone amulet, cracked
crystal.

- **Books and scrolls.** A personal spellbook, a portable true writing, or a scroll may
  sit in a **physical or Sorcerie** slot. In a Sorcerie slot it **fills the slot** but is
  **not Arcana** and **throws no Initiative die**. Either home still counts as
  **carrying** it for redraws and swaps — your personal spellbook for your own deck, a
  true writing for that one working. Book price for a blank personal spellbook is **25
  gp** (see *Spellbooks*), not the 100 gp costume tag.
- **Price (costume).** Costume Arcana (mundane grade) is **100 gp apiece** in town — a
  true wizard's hat is not a street hat. A starting Sorcerer gets **one free**. Enchanted
  Arcana has no shop price: find, seize, gift, or inherit.
- Arcana keeps its mundane function. A wizard's staff is still a staff — swing it, lean on
  it, bar a door with it.
- **Never** armor, weapons (beyond the staff's honest whack), shields, or plain cargo. A
  Sorcerie slot cannot carry fifty feet of rope. That restriction is the price of the
  split.
- Losing Arcana loses an item, nothing more. Steal the archmage's staff and you have
  stolen a stick. Steal their **personal spellbook** and you have stolen their deck — the
  hand stays; they cannot redraw from those notes. You cannot learn from them either.
  Steal a **tome** and you have stolen one complete working.
- **Found Arcana is still Arcana.** A relic wand, a runed ring, a captured staff — even a
  full magic item — rides in Sorcerie slots at its normal slot cost if it fits the
  allow-list. It does not add a card to your hand. Whatever power the treasure holds runs
  as a magic item; your hand is still only spells from your deck (or, for a true writing
  in reach, that one working — see *Spellbooks*).

## Casting

**No spontaneous magic.** You cannot cast a card that is not ready in your hand.

**The cast.**

1. **Say what you do** — name the spell and its effect in the fiction.
2. **Name the Risk.** In combat, casting is one Action: burn at least SL Fuel dice
   (SL = the working's level) and roll them for the **cast total**, as ever. Out of combat,
   roll **2d6 + Sorcerie** (or **2d6 + Craft** for Canting) against the Referee's Risk.
   Sparks, cast fumbles, and Defending against a spell run as written in
   [[Burners Adventure Game]].
   3. **Tap the card.** An instant working goes to your discard as it resolves. A lasting
   working stays **in play** for its duration, then joins the discard.

Casting in reach may invite a **Counterattack**. Struck mid-cast, Defend and mid-tempo disrupt as in
[[Burners Adventure Game]].

**When a cast Sparks.** Fuel it with one or more additional Fuel dice, up to SL, and
burn that Fuel on the *working itself* — another target caught, a beat longer, a ward
pierced (Referee's call). Add no Fuel and the Spark fades.

**Cast fumble (combat).** Combat has no Sweet or Spicy. If two or more of the Fuel dice burned for the cast show **1**, or a one-die cast shows **1**, the working fumbles — the Referee's worst fitting outcome (singe an ally, alert the ward, the card taps with no effect).

## Burning

When it comes down to the wire: what will you burn? What won't you need again before you
rest?

You may **burn** ready cards from your hand **as part of the same cast Action** — burns
and the working together. One Action may burn any number of ready cards (levels covering)
**and** resolve a cast, recast, or copy; roll at least SL Fuel dice for the working that
lands. Burns enable:

- **Recast** a spell in your discard, or
- **Copy** a spell you have in play — a second working alongside the first. Place the
  burned card face-down beneath the active one to mark the copy (does not break *one ready
  name*).

**The rules of the fire:**

- **Hand only.** Fuel comes from ready, uncast cards. You cannot burn from your discard,
  from play, or from the burned pile.
- **Levels must cover the spell.** The burned cards' levels must sum to **at least** the
  level of the spell being recast or copied. Several small cards may combine; any overage
  is wasted.
- **Scrolls never burn.** See [Scrolls](#scrolls).
- **Burned is burned** until sleep recovery spends a card from your budget to return it.
  Burned cards still occupy hand size.

Every card in your hand is a cast — and every card is also fuel for a repeat of something
better. You cannot have both.

## Sleep and Recovery

After **8 hours of uninterrupted sleep**, choose one path:

**Without a readable source** (your personal spellbook lost, left in camp, or no true
writing you can read in reach): recover up to **Sorcerie Level** cards (**Craft Level** for
Canting) from
among your tapped, burned, and lasting cards. That budget is **one pool** — each card you
recover costs one card from the budget, whether you are untapping a tapped card or returning
a burned one. Spell level does not matter; five 1sts and one 5th both cost one card each.
You may still **re-split** physical vs Sorcerie slots; your hand otherwise stays as cast
left it, except what the budget restores.

**With a readable source in reach** — your personal spellbook, or a true writing whose
hand you can already read (see *Learning Spells*) — skip the limited budget.
**Re-split** physical vs Sorcerie slots freely and **full redraw** your hand from your deck (see
*Changing Your Hand*). Every card you put in arrives **ready**. You may **keep lasting
cards in place**; swapping one out **ends the effect**.

A character with **both** Sorcerie and Craft (Canting) uses **one hand** and **one
split**; the sleep budget (when used) is the **higher** of Sorcerie Level and Craft Level.

Recovering a **lasting** card through the limited budget untaps it and **ends the effect**.

## Changing Your Hand

Choosing or changing the cards in your hand requires a **readable source** — your
personal spellbook, or a true writing you can read (see *Spellbooks*).

- **Rest: full redraw.** Requires a readable source in reach (see *Sleep and recovery*).
  Rebuild your hand freely from your deck — any known spells, up to your caster level, one
  per hand slot, unique by name. You may **keep lasting cards in place**; swapping one out
  **ends the effect**.
- **One hour: swap one card.** With an hour of study and the source in hand, exchange one
  card in your hand for one from your deck. **The incoming card inherits the outgoing
  card's status** — swap out a tapped card and the new card arrives tapped. Swapping out a
  lasting card **ends its effect**.

## Scrolls

A **scroll** is a single-use working — **not** a card. One spell, already written:
parchment, feather, wax seal, charm on a string — call it a scroll either way. **1 slot**
each; it may ride in a **physical or Sorcerie** slot. In a Sorcerie slot it occupies the
slot but is not Arcana and throws no Initiative die.

- **Cast** it as any spell of that level: one Action in combat, at least SL Fuel dice for
  the cast total — then it is **spent** (ash, blank vellum, snapped charm). Your **hand is
  untouched**; no card taps.
- **Cast only.** A scroll can never be burned as fuel.
- **Who may cast:** a **Sorcerer**, or a **Journeyman** for Canting scrolls — you need the
  school's Trait (or Canting). A Veteran cannot wake one. *Read Magic* identifies it before
  you spend it.
- **Scribing** (downtime): **100 gp × the spell's level** in reagents, from any spell you
  hold in a readable source — making a scroll is gold work; moving the same spell into
  your personal spellbook is time only (see *Spellbooks*). You may unmake a
  scroll into your personal spellbook (time only; the scroll is destroyed without being
  cast).

| Spell level on scroll | Cost to scribe (gp) |
| --- | --- |
| 1 | 100 |
| 2 | 200 |
| 3 | 300 |
| 4 | 400 |
| 5 | 500 |
| 6 | 600 |

## Potions

A **potion** is a single-use draught — **not** a card, **not** Arcana. Downtime work. A
**Sorcerer** who holds the school's Trait (or common Sorcerie — no Trait needed) may brew
a potion from a known formula — a working they hold in a readable source. **Craft**
herbalism and alchemy do not bottle spells; that is the sorcerer's job. Cost: **100 gp ×
the spell's level** in reagents and about a week × its level. Touch or self effects only
— what a draught can hold. The potion is one dose, **1 physical slot** (never a Sorcerie
slot); **anyone may drink it**. Recipe and gold decide it — no caster rank beyond the
Trait. Found potions stay treasure.

## Ritual Casting

A spell **ready in your hand** can be worked as a **ritual** — slowly, rooted in place,
and only while you sustain it. You must hold the card; no spontaneous book-cast. Ten
minutes per spell level; leave the circle or break the working and it collapses
retroactively. Never a combat option. Burns are not part of a ritual.

Cast as usual. When the card would **enter the discard** — an instant as it resolves, or a
lasting working when its effect ends — it **returns to your hand ready** instead. The
card is not spent.

**Knowledge is the exception.** Whatever a spell puts in your *mind* stays — *Detect
Magic*'s auras, a divination's answer, anything the Referee judges is now simply known.

## Binding Nodes

A **Node** is a place where ley lines cross and the Astral presses close. Its power shapes
the surrounding **Regio** and often opens onto a Kalla. To bind one is to make yourself
its **Guldur** — its node-master.

First find the Node's heart and learn enough of its nature to work there: its signs, its
present master, and what it demands. Then draw a **magic circle** around the heart in the
materials the place answers to — chalk, salt, ash, blood, silver, living roots. Inscribe
your mark among the Node's signs and work within the unbroken circle for **8 uninterrupted
hours**. You must remain inside throughout. Companions may guard the circle, but only the
claimant binds.

If the Node is unclaimed and its demand has been met, the binding simply works. If it is
hostile, wounded, or already claimed, this is a Step-2 risk: roll **2d6 + Sorcerie**
against the Referee's Risk. A present master may **Defend** the claim with Sorcerie. Break
the circle, leave it, or lose the contest and the rite fails; the Node answers according
to its nature.

A successful binding displaces the former master and reveals the Node's established
**Facts**: what its Regio changes, where its gates lead, what the Guldur may command, and
what price or duty the bond carries. Every Node is a place and a power of its own. Binding
one gives authority over what that Node already is; it does not make the place harmless,
portable, or wholly obedient.

### Node Cards

A bound Node enters your **deck** as a **Node card**. On redraw, you may put it in your
hand like any other card. It occupies hand size, but it is **not a spell**: it cannot be
cast, copied, scribed into a book, made into a scroll, or brewed into a potion.

Each Node has a **level from 0 to 6 in each school** — Vitae, Elementale, Thaumaturgy,
Illusione, Umbrakala, Necromantia, and Sorcerie. Many Nodes are a **single school**; some
are multi. Levels of 0 are simply omitted. Many also have an **alignment** (Black, White,
or mixed): that shapes the Regio and the bond's price, not which spells the Node feeds.

For a chosen school in which the Node has level 1 or higher, the Node **counts as a card
of that school level** — whether you tap it or burn it.

- **Tap for power.** Move a ready Node card to your **Discard**. It supplies Fuel dice
  equal to its level in that school for a cast of that school. The Node goes to Discard,
  not the spell you are casting.
- **Burn for power.** Burn a ready Node card. It counts as burned cards with total levels
  equal to its level in that school, toward recasting or copying a spell of that school.
- **Recover normally.** Discarded and burned Node cards recover like other cards during
  sleep.
- **The bond is live.** If the Node is sealed, corrupted, captured, or contested, its card
  may go inert or answer dangerously until the place is dealt with.

### Node Works

Magical research can write a working into a book, into a Node, or into the bond between a
Guldur and a Node.

- **Invent a spell.** The working becomes a spell in your book and deck, handled by the
  normal spell rules.
- **Build a working into the Node.** The working belongs to the place: a ward, gate, omen,
  prison, weather, hidden road, or engine. It works at the Node or in its Regio for whoever
  the Node accepts. It does not occupy your hand.
- **Bind a working to the Node card.** The Node card gains text. While it is ready in your
  hand, you may use that researched working by moving the Node to Discard. The working's
  school must be one in which the Node has level at least equal to the working's level.

Creating a new Node Work takes serious downtime: **one season** of access to the Node,
specialist materials, and whatever Cost the Referee sets. Binding an existing known spell
to a Node is easier but still major work: use the same research procedure, with a shorter
clock if the table wants one. Old Nodes often have Works already installed; discovering
what they do is treasure.

## Spellbooks

A working in writing comes in two notations. Do not mix them.

**Crib notation** is compressed — often a private cipher. A **personal spellbook** is
written this way. It holds every spell you have scribed. It is enough for **you** to
redraw what you already know. It is not enough for anyone else to learn a spell from
scratch.

**True notation** is the complete working: a large work, **one spell**. Diagrams,
constraints, the names, the grammar laid out. This is what you find — a **tome**, runes
cut into an arch, a working filling the back of a map (the map is on the back of the
spell). This is what you learn from.

| Writing | Notation | Learn a new spell? |
| --- | --- | --- |
| **Personal spellbook** | Crib — many spells, yours | No. Only you can redraw from it. If you die, it teaches no one. |
| **Another mage's personal spellbook** | Crib — their notes | No. *Read Magic* may name what they knew — intel, not a lesson. |
| **Scroll** | Primed to cast once | Yes — unmake it into your book (time only; the scroll is destroyed). Or cast it and it is gone. |
| **True writing** | True — one complete working | Yes. This is how you find a new spell. |

**True writing.** One spell, complete. Bound as a **tome**, cut into stone, or filling a
sheet that happens to have a map on the other side — same thing. Not primed (that is a
scroll). Not crib notes (that is a personal spellbook). While a true writing whose hand
you can read is **in reach** (you carry it, or you stand at the arch), you may treat that
working as **known** for redraw and swap. Leave it and the working leaves your ready
library until you recover it or scribe it into your personal spellbook. A portable true
writing is **1 slot** (physical or Sorcerie), or rides on an object you already carry. A
**tome** is still **1 slot** — large as a work, one item in the pack. Each true writing is
one spell; three finds are three slots until you crib them.

**Personal spellbook** — **1 slot**, physical or Sorcerie (fills the slot; not Arcana; no
Initiative die). Crib notation. Only you. Left in camp, your deck is out of reach: no
redraws, no swaps until you are reunited. Margins hold **Facts** (scraps, runes, puzzles)
— free in plain ink; another reader might still use those as mundane intel. The workings
themselves are private cipher. Starters get one; latecomers buy a blank at **25 gp**.

**Moving a spell into your personal spellbook.** Copy it from a true writing you can
already read, a scroll unmade, or a working a teacher just showed you: about a week × its
level, plain ink, **no gp**. No roll. Scribing writes **crib notation**. It does not
produce a second true writing, and it does **not** unmake the true work — the find stays
a party lesson until it is lost, sold, or destroyed in the fiction. A scroll unmade is
destroyed. A living teacher is not. You need a personal spellbook first. **Slot note:**
your personal spellbook is still **1 slot** no matter how many spells it holds.

**Copies within your library** — a spare of **your** personal spellbook: **25 gp × level**
and a day × level; the first is not destroyed. The spare is still yours, still crib
notation, still not a lesson.

**Lost personal spellbook (no source).** Rewrite what **you** already knew: **1,000 gp ×
level** and one week × level per spell — same rate as paid tutoring, sole focus (OSE
lost-book rewrite). Another mage's personal spellbook does not count as knowing.

| Item | Slots | Cost (gp) |
| --- | --- | --- |
| Personal spellbook, blank (physical or Sorcerie) | 1 | 25 |
| Tome (found; one spell) | 1 | — |
| Scroll case | 1 | 5 |
| Move a spell into your personal spellbook | — | 0 (time only) |
| Ask a teacher to teach you something | — | 1,000 × level |
| Lost personal spellbook — rewrite one known spell | — | 1,000 × level |
| Reagent inks (copy within your library) | — | 25 × level |
| Make a scroll | 1 | 100 × level |
| Brew a potion | 1 | 100 × level |

## Learning Spells

***Read Magic* is not how you learn a spell.** Learning is school hand + **true notation**
or a teacher. Crib notation — yours or anyone else's — is not a lesson.

- **Common Sorcerie** needs no Trait — any Sorcerer can read and learn from common-Sorcerie
  true writings and teachers. Plain sigils; the grammar of the craft.
- **A people-school** needs its **Trait**. Hold *Vitae*, *Umbrakala*, and so on, and that
  tradition's true writings are open: you see the working, memorize, and scribe. The Trait
  is enough — you do not cast *Read Magic* to study your own school's true notation.
- **Found true writings.** Loot one complete working, take Sorcerie 1 if you lack it,
  **buy a blank personal spellbook** if you have none, study the find, redraw, then scribe
  what you keep for free (time only). That is the usual road for someone who was not
  apprenticed at creation — costlier than starting as a Sorcerer because the apprentice
  kit is gone. A companion's personal spellbook, or a dead friend's, is not this find.
  Referees: when a foe casts from a tradition (or keeps a library), **stock true writings
  on purpose** — each one **named**, **one spell**, school labeled (or common Sorcerie).
  One to three finds is plenty. See [[Burners Referee Guide]].
- **Ask a teacher to teach you something** — a standard town buy when a willing tutor
  exists. **1,000 gp × the spell's level**, about a week. **You do not pick the working** —
  the teacher (Referee) chooses what they teach, within a school hand you can learn. Then
  scribe it into your personal spellbook (time only; teacher not destroyed). Want a
  *named* spell? Hunt a true writing or a scroll. Want any foothold fast? Pay and take
  what they give you.
- **Favor / quest teachers.** A hedge-wizard who owes you, or teaching as the price of a
  bargain, is fiction — no shop rate. Still: they choose what they show, unless the deal
  names a working.

*Read Magic* is for **magic items** (and opaque loot you cannot already read) — see
*Reading Magic* below. It does not enroll you in a school or put a card in your deck.

## Reading Magic

***Read Magic*** (Sorcerie 1) is a spell like any other — useful, not free, not required to
learn. See its entry on [[Burners Spells]].

**Its real work is magic items.** Cast or work it to learn what a ring, blade, wand, or
relic does — **Facts** on the piece (Step-2 risk when you probe deep). That is why
apprentices keep it in the starting five.

**True writings and scrolls** are a lesser use. If you already hold the school's Trait (or
the working is common Sorcerie), you read that true notation without this spell. Use *Read
Magic* on a true writing only when the hand is foreign to you — to **identify** the one
working it holds before you hunt the Trait, a teacher, or leave it. Same for a scroll:
know what it is before you burn it. On a **personal spellbook**, the same card may **name**
the workings the owner knew — intel, not a lesson. You still cannot learn those spells
from the notes.

Once you have identified a given hand of writing, you can recognize that script again for
identification — that is not school literacy for learning (see *Learning Spells*).

Optionally go deeper on an item or glyph: studying is an Action; describe how deep you
probe. Interpretation is a Step-2 risk — the deeper the reading, the steeper the Risk (HP,
time, noise, or a Spicy twist). Roll it out (Sorcerie, out of danger). On a success the
Referee reveals one **Fact** at the depth you reached — a power (what it does), a demand
(what it costs), or an omen (what changes about the bearer or world). On a **Sweet** you
fully grasp it and a revealed power can be called on demand; on a **Spicy** the reading
misleads or trips the power wrongly.

Track each magical item as two short lists, filled in as study and play reveal them:
**Facts** (established truths) and **Questions** (open threads). A Fact scribbled in your
personal spellbook is free to record; it is not a working. To learn a spell you still need
true notation or a teacher.

## Canting: Kicks and Jarks

Rogues on the Canting road use the same slot-split rules as Sorcerie slots — but a rogue
would never say *Sorcerie*.

- Those declared slots are **kicks** — secret pockets sewn where honest folk carry rope.
  *"How many kicks you running tonight?"*
- The **reader** is the pocketbook of the trade, written in flash paper and brotherhood
  marks. Same rule as a sorcerer's personal spellbook: **crib notation**, not a lesson.
  A dead rogue's reader teaches no one. It may ride in a **kick or a physical** slot.
- A scroll is a **jark** — a counterfeit seal, primed and single-use, spent when flashed.

All the card rules apply: **Craft** is caster level in place of Sorcerie; hand size is
kick count; tapping, burning, and sleep run identically. **Canting Trait** opens the
school; you need not be a Sorcerer. A character who also has Sorcerie still runs **one
hand** and **one split**; sleep recovery uses the **higher** of Sorcerie and Craft.

**Canting kit is different in the fiction — a lot more black.** Kicks hold the working
kit: rope, picks, a dark lantern, a betty, chalk, a muffler, soft-soled stampers — anything
**concealable** under a coat. Nothing that shines, nothing that rattles.

- **No weapons, armor, or shields** in a kick — with the burglar's exception: a **knife**,
  a **sap**, or a **sling** may hide there.
- A searched rogue looks like a burglar, not a mage. That is the point.

## Spells meshing with combat

Each spell has a name, level, and effect on [[Burners Spells]] — run it as written unless
this chapter, the spell list, or the Referee says otherwise. Where a spell's effect must
mesh with combat:

- **HP and damage** that target a **Burner** come off HP (physical effects: Defend first, then leftover, AC soaks). Against a **monster** at Referee speed, convert overrun to **Hits** on the
  face-down / face-up Monster Stack — see [[Burners Referee Guide#Monsters at speed (preferred Referee mode)]] and
  [[Burners Principles#Harm and effect are separate lanes]].
- **Hostile magic** is opposed with **Defend** — Fuel dice vs the caster's cast total. A
  hostile cast where no fight is yet underway still rolls initiative — unless the fiction
  is a quiet working in a friendly conversation (see [[Burners Referee Guide#Hostile magic
  outside a fight]]). Choose whichever Approach fits; a spell may suggest one (*Defend:
  Sword*). Procedure: *Defending against a spell* below.
- **Control** (charm, sleep, fear, command…) uses the effect lane, not HP — see
  [[Burners Principles#Harm and effect are separate lanes]].

## Defending against a spell

See [[Burners Principles#Granular defense, not binary save]] and [[Burners Principles#Harm
and effect are separate lanes]].

When a spell targets you with harm, control, or another hostile effect, the caster's
**cast total** is the sum of the Fuel dice burned to cast (at least SL Fuel dice for a
level-SL working).

**Roll initiative.** A hostile spell is an attack like any other. If no fight is yet
underway, roll initiative — the caster gains no free first strike. Exception: a quiet
working in a friendly conversation needs no Initiative and no Defend from ordinary folk
([[Burners Referee Guide#Hostile magic outside a fight]]).

You may **Defend** as against any blow: burn Fuel dice, sum the faces. Those dice are
burned for the fight. Your **defense total** opposes the cast total. Hostile magic has
**no die cap**. Spell text that says *Defend: Sword* (or Heart, Craft…) is fiction — which
Approach the struggle feels like — not a `2d6 + Approach` roll.

**Warding.** See **Ward** under Combat in [[Burners Adventure Game]]. Short form: a Sorcerer
(Sorcerie 1+) adjacent to allies may burn up to Sorcerie Level Fuel to cut a hostile cast
total or magical breath; each ally then Defends the remainder. Craft-only Canting cannot Ward.

- **Defense ≥ cast:** fully defended — no effect, no HP loss.
- **Defense < cast:** **overrun** = cast − defense. Apply per the harm/effect lanes above.

Spells with no hostile target (light on a wall, healing a willing ally, reading magic)
allow no Defend. Area workings: each target Defends separately against the same cast total.

### What Sorcerie is for

| Sorcerie | Role |
| --- | --- |
| **0** | Cannot cast |
| **1+** | Sorcerer — magic on; may Ward |
| **Higher** | Caster level: learn higher-level spells (up to level = Sorcerie); stronger Sorcerie rolls; sleep recovery budget = Sorcerie Level in cards (or higher of Sorcerie/Craft if both) |

See **[[Burners Spells]]** for the school lists and every working.
